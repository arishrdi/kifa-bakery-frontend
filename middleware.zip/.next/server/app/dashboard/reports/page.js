(()=>{var t={};t.id=589,t.ids=[589],t.modules={10846:t=>{"use strict";t.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:t=>{"use strict";t.exports=require("next/dist/server/app-render/action-async-storage.external.js")},3295:t=>{"use strict";t.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},29294:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-async-storage.external.js")},63033:t=>{"use strict";t.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},12412:t=>{"use strict";t.exports=require("assert")},55511:t=>{"use strict";t.exports=require("crypto")},94735:t=>{"use strict";t.exports=require("events")},29021:t=>{"use strict";t.exports=require("fs")},81630:t=>{"use strict";t.exports=require("http")},55591:t=>{"use strict";t.exports=require("https")},33873:t=>{"use strict";t.exports=require("path")},27910:t=>{"use strict";t.exports=require("stream")},79551:t=>{"use strict";t.exports=require("url")},28354:t=>{"use strict";t.exports=require("util")},74075:t=>{"use strict";t.exports=require("zlib")},4531:(t,e,a)=>{"use strict";a.r(e),a.d(e,{GlobalError:()=>d.a,__next_app__:()=>u,pages:()=>c,routeModule:()=>m,tree:()=>l});var r=a(88832),s=a(33471),n=a(83127),d=a.n(n),i=a(50280),o={};for(let t in i)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(t)&&(o[t]=()=>i[t]);a.d(e,o);let l=["",{children:["dashboard",{children:["reports",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,52919)),"D:\\aku\\kifa-bakery-frontend\\app\\dashboard\\reports\\page.tsx"]}]},{loading:[()=>Promise.resolve().then(a.bind(a,22396)),"D:\\aku\\kifa-bakery-frontend\\app\\dashboard\\reports\\loading.tsx"]}]},{layout:[()=>Promise.resolve().then(a.bind(a,57764)),"D:\\aku\\kifa-bakery-frontend\\app\\dashboard\\layout.tsx"],loading:[()=>Promise.resolve().then(a.bind(a,32912)),"D:\\aku\\kifa-bakery-frontend\\app\\dashboard\\loading.tsx"],metadata:{icon:[async t=>(await Promise.resolve().then(a.bind(a,23913))).default(t)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(a.bind(a,97755)),"D:\\aku\\kifa-bakery-frontend\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(a.bind(a,20583)),"D:\\aku\\kifa-bakery-frontend\\app\\not-found.tsx"],forbidden:[()=>Promise.resolve().then(a.t.bind(a,2456,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(a.t.bind(a,13305,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async t=>(await Promise.resolve().then(a.bind(a,23913))).default(t)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],c=["D:\\aku\\kifa-bakery-frontend\\app\\dashboard\\reports\\page.tsx"],u={require:a,loadChunk:()=>Promise.resolve()},m=new r.AppPageRouteModule({definition:{kind:s.RouteKind.APP_PAGE,page:"/dashboard/reports/page",pathname:"/dashboard/reports",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:l}})},19267:(t,e,a)=>{Promise.resolve().then(a.bind(a,52919))},33339:(t,e,a)=>{Promise.resolve().then(a.bind(a,62321))},62321:(t,e,a)=>{"use strict";a.r(e),a.d(e,{default:()=>eo});var r=a(18652),s=a(9861),n=a(89080),d=a(5988),i=a(95875),o=a(27277);let l=(0,o.A)("PackagePlus",[["path",{d:"M16 16h6",key:"100bgy"}],["path",{d:"M19 13v6",key:"85cyf1"}],["path",{d:"M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14",key:"e7tb2h"}],["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}],["polyline",{points:"3.29 7 12 12 20.71 7",key:"ousv84"}],["line",{x1:"12",x2:"12",y1:"22",y2:"12",key:"a4e8g8"}]]),c=(0,o.A)("PackageOpen",[["path",{d:"M12 22v-9",key:"x3hkom"}],["path",{d:"M15.17 2.21a1.67 1.67 0 0 1 1.63 0L21 4.57a1.93 1.93 0 0 1 0 3.36L8.82 14.79a1.655 1.655 0 0 1-1.64 0L3 12.43a1.93 1.93 0 0 1 0-3.36z",key:"2ntwy6"}],["path",{d:"M20 13v3.87a2.06 2.06 0 0 1-1.11 1.83l-6 3.08a1.93 1.93 0 0 1-1.78 0l-6-3.08A2.06 2.06 0 0 1 4 16.87V13",key:"1pmm1c"}],["path",{d:"M21 12.43a1.93 1.93 0 0 0 0-3.36L8.83 2.2a1.64 1.64 0 0 0-1.63 0L3 4.57a1.93 1.93 0 0 0 0 3.36l12.18 6.86a1.636 1.636 0 0 0 1.63 0z",key:"12ttoo"}]]),u=(0,o.A)("PackageMinus",[["path",{d:"M16 16h6",key:"100bgy"}],["path",{d:"M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14",key:"e7tb2h"}],["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}],["polyline",{points:"3.29 7 12 12 20.71 7",key:"ousv84"}],["line",{x1:"12",x2:"12",y1:"22",y2:"12",key:"a4e8g8"}]]),m=(0,o.A)("PackageCheck",[["path",{d:"m16 16 2 2 4-4",key:"gfu2re"}],["path",{d:"M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14",key:"e7tb2h"}],["path",{d:"m7.5 4.27 9 5.15",key:"1c824w"}],["polyline",{points:"3.29 7 12 12 20.71 7",key:"ousv84"}],["line",{x1:"12",x2:"12",y1:"22",y2:"12",key:"a4e8g8"}]]),h=0,p=new Map,x=t=>{if(p.has(t))return;let e=setTimeout(()=>{p.delete(t),f({type:"REMOVE_TOAST",toastId:t})},1e6);p.set(t,e)},y=(t,e)=>{switch(e.type){case"ADD_TOAST":return{...t,toasts:[e.toast,...t.toasts].slice(0,1)};case"UPDATE_TOAST":return{...t,toasts:t.toasts.map(t=>t.id===e.toast.id?{...t,...e.toast}:t)};case"DISMISS_TOAST":{let{toastId:a}=e;return a?x(a):t.toasts.forEach(t=>{x(t.id)}),{...t,toasts:t.toasts.map(t=>t.id===a||void 0===a?{...t,open:!1}:t)}}case"REMOVE_TOAST":if(void 0===e.toastId)return{...t,toasts:[]};return{...t,toasts:t.toasts.filter(t=>t.id!==e.toastId)}}},g=[],b={toasts:[]};function f(t){b=y(b,t),g.forEach(t=>{t(b)})}function j({...t}){let e=(h=(h+1)%Number.MAX_SAFE_INTEGER).toString(),a=()=>f({type:"DISMISS_TOAST",toastId:e});return f({type:"ADD_TOAST",toast:{...t,id:e,open:!0,onOpenChange:t=>{t||a()}}}),{id:e,dismiss:a,update:t=>f({type:"UPDATE_TOAST",toast:{...t,id:e}})}}var v=a(63288),k=a(92736),w=a(986),_=a(79755),N=a(45502),M=a(28427),P=a(45617),$=a(80429),T=a(52801),A=a(28297),S=a(94205),D=a(62657),L=a(69978);function R({dateRange:t,setDateRange:e}){let{currentOutlet:a}=(0,_.P)(),[n,d]=(0,s.useState)(null),[i,o]=(0,s.useState)(!1),[l,c]=(0,s.useState)(!1),[u,m]=(0,s.useState)(!1),{data:h,refetch:p}=(0,w.K9)({outletId:a?.id||1,dateRange:{start_date:(0,T.GP)(t.from,"yyyy-MM-dd"),end_date:(0,T.GP)(t.to,"yyyy-MM-dd")}})(),[x,y]=(0,s.useState)({adjustment:{products:[]},shipment:{products:[]},purchase:{products:[]},sale:{products:[]}}),g=t=>{d(t),o(!0)};return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)(M.Zp,{children:[(0,r.jsxs)(M.aR,{children:[(0,r.jsx)(M.ZB,{children:"Riwayat Stok"}),(0,r.jsxs)(M.BT,{children:["Menampilkan riwayat stok saat ini untuk ",a?a.name:"semua outlet"]})]}),(0,r.jsxs)(M.Wu,{children:[(0,r.jsxs)("div",{className:"flex gap-2",children:[(0,r.jsx)(N.U,{value:t,onChange:t=>{if(!t)return;let{from:a,to:r}=t;a&&r&&a>r?e({from:a,to:a}):r?e(t):e({from:a,to:a}),p()}}),(0,r.jsx)(D.p,{placeholder:"Cari Produk",className:"w-80 mb-4",onChange:t=>{let e=t.target.value.toLowerCase();y({adjustment:{...h?.data.summary_by_type.adjustment,products:h?.data.summary_by_type.adjustment.products?.filter(t=>t.product_name.toLowerCase().includes(e))},shipment:{...h?.data.summary_by_type.shipment,products:h?.data.summary_by_type.shipment.products?.filter(t=>t.product_name.toLowerCase().includes(e))},purchase:{...h?.data.summary_by_type.purchase,products:h?.data.summary_by_type.purchase.products?.filter(t=>t.product_name.toLowerCase().includes(e))},sale:{...h?.data.summary_by_type.sale,products:h?.data.summary_by_type.sale.products?.filter(t=>t.product_name.toLowerCase().includes(e))}})}})]}),l?(0,r.jsx)("div",{className:"flex justify-center items-center h-64",children:(0,r.jsx)(k.A,{className:"h-8 w-8 animate-spin"})}):u?(0,r.jsxs)("div",{className:"text-red-500 text-center py-4",children:["Error: ",u.message]}):h?.data?(0,r.jsx)("div",{className:"space-y-6",children:Object.entries({adjustment:{name:"Penyesuaian",data:x.adjustment},shipment:{name:"Kiriman Pabrik",data:x.shipment},purchase:{name:"Pembelian",data:x.purchase},sale:{name:"Penjualan",data:x.sale}}).map(([t,e])=>(0,r.jsxs)("div",{className:"border rounded-lg",children:[(0,r.jsxs)("div",{className:"p-4 bg-gray-50",children:[(0,r.jsx)("h3",{className:"font-medium",children:e.name}),(0,r.jsxs)("p",{className:"text-sm text-gray-500",children:[e?.data?.products?.length||0," produk"]})]}),(0,r.jsxs)(P.XI,{children:[(0,r.jsx)(P.A0,{children:(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nd,{children:"Produk"}),(0,r.jsx)(P.nd,{children:"SKU"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Stok Akhir Periode"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Total Perubahan"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Total Entri"}),(0,r.jsx)(P.nd,{children:"Aksi"})]})}),(0,r.jsx)(P.BF,{children:e?.data?.products?.map(t=>r.jsxs(P.Hj,{children:[r.jsx(P.nA,{children:r.jsx("div",{children:r.jsx("p",{className:"font-medium",children:t.product_name})})}),r.jsx(P.nA,{children:t.sku}),r.jsxs(P.nA,{className:"text-right",children:[t.stock_as_of_end_date," ",t.unit]}),r.jsx(P.nA,{className:"text-right",children:r.jsxs("span",{className:t.total_quantity_changed>0?"text-green-600":"text-red-600",children:[t.total_quantity_changed>0?"+":"",t.total_quantity_changed]})}),r.jsx(P.nA,{className:"text-right",children:t.total_entries}),r.jsx(P.nA,{children:r.jsx($.$,{variant:"outline",size:"sm",onClick:()=>g(t),children:"Detail"})})]},`product-${t.product_id}`))})]})]},`stock-type-${t}`))}):(0,r.jsx)("div",{className:"text-center py-4",children:"Tidak ada data stok"})]})]}),(0,r.jsx)(S.lG,{open:i,onOpenChange:o,children:(0,r.jsxs)(S.Cf,{className:"sm:max-w-2xl",children:[(0,r.jsxs)(S.c7,{children:[(0,r.jsx)(S.L3,{children:"Detail Riwayat Stok"}),(0,r.jsx)(S.rr,{children:"Informasi lengkap mengenai riwayat stok produk"})]}),(0,r.jsx)(L.F,{className:"h-[calc(80vh-180px)] pr-4",children:n&&(0,r.jsxs)("div",{className:"space-y-4",children:[(0,r.jsxs)("div",{className:"grid grid-cols-2 gap-4",children:[(0,r.jsxs)("div",{children:[(0,r.jsx)("p",{className:"text-sm text-muted-foreground",children:"Nama Produk"}),(0,r.jsx)("p",{className:"font-medium",children:n.product_name})]}),(0,r.jsxs)("div",{children:[(0,r.jsx)("p",{className:"text-sm text-muted-foreground",children:"SKU"}),(0,r.jsx)("p",{children:n.sku||"-"})]}),(0,r.jsxs)("div",{children:[(0,r.jsx)("p",{className:"text-sm text-muted-foreground",children:"Stok Akhir Periode"}),(0,r.jsxs)("p",{className:"font-medium",children:[n.stock_as_of_end_date," ",n.unit]})]}),(0,r.jsxs)("div",{children:[(0,r.jsx)("p",{className:"text-sm text-muted-foreground",children:"Total Perubahan"}),(0,r.jsxs)("p",{className:n.total_quantity_changed>0?"text-green-600":"text-red-600",children:[n.total_quantity_changed>0?"+":"",n.total_quantity_changed]})]}),(0,r.jsxs)("div",{children:[(0,r.jsx)("p",{className:"text-sm text-muted-foreground",children:"Total Entri"}),(0,r.jsx)("p",{children:n.total_entries})]})]}),(0,r.jsxs)("div",{className:"mt-6",children:[(0,r.jsx)("h4",{className:"font-medium mb-2",children:"Detail Entri"}),(0,r.jsx)("div",{className:"border rounded-lg",children:(0,r.jsxs)(P.XI,{children:[(0,r.jsx)(P.A0,{children:(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nd,{children:"Tanggal"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Stok Sebelum"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Stok Sesudah"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Perubahan"}),(0,r.jsx)(P.nd,{children:"Catatan"})]})}),(0,r.jsx)(P.BF,{children:n.entries?.map(t=>r.jsxs(P.Hj,{children:[r.jsx(P.nA,{children:T.GP(new Date(t.created_at),"dd MMM yyyy HH:mm",{locale:A.id})}),r.jsx(P.nA,{className:"text-right",children:t.quantity_before}),r.jsx(P.nA,{className:"text-right",children:t.quantity_after}),r.jsx(P.nA,{className:"text-right",children:r.jsxs("span",{className:t.quantity_change>0?"text-green-600":"text-red-600",children:[t.quantity_change>0?"+":"",t.quantity_change]})}),r.jsx(P.nA,{children:t.notes||"-"})]},`entry-${t.id}`))})]})})]})]})}),(0,r.jsx)(S.Es,{className:"sm:justify-end",children:(0,r.jsx)($.$,{type:"button",variant:"secondary",onClick:()=>o(!1),children:"Tutup"})})]})})]})}function q({dateRange:t,setDateRange:e}){let{currentOutlet:a}=(0,_.P)(),[n,d]=(0,s.useState)(null),[i,o]=(0,s.useState)(!1),[l,c]=(0,s.useState)(null),[u,m]=(0,s.useState)([]),h=async()=>{try{if(!t.from||!t.to)throw Error("Silakan pilih rentang tanggal yang valid");o(!0),c(null);let e=await (0,w.$l)({outletId:a.id,dateRange:{start_date:(0,T.GP)(t.from,"yyyy-MM-dd"),end_date:(0,T.GP)(t.to,"yyyy-MM-dd")}});if(!e.status)throw Error(e.message||"Terjadi kesalahan saat mengambil data");d(e)}catch(t){c(t.message||"Terjadi kesalahan")}finally{o(!1)}};return(0,r.jsxs)(M.Zp,{children:[(0,r.jsxs)(M.aR,{children:[(0,r.jsx)(M.ZB,{children:"Penjualan Per Pelanggan"}),(0,r.jsx)(M.BT,{children:"Data penjualan produk dikelompokkan per pelanggan/member"}),(0,r.jsxs)("div",{className:"flex justify-between items-center mt-4",children:[(0,r.jsx)(N.U,{value:t,onChange:t=>{if(!t)return;let{from:a,to:r}=t;a&&r&&a>r?e({from:a,to:a}):e(t)}}),(0,r.jsx)($.$,{onClick:h,children:"Terapkan"})]})]}),(0,r.jsx)(M.Wu,{children:i?(0,r.jsx)("div",{className:"flex justify-center items-center h-64",children:(0,r.jsx)(k.A,{className:"h-8 w-8 animate-spin"})}):l?(0,r.jsxs)("div",{className:"text-red-500 text-center py-4",children:["Error: ",l.message]}):n?.data?.members?(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(D.p,{placeholder:"Cari member",className:"w-80 mb-4",onChange:t=>{let e=t.target.value.toLowerCase();n?.data?.members&&m(n.data.members.filter(t=>t.member_name.toLowerCase().includes(e)))}}),(0,r.jsx)("div",{className:"space-y-6",children:u.map(t=>(0,r.jsxs)("div",{className:"border rounded-lg",children:[(0,r.jsxs)("div",{className:"p-4 bg-gray-50 flex justify-between items-center",children:[(0,r.jsxs)("div",{children:[(0,r.jsx)("h3",{className:"font-medium",children:t.member_name}),(0,r.jsxs)("p",{className:"text-sm text-gray-500",children:[t.total_orders," transaksi"]})]}),(0,r.jsxs)("div",{className:"text-right",children:[(0,r.jsxs)("p",{className:"font-medium",children:["Rp ",Number(t.total_spent).toLocaleString("id-ID")]}),(0,r.jsxs)("p",{className:"text-sm text-gray-500",children:[t.sales_percentage?.toFixed(2)||"0.00","% dari total"]})]})]}),(0,r.jsxs)(P.XI,{children:[(0,r.jsx)(P.A0,{children:(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nd,{children:"Produk"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Kategori"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Kuantitas"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Penjualan"}),(0,r.jsx)(P.nd,{className:"text-right",children:"% Pelanggan"})]})}),(0,r.jsx)(P.BF,{children:t.products.map(e=>(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nA,{className:"font-medium",children:e.product_name}),(0,r.jsx)(P.nA,{className:"text-right",children:e.category}),(0,r.jsx)(P.nA,{className:"text-right",children:Number(e.quantity)}),(0,r.jsxs)(P.nA,{className:"text-right",children:["Rp ",Number(e.total_spent).toLocaleString("id-ID")]}),(0,r.jsxs)(P.nA,{className:"text-right",children:[(e.total_spent/t.total_spent*100||0).toFixed(2),"%"]})]},e.product_id))})]})]},t.member_id?`member-${t.member_id}`:"member-umum"))})]}):(0,r.jsx)("div",{className:"text-center py-4",children:"Tidak ada data penjualan"})})]})}var E=a(76662),G=a(82984),O=a(72355),I=a(50532),C=a(47808),H=a(58801),K=a(98870),F=a(4631),B=a(60363),W=a(57714),Z=a(54761),z=a(44066),U=a(72382),Y=a(99647),J=a(28070);function V({date:t,setDate:e}){let{currentOutlet:a}=(0,_.P)(),{data:s,isLoading:n}=(0,w.uv)(a?.id??0,t?.from?(0,T.GP)(t.from,"yyyy-MM-dd"):"",t?.to?(0,T.GP)(t.to,"yyyy-MM-dd"):""),d=s||{approved:[],rejected:[]};return(0,r.jsxs)(M.Zp,{children:[(0,r.jsxs)(M.aR,{children:[(0,r.jsx)(M.ZB,{children:"Laporan Persetujuan Penyesuaian Stok"}),(0,r.jsx)(M.BT,{children:"Laporan persetujuan dan penolakan penyesuaian stok"})]}),(0,r.jsxs)(M.Wu,{children:[(0,r.jsx)("div",{className:"flex flex-col sm:flex-row justify-between items-start mb-6 gap-4",children:(0,r.jsxs)(U.AM,{children:[(0,r.jsx)(U.Wv,{asChild:!0,children:(0,r.jsxs)($.$,{variant:"outline",className:(0,J.cn)("justify-start text-left font-normal",!t&&"text-muted-foreground"),children:[(0,r.jsx)(z.A,{className:"mr-2 h-4 w-4"}),t?.from?t.to?(0,r.jsxs)(r.Fragment,{children:[(0,T.GP)(t.from,"dd MMM yyyy",{locale:A.id})," - ",(0,T.GP)(t.to,"dd MMM yyyy",{locale:A.id})]}):(0,T.GP)(t.from,"dd MMM yyyy",{locale:A.id}):(0,r.jsx)("span",{children:"Pilih periode"})]})}),(0,r.jsx)(U.hl,{className:"w-auto p-0",align:"start",children:(0,r.jsx)(Y.V,{initialFocus:!0,mode:"range",defaultMonth:t?.from,selected:t,onSelect:e,numberOfMonths:2})})]})}),(0,r.jsxs)(Z.tU,{defaultValue:"approved",className:"w-full",children:[(0,r.jsxs)(Z.j7,{className:"mb-4",children:[(0,r.jsx)(Z.Xi,{value:"approved",children:"Disetujui"}),(0,r.jsx)(Z.Xi,{value:"rejected",children:"Ditolak"})]}),(0,r.jsx)(Z.av,{value:"approved",children:(0,r.jsx)("div",{className:"overflow-x-auto",children:(0,r.jsxs)(P.XI,{children:[(0,r.jsx)(P.A0,{children:(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nd,{children:"Tanggal"}),(0,r.jsx)(P.nd,{children:"SKU"}),(0,r.jsx)(P.nd,{children:"Nama Item"}),(0,r.jsx)(P.nd,{children:"Perubahan"}),(0,r.jsx)(P.nd,{children:"Keterangan"}),(0,r.jsx)(P.nd,{children:"Disetujui Oleh"})]})}),(0,r.jsx)(P.BF,{children:n?(0,r.jsx)(P.Hj,{children:(0,r.jsx)(P.nA,{colSpan:6,className:"text-center py-4",children:"Memuat data..."})}):d.approved&&d.approved.length>0?d.approved.map(t=>(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nA,{children:t.approved_at?(0,T.GP)(new Date(t.approved_at),"dd MMM yyyy",{locale:A.id}):"-"}),(0,r.jsx)(P.nA,{children:t.product?.sku||"-"}),(0,r.jsx)(P.nA,{children:t.product?.name||"-"}),(0,r.jsx)(P.nA,{className:t.quantity_change>0?"text-green-600":"text-red-600",children:t.quantity_change>0?`+${t.quantity_change}`:t.quantity_change}),(0,r.jsx)(P.nA,{children:t.notes||"-"}),(0,r.jsx)(P.nA,{children:t.approver?.name||"-"})]},t.id)):(0,r.jsx)(P.Hj,{children:(0,r.jsx)(P.nA,{colSpan:6,className:"text-center py-4",children:"Tidak ada data"})})})]})})}),(0,r.jsx)(Z.av,{value:"rejected",children:(0,r.jsx)("div",{className:"overflow-x-auto",children:(0,r.jsxs)(P.XI,{children:[(0,r.jsx)(P.A0,{children:(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nd,{children:"Tanggal"}),(0,r.jsx)(P.nd,{children:"SKU"}),(0,r.jsx)(P.nd,{children:"Nama Item"}),(0,r.jsx)(P.nd,{children:"Perubahan"}),(0,r.jsx)(P.nd,{children:"Keterangan"}),(0,r.jsx)(P.nd,{children:"Ditolak Oleh"})]})}),(0,r.jsx)(P.BF,{children:n?(0,r.jsx)(P.Hj,{children:(0,r.jsx)(P.nA,{colSpan:6,className:"text-center py-4",children:"Memuat data..."})}):d.rejected&&d.rejected.length>0?d.rejected.map(t=>(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nA,{children:t.approved_at?(0,T.GP)(new Date(t.approved_at),"dd MMM yyyy",{locale:A.id}):"-"}),(0,r.jsx)(P.nA,{children:t.product?.sku||"-"}),(0,r.jsx)(P.nA,{children:t.product?.name||"-"}),(0,r.jsx)(P.nA,{className:t.quantity_change>0?"text-green-600":"text-red-600",children:t.quantity_change>0?`+${t.quantity_change}`:t.quantity_change}),(0,r.jsx)(P.nA,{children:t.notes||"-"}),(0,r.jsx)(P.nA,{children:t.approver?.name||"-"})]},t.id)):(0,r.jsx)(P.Hj,{children:(0,r.jsx)(P.nA,{colSpan:6,className:"text-center py-4",children:"Tidak ada data"})})})]})})})]})]})]})}var X=a(21786),Q=a(62812),tt=a(15236),te=a(4889),ta=a(15481),tr=a(89900),ts=a(24827);class tn{validate(t,e){return!0}constructor(){this.subPriority=0}}class td extends tn{constructor(t,e,a,r,s){super(),this.value=t,this.validateValue=e,this.setValue=a,this.priority=r,s&&(this.subPriority=s)}validate(t,e){return this.validateValue(t,this.value,e)}set(t,e,a){return this.setValue(t,e,this.value,a)}}class ti extends tn{constructor(t,e){super(),this.priority=10,this.subPriority=-1,this.context=t||(t=>(0,ta.w)(e,t))}set(t,e){return e.timestampIsSet?t:(0,ta.w)(t,function(t,e){let a="function"==typeof e&&e.prototype?.constructor===e?new e(0):(0,ta.w)(e,0);return a.setFullYear(t.getFullYear(),t.getMonth(),t.getDate()),a.setHours(t.getHours(),t.getMinutes(),t.getSeconds(),t.getMilliseconds()),a}(t,this.context))}}class to{run(t,e,a,r){let s=this.parse(t,e,a,r);return s?{setter:new td(s.value,this.validate,this.set,this.priority,this.subPriority),rest:s.rest}:null}validate(t,e,a){return!0}}class tl extends to{parse(t,e,a){switch(e){case"G":case"GG":case"GGG":return a.era(t,{width:"abbreviated"})||a.era(t,{width:"narrow"});case"GGGGG":return a.era(t,{width:"narrow"});default:return a.era(t,{width:"wide"})||a.era(t,{width:"abbreviated"})||a.era(t,{width:"narrow"})}}set(t,e,a){return e.era=a,t.setFullYear(a,0,1),t.setHours(0,0,0,0),t}constructor(...t){super(...t),this.priority=140,this.incompatibleTokens=["R","u","t","T"]}}var tc=a(89277);let tu={month:/^(1[0-2]|0?\d)/,date:/^(3[0-1]|[0-2]?\d)/,dayOfYear:/^(36[0-6]|3[0-5]\d|[0-2]?\d?\d)/,week:/^(5[0-3]|[0-4]?\d)/,hour23h:/^(2[0-3]|[0-1]?\d)/,hour24h:/^(2[0-4]|[0-1]?\d)/,hour11h:/^(1[0-1]|0?\d)/,hour12h:/^(1[0-2]|0?\d)/,minute:/^[0-5]?\d/,second:/^[0-5]?\d/,singleDigit:/^\d/,twoDigits:/^\d{1,2}/,threeDigits:/^\d{1,3}/,fourDigits:/^\d{1,4}/,anyDigitsSigned:/^-?\d+/,singleDigitSigned:/^-?\d/,twoDigitsSigned:/^-?\d{1,2}/,threeDigitsSigned:/^-?\d{1,3}/,fourDigitsSigned:/^-?\d{1,4}/},tm={basicOptionalMinutes:/^([+-])(\d{2})(\d{2})?|Z/,basic:/^([+-])(\d{2})(\d{2})|Z/,basicOptionalSeconds:/^([+-])(\d{2})(\d{2})((\d{2}))?|Z/,extended:/^([+-])(\d{2}):(\d{2})|Z/,extendedOptionalSeconds:/^([+-])(\d{2}):(\d{2})(:(\d{2}))?|Z/};function th(t,e){return t?{value:e(t.value),rest:t.rest}:t}function tp(t,e){let a=e.match(t);return a?{value:parseInt(a[0],10),rest:e.slice(a[0].length)}:null}function tx(t,e){let a=e.match(t);if(!a)return null;if("Z"===a[0])return{value:0,rest:e.slice(1)};let r="+"===a[1]?1:-1,s=a[2]?parseInt(a[2],10):0,n=a[3]?parseInt(a[3],10):0,d=a[5]?parseInt(a[5],10):0;return{value:r*(s*tc.s0+n*tc.Cg+d*tc._m),rest:e.slice(a[0].length)}}function ty(t){return tp(tu.anyDigitsSigned,t)}function tg(t,e){switch(t){case 1:return tp(tu.singleDigit,e);case 2:return tp(tu.twoDigits,e);case 3:return tp(tu.threeDigits,e);case 4:return tp(tu.fourDigits,e);default:return tp(RegExp("^\\d{1,"+t+"}"),e)}}function tb(t,e){switch(t){case 1:return tp(tu.singleDigitSigned,e);case 2:return tp(tu.twoDigitsSigned,e);case 3:return tp(tu.threeDigitsSigned,e);case 4:return tp(tu.fourDigitsSigned,e);default:return tp(RegExp("^-?\\d{1,"+t+"}"),e)}}function tf(t){switch(t){case"morning":return 4;case"evening":return 17;case"pm":case"noon":case"afternoon":return 12;default:return 0}}function tj(t,e){let a;let r=e>0,s=r?e:1-e;if(s<=50)a=t||100;else{let e=s+50;a=t+100*Math.trunc(e/100)-(t>=e%100?100:0)}return r?a:1-a}function tv(t){return t%400==0||t%4==0&&t%100!=0}class tk extends to{parse(t,e,a){let r=t=>({year:t,isTwoDigitYear:"yy"===e});switch(e){case"y":return th(tg(4,t),r);case"yo":return th(a.ordinalNumber(t,{unit:"year"}),r);default:return th(tg(e.length,t),r)}}validate(t,e){return e.isTwoDigitYear||e.year>0}set(t,e,a){let r=t.getFullYear();if(a.isTwoDigitYear){let e=tj(a.year,r);return t.setFullYear(e,0,1),t.setHours(0,0,0,0),t}let s="era"in e&&1!==e.era?1-a.year:a.year;return t.setFullYear(s,0,1),t.setHours(0,0,0,0),t}constructor(...t){super(...t),this.priority=130,this.incompatibleTokens=["Y","R","u","w","I","i","e","c","t","T"]}}var tw=a(30293),t_=a(75529);class tN extends to{parse(t,e,a){let r=t=>({year:t,isTwoDigitYear:"YY"===e});switch(e){case"Y":return th(tg(4,t),r);case"Yo":return th(a.ordinalNumber(t,{unit:"year"}),r);default:return th(tg(e.length,t),r)}}validate(t,e){return e.isTwoDigitYear||e.year>0}set(t,e,a,r){let s=(0,tw.h)(t,r);if(a.isTwoDigitYear){let e=tj(a.year,s);return t.setFullYear(e,0,r.firstWeekContainsDate),t.setHours(0,0,0,0),(0,t_.k)(t,r)}let n="era"in e&&1!==e.era?1-a.year:a.year;return t.setFullYear(n,0,r.firstWeekContainsDate),t.setHours(0,0,0,0),(0,t_.k)(t,r)}constructor(...t){super(...t),this.priority=130,this.incompatibleTokens=["y","R","u","Q","q","M","L","I","d","D","i","t","T"]}}var tM=a(49784);class tP extends to{parse(t,e){return"R"===e?tb(4,t):tb(e.length,t)}set(t,e,a){let r=(0,ta.w)(t,0);return r.setFullYear(a,0,4),r.setHours(0,0,0,0),(0,tM.b)(r)}constructor(...t){super(...t),this.priority=130,this.incompatibleTokens=["G","y","Y","u","Q","q","M","L","w","d","D","e","c","t","T"]}}class t$ extends to{parse(t,e){return"u"===e?tb(4,t):tb(e.length,t)}set(t,e,a){return t.setFullYear(a,0,1),t.setHours(0,0,0,0),t}constructor(...t){super(...t),this.priority=130,this.incompatibleTokens=["G","y","Y","R","w","I","i","e","c","t","T"]}}class tT extends to{parse(t,e,a){switch(e){case"Q":case"QQ":return tg(e.length,t);case"Qo":return a.ordinalNumber(t,{unit:"quarter"});case"QQQ":return a.quarter(t,{width:"abbreviated",context:"formatting"})||a.quarter(t,{width:"narrow",context:"formatting"});case"QQQQQ":return a.quarter(t,{width:"narrow",context:"formatting"});default:return a.quarter(t,{width:"wide",context:"formatting"})||a.quarter(t,{width:"abbreviated",context:"formatting"})||a.quarter(t,{width:"narrow",context:"formatting"})}}validate(t,e){return e>=1&&e<=4}set(t,e,a){return t.setMonth((a-1)*3,1),t.setHours(0,0,0,0),t}constructor(...t){super(...t),this.priority=120,this.incompatibleTokens=["Y","R","q","M","L","w","I","d","D","i","e","c","t","T"]}}class tA extends to{parse(t,e,a){switch(e){case"q":case"qq":return tg(e.length,t);case"qo":return a.ordinalNumber(t,{unit:"quarter"});case"qqq":return a.quarter(t,{width:"abbreviated",context:"standalone"})||a.quarter(t,{width:"narrow",context:"standalone"});case"qqqqq":return a.quarter(t,{width:"narrow",context:"standalone"});default:return a.quarter(t,{width:"wide",context:"standalone"})||a.quarter(t,{width:"abbreviated",context:"standalone"})||a.quarter(t,{width:"narrow",context:"standalone"})}}validate(t,e){return e>=1&&e<=4}set(t,e,a){return t.setMonth((a-1)*3,1),t.setHours(0,0,0,0),t}constructor(...t){super(...t),this.priority=120,this.incompatibleTokens=["Y","R","Q","M","L","w","I","d","D","i","e","c","t","T"]}}class tS extends to{parse(t,e,a){let r=t=>t-1;switch(e){case"M":return th(tp(tu.month,t),r);case"MM":return th(tg(2,t),r);case"Mo":return th(a.ordinalNumber(t,{unit:"month"}),r);case"MMM":return a.month(t,{width:"abbreviated",context:"formatting"})||a.month(t,{width:"narrow",context:"formatting"});case"MMMMM":return a.month(t,{width:"narrow",context:"formatting"});default:return a.month(t,{width:"wide",context:"formatting"})||a.month(t,{width:"abbreviated",context:"formatting"})||a.month(t,{width:"narrow",context:"formatting"})}}validate(t,e){return e>=0&&e<=11}set(t,e,a){return t.setMonth(a,1),t.setHours(0,0,0,0),t}constructor(...t){super(...t),this.incompatibleTokens=["Y","R","q","Q","L","w","I","D","i","e","c","t","T"],this.priority=110}}class tD extends to{parse(t,e,a){let r=t=>t-1;switch(e){case"L":return th(tp(tu.month,t),r);case"LL":return th(tg(2,t),r);case"Lo":return th(a.ordinalNumber(t,{unit:"month"}),r);case"LLL":return a.month(t,{width:"abbreviated",context:"standalone"})||a.month(t,{width:"narrow",context:"standalone"});case"LLLLL":return a.month(t,{width:"narrow",context:"standalone"});default:return a.month(t,{width:"wide",context:"standalone"})||a.month(t,{width:"abbreviated",context:"standalone"})||a.month(t,{width:"narrow",context:"standalone"})}}validate(t,e){return e>=0&&e<=11}set(t,e,a){return t.setMonth(a,1),t.setHours(0,0,0,0),t}constructor(...t){super(...t),this.priority=110,this.incompatibleTokens=["Y","R","q","Q","M","w","I","D","i","e","c","t","T"]}}var tL=a(35973);class tR extends to{parse(t,e,a){switch(e){case"w":return tp(tu.week,t);case"wo":return a.ordinalNumber(t,{unit:"week"});default:return tg(e.length,t)}}validate(t,e){return e>=1&&e<=53}set(t,e,a,r){return(0,t_.k)(function(t,e,a){let r=(0,ts.a)(t,a?.in),s=(0,tL.N)(r,a)-e;return r.setDate(r.getDate()-7*s),(0,ts.a)(r,a?.in)}(t,a,r),r)}constructor(...t){super(...t),this.priority=100,this.incompatibleTokens=["y","R","u","q","Q","M","L","I","d","D","i","t","T"]}}var tq=a(65627);class tE extends to{parse(t,e,a){switch(e){case"I":return tp(tu.week,t);case"Io":return a.ordinalNumber(t,{unit:"week"});default:return tg(e.length,t)}}validate(t,e){return e>=1&&e<=53}set(t,e,a){return(0,tM.b)(function(t,e,a){let r=(0,ts.a)(t,void 0),s=(0,tq.s)(r,void 0)-e;return r.setDate(r.getDate()-7*s),r}(t,a))}constructor(...t){super(...t),this.priority=100,this.incompatibleTokens=["y","Y","u","q","Q","M","L","w","d","D","e","c","t","T"]}}let tG=[31,28,31,30,31,30,31,31,30,31,30,31],tO=[31,29,31,30,31,30,31,31,30,31,30,31];class tI extends to{parse(t,e,a){switch(e){case"d":return tp(tu.date,t);case"do":return a.ordinalNumber(t,{unit:"date"});default:return tg(e.length,t)}}validate(t,e){let a=tv(t.getFullYear()),r=t.getMonth();return a?e>=1&&e<=tO[r]:e>=1&&e<=tG[r]}set(t,e,a){return t.setDate(a),t.setHours(0,0,0,0),t}constructor(...t){super(...t),this.priority=90,this.subPriority=1,this.incompatibleTokens=["Y","R","q","Q","w","I","D","i","e","c","t","T"]}}class tC extends to{parse(t,e,a){switch(e){case"D":case"DD":return tp(tu.dayOfYear,t);case"Do":return a.ordinalNumber(t,{unit:"date"});default:return tg(e.length,t)}}validate(t,e){return tv(t.getFullYear())?e>=1&&e<=366:e>=1&&e<=365}set(t,e,a){return t.setMonth(0,a),t.setHours(0,0,0,0),t}constructor(...t){super(...t),this.priority=90,this.subpriority=1,this.incompatibleTokens=["Y","R","q","Q","M","L","w","I","d","E","i","e","c","t","T"]}}var tH=a(46116);function tK(t,e,a){let r=(0,tr.q)(),s=a?.weekStartsOn??a?.locale?.options?.weekStartsOn??r.weekStartsOn??r.locale?.options?.weekStartsOn??0,n=(0,ts.a)(t,a?.in),d=n.getDay(),i=7-s;return(0,tH.f)(n,e<0||e>6?e-(d+i)%7:((e%7+7)%7+i)%7-(d+i)%7,a)}class tF extends to{parse(t,e,a){switch(e){case"E":case"EE":case"EEE":return a.day(t,{width:"abbreviated",context:"formatting"})||a.day(t,{width:"short",context:"formatting"})||a.day(t,{width:"narrow",context:"formatting"});case"EEEEE":return a.day(t,{width:"narrow",context:"formatting"});case"EEEEEE":return a.day(t,{width:"short",context:"formatting"})||a.day(t,{width:"narrow",context:"formatting"});default:return a.day(t,{width:"wide",context:"formatting"})||a.day(t,{width:"abbreviated",context:"formatting"})||a.day(t,{width:"short",context:"formatting"})||a.day(t,{width:"narrow",context:"formatting"})}}validate(t,e){return e>=0&&e<=6}set(t,e,a,r){return(t=tK(t,a,r)).setHours(0,0,0,0),t}constructor(...t){super(...t),this.priority=90,this.incompatibleTokens=["D","i","e","c","t","T"]}}class tB extends to{parse(t,e,a,r){let s=t=>{let e=7*Math.floor((t-1)/7);return(t+r.weekStartsOn+6)%7+e};switch(e){case"e":case"ee":return th(tg(e.length,t),s);case"eo":return th(a.ordinalNumber(t,{unit:"day"}),s);case"eee":return a.day(t,{width:"abbreviated",context:"formatting"})||a.day(t,{width:"short",context:"formatting"})||a.day(t,{width:"narrow",context:"formatting"});case"eeeee":return a.day(t,{width:"narrow",context:"formatting"});case"eeeeee":return a.day(t,{width:"short",context:"formatting"})||a.day(t,{width:"narrow",context:"formatting"});default:return a.day(t,{width:"wide",context:"formatting"})||a.day(t,{width:"abbreviated",context:"formatting"})||a.day(t,{width:"short",context:"formatting"})||a.day(t,{width:"narrow",context:"formatting"})}}validate(t,e){return e>=0&&e<=6}set(t,e,a,r){return(t=tK(t,a,r)).setHours(0,0,0,0),t}constructor(...t){super(...t),this.priority=90,this.incompatibleTokens=["y","R","u","q","Q","M","L","I","d","D","E","i","c","t","T"]}}class tW extends to{parse(t,e,a,r){let s=t=>{let e=7*Math.floor((t-1)/7);return(t+r.weekStartsOn+6)%7+e};switch(e){case"c":case"cc":return th(tg(e.length,t),s);case"co":return th(a.ordinalNumber(t,{unit:"day"}),s);case"ccc":return a.day(t,{width:"abbreviated",context:"standalone"})||a.day(t,{width:"short",context:"standalone"})||a.day(t,{width:"narrow",context:"standalone"});case"ccccc":return a.day(t,{width:"narrow",context:"standalone"});case"cccccc":return a.day(t,{width:"short",context:"standalone"})||a.day(t,{width:"narrow",context:"standalone"});default:return a.day(t,{width:"wide",context:"standalone"})||a.day(t,{width:"abbreviated",context:"standalone"})||a.day(t,{width:"short",context:"standalone"})||a.day(t,{width:"narrow",context:"standalone"})}}validate(t,e){return e>=0&&e<=6}set(t,e,a,r){return(t=tK(t,a,r)).setHours(0,0,0,0),t}constructor(...t){super(...t),this.priority=90,this.incompatibleTokens=["y","R","u","q","Q","M","L","I","d","D","E","i","e","t","T"]}}class tZ extends to{parse(t,e,a){let r=t=>0===t?7:t;switch(e){case"i":case"ii":return tg(e.length,t);case"io":return a.ordinalNumber(t,{unit:"day"});case"iii":return th(a.day(t,{width:"abbreviated",context:"formatting"})||a.day(t,{width:"short",context:"formatting"})||a.day(t,{width:"narrow",context:"formatting"}),r);case"iiiii":return th(a.day(t,{width:"narrow",context:"formatting"}),r);case"iiiiii":return th(a.day(t,{width:"short",context:"formatting"})||a.day(t,{width:"narrow",context:"formatting"}),r);default:return th(a.day(t,{width:"wide",context:"formatting"})||a.day(t,{width:"abbreviated",context:"formatting"})||a.day(t,{width:"short",context:"formatting"})||a.day(t,{width:"narrow",context:"formatting"}),r)}}validate(t,e){return e>=1&&e<=7}set(t,e,a){return(t=function(t,e,a){let r=(0,ts.a)(t,void 0),s=function(t,e){let a=(0,ts.a)(t,e?.in).getDay();return 0===a?7:a}(r,void 0);return(0,tH.f)(r,e-s,void 0)}(t,a)).setHours(0,0,0,0),t}constructor(...t){super(...t),this.priority=90,this.incompatibleTokens=["y","Y","u","q","Q","M","L","w","d","D","E","e","c","t","T"]}}class tz extends to{parse(t,e,a){switch(e){case"a":case"aa":case"aaa":return a.dayPeriod(t,{width:"abbreviated",context:"formatting"})||a.dayPeriod(t,{width:"narrow",context:"formatting"});case"aaaaa":return a.dayPeriod(t,{width:"narrow",context:"formatting"});default:return a.dayPeriod(t,{width:"wide",context:"formatting"})||a.dayPeriod(t,{width:"abbreviated",context:"formatting"})||a.dayPeriod(t,{width:"narrow",context:"formatting"})}}set(t,e,a){return t.setHours(tf(a),0,0,0),t}constructor(...t){super(...t),this.priority=80,this.incompatibleTokens=["b","B","H","k","t","T"]}}class tU extends to{parse(t,e,a){switch(e){case"b":case"bb":case"bbb":return a.dayPeriod(t,{width:"abbreviated",context:"formatting"})||a.dayPeriod(t,{width:"narrow",context:"formatting"});case"bbbbb":return a.dayPeriod(t,{width:"narrow",context:"formatting"});default:return a.dayPeriod(t,{width:"wide",context:"formatting"})||a.dayPeriod(t,{width:"abbreviated",context:"formatting"})||a.dayPeriod(t,{width:"narrow",context:"formatting"})}}set(t,e,a){return t.setHours(tf(a),0,0,0),t}constructor(...t){super(...t),this.priority=80,this.incompatibleTokens=["a","B","H","k","t","T"]}}class tY extends to{parse(t,e,a){switch(e){case"B":case"BB":case"BBB":return a.dayPeriod(t,{width:"abbreviated",context:"formatting"})||a.dayPeriod(t,{width:"narrow",context:"formatting"});case"BBBBB":return a.dayPeriod(t,{width:"narrow",context:"formatting"});default:return a.dayPeriod(t,{width:"wide",context:"formatting"})||a.dayPeriod(t,{width:"abbreviated",context:"formatting"})||a.dayPeriod(t,{width:"narrow",context:"formatting"})}}set(t,e,a){return t.setHours(tf(a),0,0,0),t}constructor(...t){super(...t),this.priority=80,this.incompatibleTokens=["a","b","t","T"]}}class tJ extends to{parse(t,e,a){switch(e){case"h":return tp(tu.hour12h,t);case"ho":return a.ordinalNumber(t,{unit:"hour"});default:return tg(e.length,t)}}validate(t,e){return e>=1&&e<=12}set(t,e,a){let r=t.getHours()>=12;return r&&a<12?t.setHours(a+12,0,0,0):r||12!==a?t.setHours(a,0,0,0):t.setHours(0,0,0,0),t}constructor(...t){super(...t),this.priority=70,this.incompatibleTokens=["H","K","k","t","T"]}}class tV extends to{parse(t,e,a){switch(e){case"H":return tp(tu.hour23h,t);case"Ho":return a.ordinalNumber(t,{unit:"hour"});default:return tg(e.length,t)}}validate(t,e){return e>=0&&e<=23}set(t,e,a){return t.setHours(a,0,0,0),t}constructor(...t){super(...t),this.priority=70,this.incompatibleTokens=["a","b","h","K","k","t","T"]}}class tX extends to{parse(t,e,a){switch(e){case"K":return tp(tu.hour11h,t);case"Ko":return a.ordinalNumber(t,{unit:"hour"});default:return tg(e.length,t)}}validate(t,e){return e>=0&&e<=11}set(t,e,a){return t.getHours()>=12&&a<12?t.setHours(a+12,0,0,0):t.setHours(a,0,0,0),t}constructor(...t){super(...t),this.priority=70,this.incompatibleTokens=["h","H","k","t","T"]}}class tQ extends to{parse(t,e,a){switch(e){case"k":return tp(tu.hour24h,t);case"ko":return a.ordinalNumber(t,{unit:"hour"});default:return tg(e.length,t)}}validate(t,e){return e>=1&&e<=24}set(t,e,a){return t.setHours(a<=24?a%24:a,0,0,0),t}constructor(...t){super(...t),this.priority=70,this.incompatibleTokens=["a","b","h","H","K","t","T"]}}class t0 extends to{parse(t,e,a){switch(e){case"m":return tp(tu.minute,t);case"mo":return a.ordinalNumber(t,{unit:"minute"});default:return tg(e.length,t)}}validate(t,e){return e>=0&&e<=59}set(t,e,a){return t.setMinutes(a,0,0),t}constructor(...t){super(...t),this.priority=60,this.incompatibleTokens=["t","T"]}}class t1 extends to{parse(t,e,a){switch(e){case"s":return tp(tu.second,t);case"so":return a.ordinalNumber(t,{unit:"second"});default:return tg(e.length,t)}}validate(t,e){return e>=0&&e<=59}set(t,e,a){return t.setSeconds(a,0),t}constructor(...t){super(...t),this.priority=50,this.incompatibleTokens=["t","T"]}}class t2 extends to{parse(t,e){return th(tg(e.length,t),t=>Math.trunc(t*Math.pow(10,-e.length+3)))}set(t,e,a){return t.setMilliseconds(a),t}constructor(...t){super(...t),this.priority=30,this.incompatibleTokens=["t","T"]}}var t5=a(77436);class t3 extends to{parse(t,e){switch(e){case"X":return tx(tm.basicOptionalMinutes,t);case"XX":return tx(tm.basic,t);case"XXXX":return tx(tm.basicOptionalSeconds,t);case"XXXXX":return tx(tm.extendedOptionalSeconds,t);default:return tx(tm.extended,t)}}set(t,e,a){return e.timestampIsSet?t:(0,ta.w)(t,t.getTime()-(0,t5.G)(t)-a)}constructor(...t){super(...t),this.priority=10,this.incompatibleTokens=["t","T","x"]}}class t4 extends to{parse(t,e){switch(e){case"x":return tx(tm.basicOptionalMinutes,t);case"xx":return tx(tm.basic,t);case"xxxx":return tx(tm.basicOptionalSeconds,t);case"xxxxx":return tx(tm.extendedOptionalSeconds,t);default:return tx(tm.extended,t)}}set(t,e,a){return e.timestampIsSet?t:(0,ta.w)(t,t.getTime()-(0,t5.G)(t)-a)}constructor(...t){super(...t),this.priority=10,this.incompatibleTokens=["t","T","X"]}}class t6 extends to{parse(t){return ty(t)}set(t,e,a){return[(0,ta.w)(t,1e3*a),{timestampIsSet:!0}]}constructor(...t){super(...t),this.priority=40,this.incompatibleTokens="*"}}class t8 extends to{parse(t){return ty(t)}set(t,e,a){return[(0,ta.w)(t,a),{timestampIsSet:!0}]}constructor(...t){super(...t),this.priority=20,this.incompatibleTokens="*"}}let t7={G:new tl,y:new tk,Y:new tN,R:new tP,u:new t$,Q:new tT,q:new tA,M:new tS,L:new tD,w:new tR,I:new tE,d:new tI,D:new tC,E:new tF,e:new tB,c:new tW,i:new tZ,a:new tz,b:new tU,B:new tY,h:new tJ,H:new tV,K:new tX,k:new tQ,m:new t0,s:new t1,S:new t2,X:new t3,x:new t4,t:new t6,T:new t8},t9=/[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g,et=/P+p+|P+|p+|''|'(''|[^'])+('|$)|./g,ee=/^'([^]*?)'?$/,ea=/''/g,er=/\S/,es=/[a-zA-Z]/;var en=a(41559);let ed=t=>{let e={};return t.forEach(t=>{let a=function(t,e,a,r){let s=()=>(0,ta.w)(a,NaN),n=Object.assign({},(0,tr.q)()),d=(void 0)??n.locale??Q.c,i=(void 0)??r?.locale?.options?.firstWeekContainsDate??n.firstWeekContainsDate??n.locale?.options?.firstWeekContainsDate??1,o=r?.weekStartsOn??r?.locale?.options?.weekStartsOn??n.weekStartsOn??n.locale?.options?.weekStartsOn??0;if(!e)return t?s():(0,ts.a)(a,r?.in);let l={firstWeekContainsDate:i,weekStartsOn:o,locale:d},c=[new ti(r?.in,a)],u=e.match(et).map(t=>{let e=t[0];return e in tt.m?(0,tt.m[e])(t,d.formatLong):t}).join("").match(t9),m=[];for(let a of u){!r?.useAdditionalWeekYearTokens&&(0,te.xM)(a)&&(0,te.Ss)(a,e,t),!r?.useAdditionalDayOfYearTokens&&(0,te.ef)(a)&&(0,te.Ss)(a,e,t);let n=a[0],i=t7[n];if(i){let{incompatibleTokens:e}=i;if(Array.isArray(e)){let t=m.find(t=>e.includes(t.token)||t.token===n);if(t)throw RangeError(`The format string mustn't contain \`${t.fullToken}\` and \`${a}\` at the same time`)}else if("*"===i.incompatibleTokens&&m.length>0)throw RangeError(`The format string mustn't contain \`${a}\` and any other token at the same time`);m.push({token:n,fullToken:a});let r=i.run(t,a,d.match,l);if(!r)return s();c.push(r.setter),t=r.rest}else{if(n.match(es))throw RangeError("Format string contains an unescaped latin alphabet character `"+n+"`");if("''"===a?a="'":"'"===n&&(a=a.match(ee)[1].replace(ea,"'")),0!==t.indexOf(a))return s();t=t.slice(a.length)}}if(t.length>0&&er.test(t))return s();let h=c.map(t=>t.priority).sort((t,e)=>e-t).filter((t,e,a)=>a.indexOf(t)===e).map(t=>c.filter(e=>e.priority===t).sort((t,e)=>e.subPriority-t.subPriority)).map(t=>t[0]),p=(0,ts.a)(a,r?.in);if(isNaN(+p))return s();let x={};for(let t of h){if(!t.validate(p,l))return s();let e=t.set(p,x,l);Array.isArray(e)?(p=e[0],Object.assign(x,e[1])):p=e}return p}(t.created_at,"dd/MM/yyyy HH:mm",new Date),r=(0,T.GP)(a,"dd/MM/yyyy");e[r]||(e[r]=[]),e[r].push(t)}),e};function ei({dateRange:t,setDateRange:e}){let{currentOutlet:a}=(0,_.P)(),[n,i]=(0,s.useState)(""),{data:o,isLoading:l,error:c}=(0,X.Ib)(a?.id,(0,T.GP)(t?.from??new Date,"yyyy-MM-dd"),(0,T.GP)(t?.to??new Date,"yyyy-MM-dd"))(),u=ed(o?.data.orders.filter(t=>{let e=n.toLowerCase(),a=t.order_number.toLowerCase().includes(e),r=t.items.some(t=>t.product.toLowerCase().includes(e));return a||r})||[]);return(0,r.jsx)(r.Fragment,{children:(0,r.jsxs)(M.Zp,{children:[(0,r.jsxs)(M.aR,{children:[(0,r.jsx)(M.ZB,{children:"Analisis Penjualan"}),(0,r.jsxs)(M.BT,{children:["Detail penjualan per hari",a&&` untuk ${a.name}`]})]}),(0,r.jsxs)(M.Wu,{className:"space-y-4",children:[(0,r.jsx)("div",{className:"flex items-center space-x-4",children:(0,r.jsxs)("div",{className:"grid grid-cols-2 gap-4",children:[(0,r.jsx)(N.U,{value:t,onChange:e}),(0,r.jsx)(D.p,{placeholder:"Cari invoice/produk",value:n,onChange:t=>{i(t.target.value)}})]})}),o?.data.total_orders&&(0,r.jsxs)("div",{className:"grid grid-cols-4 gap-4",children:[(0,r.jsxs)("div",{className:"rounded-lg border p-4",children:[(0,r.jsx)("h3",{className:"text-sm font-medium",children:"Total Penjualan"}),(0,r.jsxs)("p",{className:"text-2xl font-bold",children:["Rp ",Number(o.data.total_revenue).toLocaleString()]})]}),(0,r.jsxs)("div",{className:"rounded-lg border p-4",children:[(0,r.jsx)("h3",{className:"text-sm font-medium",children:"Total Order"}),(0,r.jsx)("p",{className:"text-2xl font-bold",children:o.data.total_orders})]}),(0,r.jsxs)("div",{className:"rounded-lg border p-4",children:[(0,r.jsx)("h3",{className:"text-sm font-medium",children:"Total Item"}),(0,r.jsx)("p",{className:"text-2xl font-bold",children:o.data.total_items_sold})]}),(0,r.jsxs)("div",{className:"rounded-lg border p-4",children:[(0,r.jsx)("h3",{className:"text-sm font-medium",children:"Rata-rata Order"}),(0,r.jsxs)("p",{className:"text-2xl font-bold",children:["Rp ",o.data.average_order_value.toLocaleString()]})]})]}),Object.entries(u).map(([t,e])=>(0,r.jsxs)("div",{className:"space-y-4",children:[(0,r.jsx)("h3",{className:"text-lg font-semibold",children:t}),(0,r.jsxs)(P.XI,{children:[(0,r.jsx)(P.A0,{children:(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nd,{children:"Invoice"}),(0,r.jsx)(P.nd,{children:"Waktu"}),(0,r.jsx)(P.nd,{children:"Kasir"}),(0,r.jsx)(P.nd,{children:"Metode Pembayaran"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Total"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Aksi"})]})}),(0,r.jsx)(P.BF,{children:e.map(t=>(0,r.jsxs)(P.Hj,{children:[(0,r.jsxs)(P.nA,{children:["#",t.order_number]}),(0,r.jsx)(P.nA,{children:t.created_at.split(" ")[1]}),(0,r.jsx)(P.nA,{children:t.user}),(0,r.jsx)(P.nA,{children:(0,r.jsx)(d.E,{variant:"outline",children:"cash"===t.payment_method?"Tunai":"transfer"===t.payment_method?"Transfer":"Qris"})}),(0,r.jsxs)(P.nA,{className:"text-right",children:["Rp ",Number(t.total).toLocaleString()]}),(0,r.jsx)(P.nA,{className:"text-right",children:(0,r.jsx)(en.A,{trx:t})})]},t.order_number))})]})]},t))]})]})})}function eo(){let{currentOutlet:t,outlets:e}=(0,_.P)(),a=(0,W.useSearchParams)(),o=(0,W.useRouter)(),h=a.get("tab")||"overview",[p,x]=(0,s.useState)(new Date),[y,g]=(0,s.useState)("1"),[b,f]=(0,s.useState)(!1),[S,L]=(0,s.useState)(null),[z,U]=(0,s.useState)(new Date),[Y,J]=(0,s.useState)([]),[Q,tt]=(0,s.useState)(""),[te,ta]=(0,s.useState)([]),[tr,ts]=(0,s.useState)([]),[tn,td]=(0,s.useState)([]),[ti,to]=(0,s.useState)(null),[tl,tc]=(0,s.useState)({from:new Date(new Date().setDate(1)),to:new Date}),[tu,tm]=(0,s.useState)({from:new Date(new Date().setDate(1)),to:new Date}),[th,tp]=(0,s.useState)({from:new Date(new Date().setDate(1)),to:new Date}),[tx,ty]=(0,s.useState)({from:new Date(new Date().setDate(1)),to:new Date}),[tg,tb]=(0,s.useState)({from:new Date(new Date().setDate(1)),to:new Date}),[tf,tj]=(0,s.useState)({from:new Date(new Date().setDate(1)),to:new Date}),{data:tv}=(0,v.I)((0,w.Ke)(1,th)),{data:tk}=(0,X.Ib)(t?.id,(0,T.GP)(tg?.from??new Date,"yyyy-MM-dd"),(0,T.GP)(tg?.to??new Date,"yyyy-MM-dd"))(),{data:tw,refetch:t_}=(0,v.I)({...(0,w.gQ)(1,(0,T.GP)(tu?.from,"yyyy-MM-dd"),(0,T.GP)(tu?.to,"yyyy-MM-dd"))}),tN=t=>{tp(t)},[tM,tP]=(0,s.useState)({data:{products:[],summary:{total_saldo_awal:0,total_stock_masuk:0,total_stock_keluar:0,total_stock_akhir:0},periode:{start_date:"",end_date:""},outlet:""}}),t$=t=>{let e=t.target.value.toLowerCase();if(!Y)return;let a=Y.filter(t=>t.product_name.toLowerCase().includes(e)),r=tM.data.products.filter(t=>t.product_name.toLowerCase().includes(e));td(tv?.data.categories.filter(t=>t.category_name.toLowerCase().includes(e))),ts(r),ta(a)},tT=(0,n.getCookie)("access_token"),tA=()=>{let e=document.createElement("iframe");e.style.position="absolute",e.style.top="-1000px",e.style.left="-1000px",document.body.appendChild(e);let a=(0,T.GP)(new Date,"dd/MM/yy - dd/MM/yy",{locale:A.id}),r=t?t.name:"Semua Outlet",s=tM.data?.periode?`${(0,T.GP)(new Date(tM.data.periode.start_date),"dd/MM/yy")} - ${(0,T.GP)(new Date(tM.data.periode.end_date),"dd/MM/yy")}`:(0,T.GP)(z,"dd/MM/yy",{locale:A.id}),n=`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Daftar Jual Per Item Per Pelanggan</title>
      <style>
        body { 
          font-family: Arial, sans-serif; 
          padding: 15px;
          color: #333;
        }
        .header { 
          display: flex;
          margin-bottom: 20px;
          padding-bottom: 15px;
          border-bottom: 1px solid #000;
        }
        .logo-container {
          width: 80px;
          height: 80px; /* tambahkan tinggi tetap */
          margin-right: 15px;
          display: flex;
          align-items: center; /* pusatkan vertikal */
        }
        .logo {
          max-width: 100%;
          height: auto;
          object-fit: contain;
          opacity: 0.8;
        }
        .header-content {
          flex-grow: 1;
        }
        .title { 
          font-size: 16px; 
          font-weight: bold;
          margin-bottom: 5px;
        }
        .address {
          font-size: 12px;
          margin-bottom: 2px;
        }
        .phone {
          font-size: 12px;
        }
        .periode {
          text-align: right;
          font-size: 12px;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin: 15px 0;
          font-size: 12px;
        }
        th, td {
          padding: 8px 12px;
          text-align: left;
          border: 1px solid #ddd;
        }
        th { 
          background-color:rgb(255, 255, 255); 
          font-weight: bold;
          text-align: center;
        }
        .text-right { 
          text-align: right; 
        }
        .text-center {
          text-align: center;
        }
        .summary {
          margin-top: 20px;
          font-weight: bold;
          background-color:rgb(255, 255, 255);
          padding: 10px;
          border-radius: 4px;
        }
        .footer {
          margin-top: 30px;
          padding-top: 15px;
          border-top: 1px solid #eee;
          font-size: 11px;
          color: #666;
          text-align: center;
        }
        @media print {
          body { 
            padding: 10px;
            -webkit-print-color-adjust: exact; 
          }
          th { 
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
        }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="logo-container">
          <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg0JeOFanmAshWgLBlxIH5qHVyx7okwwmeV9Wbqr9n8Aie9Gh-BqnAF0_PlfBa_ZHqnENEOz8MuPZxFYFfgvCAYF8ie3AMRW_syA0dluwZJW-jg7ZuS8aaRJ38NI2f7UFW1ePVO4kifJTbdZi0WvQFr77GyqssJzeWL2K65GPB4dZwHEkZnlab9qNKX9VSZ/s320/logo-kifa.png" alt="Logo kifa" class="logo" />
        </div>
        <div class="header-content">
          <div class="title">DAFTAR JUAL PER ITEM PER PELANGGAN</div>
          <div class="subtitle">
            Outlet: ${r}
          </div>
          <div class="subtitle">
            Periode: ${s}
          </div>
          <div class="date">
            Dicetak pada: ${a}
          </div>
          <div class="phone">0858-6409-3750</div>
        </div>
        <div class="periode">
          PERIODE : ${s}
        </div>
      </div>

      <table>
        <thead>
          <tr>
            <th class="text-center">No</th>
            <th>Produk</th>
            <th class="text-right">Saldo Awal</th>
            <th class="text-right">Stock Masuk</th>
            <th class="text-right">Stock Keluar</th>
            <th class="text-right">Stock Akhir</th>
          </tr>
        </thead>
        <tbody>
          ${tM.data?.products?.map((t,e)=>`
            <tr>
              <td class="text-center">${e+1}</td>
              <td>${t.product_name||"-"}</td>
              <td class="text-right">${t.saldo_awal?.toLocaleString()||"0"}</td>
              <td class="text-right">${t.stock_masuk?.toLocaleString()||"0"}</td>
              <td class="text-right">${t.stock_keluar?.toLocaleString()||"0"}</td>
              <td class="text-right">${t.stock_akhir?.toLocaleString()||"0"}</td>
            </tr>
          `).join("")||'<tr><td colspan="6" class="text-center">Tidak ada data stok</td></tr>'}
        </tbody>
        <tfoot>
          <tr class="summary">
            <td colspan="2">TOTAL</td>
            <td class="text-right">${tM.data?.summary?.total_saldo_awal?.toLocaleString()||"0"}</td>
            <td class="text-right">${tM.data?.summary?.total_stock_masuk?.toLocaleString()||"0"}</td>
            <td class="text-right">${tM.data?.summary?.total_stock_keluar?.toLocaleString()||"0"}</td>
            <td class="text-right">${tM.data?.summary?.total_stock_akhir?.toLocaleString()||"0"}</td>
          </tr>
        </tfoot>
      </table>

      <div class="footer">
        <p>Laporan ini dibuat secara otomatis oleh Sistem Manajemen Inventori</p>
        <p>\xa9 ${new Date().getFullYear()} Kifa Bakery</p>
      </div>
    </body>
    </html>
  `,d=e.contentWindow.document;d.open(),d.write(n),d.close(),e.onload=function(){setTimeout(()=>{try{e.contentWindow.focus(),e.contentWindow.print()}catch(t){console.error("Gagal mencetak:",t)}finally{setTimeout(()=>{document.body.removeChild(e)},1e3)}},500)}};function tS({title:t,value:e,icon:a}){return(0,r.jsxs)("div",{className:"border rounded-lg p-4",children:[(0,r.jsxs)("div",{className:"flex items-center justify-between",children:[(0,r.jsx)("h4",{className:"text-sm font-medium text-muted-foreground",children:t}),a]}),(0,r.jsx)("p",{className:"text-2xl font-bold mt-2",children:e})]})}let tD=()=>{let e=document.createElement("iframe");e.style.position="absolute",e.style.top="-1000px",e.style.left="-1000px",document.body.appendChild(e);let a=(0,T.GP)(new Date,"dd MMMM yyyy",{locale:A.id}),r=t?t.name:"Semua Outlet",s=(0,T.GP)(th.from,"dd MMMM yyyy",{locale:A.id}),n=(0,T.GP)(th.to,"dd MMMM yyyy",{locale:A.id}),d=`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Laporan Penjualan per Item</title>
        <style>
          body { 
            font-family: Arial, sans-serif; 
            padding: 15px;
            color: #333;
          }
          .header { 
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #ddd;
          }
          .logo-container {
            width: 70px;
            margin-right: 15px;
          }
          .logo {
            width: 100%;
            height: auto;
          }
          .header-content {
            flex: 1;
          }
          .title { 
            font-size: 18px; 
            font-weight: bold;
            margin-bottom: 5px;
          }
          .subtitle {
            font-size: 13px;
            color: #555;
            margin-bottom: 3px;
          }
          .date {
            font-size: 12px;
            color: #777;
          }
          .stats-summary {
            margin: 15px 0;
            padding: 15px;
            background-color:rgb(255, 255, 255);
            border-radius: 5px;
          }
          .stat-item {
            margin-bottom: 8px;
            display: flex;
          }
          .stat-label {
            font-weight: bold;
            width: 180px;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            font-size: 13px;
          }
          th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
          }
          th { 
            background-color:rgb(255, 255, 255);
            font-weight: bold;
          }
          .text-right { 
            text-align: right; 
          }
          .footer {
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #eee;
            font-size: 12px;
            color: #666;
            text-align: center;
          }
          @media print {
            body { 
              padding: 10px;
              -webkit-print-color-adjust: exact; 
            }
            .stats-summary, th { 
              -webkit-print-color-adjust: exact;
            }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="logo-container">
            <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg0JeOFanmAshWgLBlxIH5qHVyx7okwwmeV9Wbqr9n8Aie9Gh-BqnAF0_PlfBa_ZHqnENEOz8MuPZxFYFfgvCAYF8ie3AMRW_syA0dluwZJW-jg7ZuS8aaRJ38NI2f7UFW1ePVO4kifJTbdZi0WvQFr77GyqssJzeWL2K65GPB4dZwHEkZnlab9qNKX9VSZ/s320/logo-kifa.png" 
                 alt="Logo Kifa" 
                 class="logo">
          </div>
          <div class="header-content">
            <div class="title">LAPORAN PENJUALAN per Item</div>
            <div class="subtitle">Outlet: ${r}</div>
            <div class="subtitle">Periode: ${s} - ${n}</div>
            <div class="date">Dicetak pada: ${a}</div>
          </div>
        </div>
  
        <div class="stats-summary">
          <div class="stat-item">
            <span class="stat-label">Total Penjualan:</span>
            <span>Rp ${ti.total_sales.toLocaleString()}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">Total Kuantitas:</span>
            <span>${ti.total_quantity.toLocaleString()} item</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">Total Transaksi:</span>
            <span>${ti.total_orders.toLocaleString()}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">Rata-rata/Transaksi:</span>
            <span>Rp ${ti.average_order_value.toLocaleString()}</span>
          </div>
        </div>
  
        <table>
          <thead>
            <tr>
              <th>SKU</th>
              <th>Nama Item</th>
              <th>Jenis</th>
              <th class="text-right">Jumlah Satuan</th>
              <th class="text-right">Total Harga</th>
            </tr>
          </thead>
          <tbody>
            ${Y.map(t=>`
              <tr>
                <td>${t.sku}</td>
                <td>${t.product_name}</td>
                <td>${t.category_name||"-"}</td>
                <td class="text-right">${t.total_quantity.toLocaleString()}</td>
                <td class="text-right">Rp ${t.total_sales.toLocaleString()}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
  
        <div class="footer">
          <p>Laporan ini dibuat otomatis oleh Sistem Manajemen Penjualan</p>
          <p>\xa9 ${new Date().getFullYear()} Kifa Bakery</p>
        </div>
      </body>
      </html>
    `,i=e.contentWindow.document;i.open(),i.write(d),i.close(),e.onload=function(){setTimeout(()=>{try{e.contentWindow.focus(),e.contentWindow.print()}catch(t){console.error("Gagal mencetak:",t)}finally{setTimeout(()=>{document.body.removeChild(e)},1e3)}},500)}},tL=()=>{if(!Y||!Y.length)return;let e=new Blob([[["LAPORAN PRODUK BERDASARKAN RENTANG TANGGAL"],[`Outlet: ${t?.name||"Semua Outlet"}`],[`Periode: ${(0,T.GP)(th.from,"dd MMMM yyyy",{locale:A.id})} - ${(0,T.GP)(th.to,"dd MMMM yyyy",{locale:A.id})}`],[`Tanggal Ekspor: ${(0,T.GP)(new Date,"dd MMMM yyyy HH:mm",{locale:A.id})}`],[],ti,[""],["DATA PRODUK"],["No","SKU","Nama Item","Jenis","Jumlah Satuan","Total Harga (Rp)"],...Y.map((t,e)=>[e+1,t.sku,t.product_name,t.category_name||"-",t.order_count,t.total_quantity,t.total_sales]).map(t=>[t[0],`"${t[1]}"`,`"${t[2]}"`,`"${t[3]}"`,`"${t[5].toLocaleString("id-ID")}"`,`"Rp ${t[6].toLocaleString("id-ID")}"`])].map(t=>Array.isArray(t)?t.join(","):t).join("\n")],{type:"text/csv;charset=utf-8;"}),a=document.createElement("a"),r=URL.createObjectURL(e);a.setAttribute("href",r),a.setAttribute("download",`Laporan_Produk_Per_Item_${t?.name||"All"}_${(0,T.GP)(th.from,"yyyyMMdd")}_${(0,T.GP)(th.to,"yyyyMMdd")}.csv`),document.body.appendChild(a),a.click(),document.body.removeChild(a)},tR=()=>{if(!tM?.data)return;let t=new Blob(["\uFEFF"+[[`Outlet: ${tM.data.outlet||"Semua Outlet"}`],[`Periode: ${tM.data.periode.start_date} s/d ${tM.data.periode.end_date}`],[],["No","Produk","Saldo Awal","Stock Masuk","Stock Keluar","Stock Akhir"],...tM.data.products.map((t,e)=>[e+1,t.product_name,t.saldo_awal,t.stock_masuk,t.stock_keluar,t.stock_akhir]),[],["TOTAL","",tM.data.summary.total_saldo_awal,tM.data.summary.total_stock_masuk,tM.data.summary.total_stock_keluar,tM.data.summary.total_stock_akhir]].map(t=>t.map(t=>"number"==typeof t?t:"string"==typeof t&&t.includes(",")?`"${t}"`:t).join(",")).join("\n")],{type:"text/csv;charset=utf-8;"}),e=document.createElement("a"),a=URL.createObjectURL(t);e.setAttribute("href",a),e.setAttribute("download",`Laporan_Stok_${tM.data.outlet.replace(/ /g,"_")||"All"}_${(0,T.GP)(new Date,"yyyyMMdd")}.csv`),document.body.appendChild(e),e.click(),document.body.removeChild(e)},tq=()=>{let e=document.createElement("iframe");e.style.position="absolute",e.style.top="-1000px",e.style.left="-1000px",document.body.appendChild(e);let a=(0,T.GP)(new Date,"dd MMMM yyyy",{locale:A.id}),r=t?t.name:"Semua Outlet",s=(0,T.GP)(th.from,"dd MMMM yyyy",{locale:A.id}),n=(0,T.GP)(th.to,"dd MMMM yyyy",{locale:A.id}),d=`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Laporan Penjualan Per Kategori</title>
        <style>
          body { 
            font-family: Arial, sans-serif; 
            padding: 15px;
            color: #333;
          }
          .header { 
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #ddd;
          }
          .logo-container {
            width: 70px;
            margin-right: 15px;
          }
          .logo {
            width: 100%;
            height: auto;
          }
          .header-content {
            flex: 1;
          }
          .title { 
            font-size: 18px; 
            font-weight: bold;
            margin-bottom: 5px;
          }
          .subtitle {
            font-size: 13px;
            color: #555;
            margin-bottom: 3px;
          }
          .date {
            font-size: 12px;
            color: #777;
          }
          .stats-summary {
            margin: 15px 0;
            padding: 15px;
            background-color:rgb(255, 255, 255);
            border-radius: 5px;
          }
          .stat-item {
            margin-bottom: 8px;
            display: flex;
          }
          .stat-label {
            font-weight: bold;
            width: 180px;
          }
          .category-header {
            background-color:rgb(255, 255, 255);
            padding: 12px 15px;
            margin-top: 25px;
            border-radius: 5px 5px 0 0;
            display: flex;
            justify-content: space-between;
            border: 1px solid #ddd;
            border-bottom: none;
          }
          .category-name {
            font-weight: bold;
            font-size: 15px;
          }
          .category-meta {
            color: #666;
            font-size: 13px;
            margin-top: 3px;
          }
          .category-sales {
            text-align: right;
            font-weight: bold;
          }
          .category-percentage {
            color: #666;
            text-align: right;
            font-size: 13px;
            margin-top: 3px;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin: 0 0 25px 0;
            font-size: 13px;
          }
          th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
          }
          th { 
            background-color:rgb(255, 255, 255); 
            font-weight: bold;
          }
          .text-right { 
            text-align: right; 
          }
          .footer {
            margin-top: 30px;
            padding-top: 15px;
            border-top: 1px solid #eee;
            font-size: 12px;
            color: #666;
            text-align: center;
          }
          .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin: 20px 0;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 5px;
          }
          .summary-item {
            margin-bottom: 8px;
          }
          .summary-label {
            color: #666;
            font-size: 13px;
            margin-bottom: 5px;
          }
          .summary-value {
            font-weight: bold;
            font-size: 15px;
          }
          @media print {
            body { 
              padding: 10px;
              -webkit-print-color-adjust: exact; 
            }
            .stats-summary, th, .category-header, .summary-grid { 
              -webkit-print-color-adjust: exact;
            }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="logo-container">
            <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg0JeOFanmAshWgLBlxIH5qHVyx7okwwmeV9Wbqr9n8Aie9Gh-BqnAF0_PlfBa_ZHqnENEOz8MuPZxFYFfgvCAYF8ie3AMRW_syA0dluwZJW-jg7ZuS8aaRJ38NI2f7UFW1ePVO4kifJTbdZi0WvQFr77GyqssJzeWL2K65GPB4dZwHEkZnlab9qNKX9VSZ/s320/logo-kifa.png" 
                 alt="Logo Kifa" 
                 class="logo">
          </div>
          <div class="header-content">
            <div class="title">LAPORAN PENJUALAN PER KATEGORI</div>
            <div class="subtitle">Outlet: ${r}</div>
            <div class="subtitle">Periode: ${s} - ${n}</div>
            <div class="date">Dicetak pada: ${a}</div>
          </div>
        </div>
  
        <div class="summary-grid">
          <div class="summary-item">
            <div class="summary-label">Total Kategori</div>
            <div class="summary-value">${tv.data.summary.total_categories}</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">Total Produk Terjual</div>
            <div class="summary-value">${tv.data.summary.total_products}</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">Total Kuantitas</div>
            <div class="summary-value">${tv.data.summary.total_quantity}</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">Total Penjualan</div>
            <div class="summary-value">Rp ${Number(tv.data.summary.total_sales).toLocaleString("id-ID")}</div>
          </div>
        </div>
  
        ${tv.data.categories.map(t=>`
          <div>
            <div class="category-header">
              <div>
                <div class="category-name">${t.category_name}</div>
                <div class="category-meta">${t.products.length} produk terjual</div>
              </div>
            </div>
            
            <table>
              <thead>
                <tr>
                  <th>Nama Item</th>
                  <th class="text-right">Kode Item</th>
                  <th class="text-right">Jenis</th>
                  <th class="text-right">Jumlah</th>
                  <th class="text-left">Satuan</th>
                  <th class="text-right">Total Harga</th>
                </tr>
              </thead>
              <tbody>
                ${t.products.map(e=>`
                  <tr>
                    <td>${e.product_name}</td>
                    <td class="text-right">${e.product_sku}</td>
                    <td class="text-right">${t.category_name}</td>
                    <td class="text-right">${Number(e.quantity)}</td>                    
                    <td class="text-left">${e.product_unit}</td>                    
                    <td class="text-right">Rp ${Number(e.sales).toLocaleString("id-ID")}</td>
                  </tr>
                `).join("")}
              </tbody>
              <tfoot>
                <tr>
                  <td colspan="3" class="text-right" style="font-weight: bold;">Total</td>
                  <td class="text-right" style="font-weight: bold;"> ${Number(t.total_quantity)}</td>
                  <td colspan="2" class="text-right" style="font-weight: bold;">Rp ${Number(t.total_sales).toLocaleString("id-ID")}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        `).join("")}
  
        <div class="footer">
          <p>Laporan ini dibuat otomatis oleh Sistem Manajemen Penjualan</p>
          <p>\xa9 ${new Date().getFullYear()} Kifa Bakery</p>
        </div>
      </body>
      </html>
    `,i=e.contentWindow.document;i.open(),i.write(d),i.close(),e.onload=function(){setTimeout(()=>{try{e.contentWindow.focus(),e.contentWindow.print()}catch(t){console.error("Gagal mencetak:",t)}finally{setTimeout(()=>{document.body.removeChild(e)},1e3)}},500)}},tE=()=>{if(!tv?.data?.categories||!tv.data.categories.length)return;let e=[["LAPORAN PENJUALAN PER KATEGORI"],[`Outlet: ${t?.name||"Semua Outlet"}`],[`Periode: ${(0,T.GP)(th.from,"dd MMMM yyyy",{locale:A.id})} - ${(0,T.GP)(th.to,"dd MMMM yyyy",{locale:A.id})}`],[`Tanggal Ekspor: ${(0,T.GP)(new Date,"dd MMMM yyyy HH:mm",{locale:A.id})}`],[]],a=[["Total Kategori",tv.data.summary.total_categories],["Total Produk Terjual",tv.data.summary.total_products],["Total Kuantitas",tv.data.summary.total_quantity],["Total Penjualan (Rp)",`Rp ${Number(tv.data.summary.total_sales).toLocaleString("id-ID")}`]].map(t=>t.join(",")),r=[""],s=[...e,["RINGKASAN"],...a,r];tv.data.categories.forEach(t=>{s.push([`KATEGORI: ${t.category_name}`]),s.push([`Total Penjualan Kategori: Rp ${Number(t.total_sales).toLocaleString("id-ID")}`,`Persentase dari Total: ${t.sales_percentage.toFixed(2)}%`,`Jumlah Produk: ${t.products.length}`]),s.push(r),s.push(["No","Nama Item","Jenis","SKU","Jumlah","Satuan","Total Harga (Rp)"]),t.products.forEach((e,a)=>{s.push([a+1,`"${e.product_name}"`,`"${t.category_name}"`,`"${e.product_sku}"`,`"${Number(e.quantity).toLocaleString("id-ID")}"`,`"${e.product_unit}"`,`"Rp ${Number(e.sales).toLocaleString("id-ID")}"`])}),s.push(r),s.push(r)});let n=new Blob([s.map(t=>Array.isArray(t)?t.join(","):t).join("\n")],{type:"text/csv;charset=utf-8;"}),d=document.createElement("a"),i=URL.createObjectURL(n);d.setAttribute("href",i),d.setAttribute("download",`Laporan_Kategori_${t?.name||"All"}_${(0,T.GP)(th.from,"yyyyMMdd")}_${(0,T.GP)(th.to,"yyyyMMdd")}.csv`),document.body.appendChild(d),d.click(),document.body.removeChild(d)},tG=()=>{let e=document.createElement("iframe");e.style.position="absolute",e.style.top="-1000px",e.style.left="-1000px",document.body.appendChild(e);let a=(0,T.GP)(tg.from,"dd MMMM yyyy",{locale:A.id}),r=(0,T.GP)(tg.to,"dd MMMM yyyy",{locale:A.id}),s=(0,T.GP)(new Date,"dd MMMM yyyy",{locale:A.id}),n=t?t.name:"Semua Outlet";p?(0,T.GP)(p,"dd MMMM yyyy",{locale:A.id}):(0,T.GP)(new Date,"dd MMMM yyyy",{locale:A.id});let d=`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Laporan Penjualan Harian</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 15px; color: #333; }
          .header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #ddd;
          }
          .logo-container {
            width: 70px;
            margin-right: 15px;
          }
          .logo {
            width: 100%;
            height: auto;
          }
          .header-content {
            flex: 1;
          }
          .title {
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 5px;
          }
          .subtitle {
            font-size: 13px;
            color: #555;
            margin-bottom: 3px;
          }
          .date {
            font-size: 12px;
            color: #777;
          }
          .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin: 30px 0;
            padding: 20px;
            background-color:rgb(255, 255, 255);
            border-radius: 8px;
          }
          .summary-item { margin-bottom: 10px; }
          .summary-label {
            color: #666;
            font-size: 14px;
            margin-bottom: 5px;
          }
          .summary-value {
            font-weight: bold;
            font-size: 16px;
          }
          .order-container {
            margin-bottom: 30px;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
          }
          .order-header {
            background-color:rgb(255, 255, 255);
            padding: 15px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
          }
          .order-id { font-weight: bold; font-size: 16px; }
          .order-meta {
            display: flex;
            gap: 20px;
            color: #666;
            font-size: 14px;
          }
          .order-total {
            font-weight: bold;
            text-align: right;
          }
          table {
            width: 100%;
            border-collapse: collapse;
          }
          th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
          }
          th {
            background-color:rgb(255, 255, 255);
            font-weight: bold;
          }
          .text-right { text-align: right; }
          .payment-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            background-color:rgb(255, 255, 255);
            border: 1px solid #ddd;
            font-size: 12px;
          }
          .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            font-size: 12px;
            color: #666;
            text-align: center;
          }
          @media print {
            body { -webkit-print-color-adjust: exact; }
            .summary-grid, th, .order-header {
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div class="logo-container">
            <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg0JeOFanmAshWgLBlxIH5qHVyx7okwwmeV9Wbqr9n8Aie9Gh-BqnAF0_PlfBa_ZHqnENEOz8MuPZxFYFfgvCAYF8ie3AMRW_syA0dluwZJW-jg7ZuS8aaRJ38NI2f7UFW1ePVO4kifJTbdZi0WvQFr77GyqssJzeWL2K65GPB4dZwHEkZnlab9qNKX9VSZ/s320/logo-kifa.png"
                 alt="Logo Kifa"
                 class="logo">
          </div>
          <div class="header-content">
            <div class="title">LAPORAN PENJUALAN</div>
            <div class="subtitle">Outlet: ${n}</div>
            <div class="subtitle">Tanggal: ${a} - ${r}</div>
            <div class="date">Dicetak pada: ${s}</div>
          </div>
        </div>
  
        <div class="summary-grid">
          <div class="summary-item">
            <div class="summary-label">Total Penjualan</div>
            <div class="summary-value">Rp ${tk?.data.total_revenue.toLocaleString()}</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">Total Order</div>
            <div class="summary-value">${tk?.data.total_orders}</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">Total Item</div>
            <div class="summary-value">${tk?.data.total_items_sold}</div>
          </div>
          <div class="summary-item">
            <div class="summary-label">Rata-rata Order</div>
            <div class="summary-value">Rp ${tk?.data.average_order_value}</div>
          </div>
        </div>
  
        ${tk?.data.orders.map((t,e)=>`
          <div class="order-container ${e>0?"page-break":""}">
            <div class="order-header">
              <div>
                <div class="summary-label">No Transaksi</div>
                <div class="order-id">#${t.order_number}</div>
              </div>
              <div class="order-meta">
                <div>${t.created_at}</div>
                <div>Kasir: ${t.user}</div>
                <div class="payment-badge">${"cash"===t.payment_method?"Tunai":"transfer"===t.payment_method?"Transfer":"Qris"}</div>
              </div>
              <div class="order-total">
                Rp ${t.total.toLocaleString()}
              </div>
            </div>
            <table>
              <thead>
                <tr>
                  <th>Nama Item</th>
                  <th>Kode Item</th>
                  <th class="text-right">Harga</th>
                  <th class="text-right">Jumlah</th>
                  <th class="text-left">Satuan</th>
                  <th class="text-right">Total</th>
                </tr>
              </thead>
              <tbody>
                ${t.items?t.items.map(t=>`
                  <tr>
                    <td>${t.product}</td>
                    <td>${t.sku||"-"}</td>
                    <td class="text-right">Rp ${t.price.toLocaleString()}</td>
                    <td class="text-right">${t.quantity}</td>
                    <td class="text-left">${t.unit}</td>
                    <td class="text-right">Rp ${(Number(t.price)*t.quantity).toLocaleString()}</td>
                  </tr>
                `).join(""):`
                  <tr>
                    <td colspan="5" style="text-align: center; color: #666;">Detail produk tidak tersedia</td>
                  </tr>
                `}
              </tbody>
              <tfoot>
                <tr>
                  <td class="text-right" style="font-weight: bold;">Tax</td>
                  <td class="text-right" style="font-weight: bold;">Rp ${t.tax.toLocaleString()}</td>
                </tr>
                <tr>
                  <td colspan="4" class="text-right" style="font-weight: bold;">Total</td>
                  <td class="text-right" style="font-weight: bold;">Rp ${t.total.toLocaleString()}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        `).join("")}
  
        <div class="footer">
          <p>Laporan ini dibuat secara otomatis oleh sistem.</p>
          <p>\xa9 ${new Date().getFullYear()} Kifa Bakery</p>
        </div>
      </body>
      </html>
    `,i=e.contentWindow.document;i.open(),i.write(d),i.close(),e.onload=function(){setTimeout(()=>{try{e.contentWindow.focus(),e.contentWindow.print()}catch(t){console.error("Gagal mencetak:",t)}finally{setTimeout(()=>{document.body.removeChild(e)},1e3)}},500)}},tO=()=>{if(!tk||!tk.data||!tk.data.orders){console.error("Data penjualan tidak tersedia untuk di-export");return}try{let e="Order ID,Tanggal,Waktu,Kasir,Metode Pembayaran,Produk,SKU,Harga,Kuantitas,Subtotal,Total Order\n";tk.data.orders.forEach(t=>{let a=t.created_at.split(" ")[0],r="cash"===t.payment_method?"Tunai":"Non-Tunai";t.items&&t.items.length>0?t.items.forEach((s,n)=>{let d=s.product.replace(/,/g,";"),i=(s.sku||"-").replace(/,/g,";"),o=s.price,l=s.quantity,c=Number(s.price)*s.quantity,u=0===n?t.total:"";e+=`"${t.order_number}","${a}","${t.user}","${r}","${d}","${i}",${o},${l},${c},${u}
`}):e+=`"${t.order_number}","${a}","${t.created_at}","${t.user.name}","${r}","","","","","",${t.total}
`}),e+=`
"RINGKASAN PENJUALAN"
"Total Penjualan",${tk.data.total_revenue}
"Total Order",${tk.data.total_orders}
"Total Item",${tk.data.total_items_sold}
"Rata-rata Order",${tk.data.average_order_value}
`;let a=new Blob([e],{type:"text/csv;charset=utf-8;"}),r=p?(0,T.GP)(p,"yyyy-MM-dd",{locale:A.id}):(0,T.GP)(new Date,"yyyy-MM-dd",{locale:A.id}),s=t?`_${t.name.replace(/\s+/g,"_")}`:"_Semua_Outlet",n=`Laporan_Penjualan_Harian${s}_${r}.csv`;if(window.saveAs)window.saveAs(a,n);else{let t=document.createElement("a");window.URL&&window.URL.createObjectURL?(t.href=window.URL.createObjectURL(a),t.download=n,document.body.appendChild(t),t.click(),setTimeout(()=>{document.body.removeChild(t),window.URL.revokeObjectURL(t.href)},100)):(console.error("Browser tidak mendukung download CSV"),j.error("Browser tidak mendukung download CSV"))}}catch(t){console.error("Gagal export CSV:",t)}},{data:tI}=(0,w.uv)(t?.id??0,tx?.from?(0,T.GP)(tx.from,"yyyy-MM-dd"):"",tx?.to?(0,T.GP)(tx.to,"yyyy-MM-dd"):""),tC={approved:tI?.approved||[],rejected:tI?.rejected||[]},tH=()=>{let t=document.createElement("iframe");t.style.position="absolute",t.style.top="-1000px",t.style.left="-1000px",document.body.appendChild(t);let e=(0,T.GP)(new Date,"dd MMMM yyyy",{locale:A.id}),a=tx?.from?`${(0,T.GP)(tx.from,"dd MMM yyyy",{locale:A.id})} - ${tx.to?(0,T.GP)(tx.to,"dd MMM yyyy",{locale:A.id}):""}`:"Semua Periode",r=`
<!DOCTYPE html>
<html>
<head>
  <title>Laporan Penyesuaian Stok</title>
  <style>
    body { font-family: Arial, sans-serif; padding: 15px; color: #333; }
    .header {
      display: flex;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 15px;
      border-bottom: 1px solid #ddd;
    }
    .logo-container {
      width: 70px;
      margin-right: 15px;
    }
    .logo {
      width: 100%;
      height: auto;
    }
    .header-content {
      flex: 1;
    }
    .title {
      font-size: 18px;
      font-weight: bold;
      margin-bottom: 5px;
    }
    .subtitle {
      font-size: 13px;
      color: #555;
      margin-bottom: 3px;
    }
    .date {
      font-size: 12px;
      color: #777;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 20px 0;
    }
    th, td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    th {
      background-color: #f8f9fa;
      font-weight: bold;
    }
    .section-title {
      font-size: 16px;
      font-weight: bold;
      margin: 25px 0 15px;
      padding-bottom: 5px;
      border-bottom: 2px solid #333;
    }
    .status-badge {
      display: inline-block;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 12px;
    }
    .approved { background-color: #e6f4ea; color: #137333; }
    .rejected { background-color: #fce8e6; color: #a50e0e; }
    .footer {
      margin-top: 40px;
      padding-top: 20px;
      border-top: 1px solid #eee;
      font-size: 12px;
      color: #666;
      text-align: center;
    }
    @media print {
      body { -webkit-print-color-adjust: exact; }
      th, .status-badge {
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
      }
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="logo-container">
      <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg0JeOFanmAshWgLBlxIH5qHVyx7okwwmeV9Wbqr9n8Aie9Gh-BqnAF0_PlfBa_ZHqnENEOz8MuPZxFYFfgvCAYF8ie3AMRW_syA0dluwZJW-jg7ZuS8aaRJ38NI2f7UFW1ePVO4kifJTbdZi0WvQFr77GyqssJzeWL2K65GPB4dZwHEkZnlab9qNKX9VSZ/s320/logo-kifa.png"
           alt="Logo Kifa"
           class="logo">
    </div>
    <div class="header-content">
      <div class="title">LAPORAN PERSETUJUAN PENYESUAIAN STOK</div>
      <div class="subtitle">Periode: ${a}</div>
      <div class="date">Dicetak pada: ${e}</div>
    </div>
  </div>

  <div class="section-title">Penyesuaian Disetujui</div>
  <table>
    <thead>
      <tr>
        <th>Tanggal</th>
        <th>SKU</th>
        <th>Nama Item</th>
        <th>Perubahan</th>
        <th>Keterangan</th>
        <th>Disetujui Oleh</th>
      </tr>
    </thead>
    <tbody>
    ${tC?.approved?.length>0?tC.approved.map(t=>`
        <tr>
          <td>${t.approved_at?(0,T.GP)(new Date(t.approved_at),"dd MMM yyyy",{locale:A.id}):"-"}</td>
          <td>${t.product?.sku||"-"}</td>
          <td>${t.product?.name||"-"}</td>
          <td style="color: ${t.quantity_change>0?"#137333":"#a50e0e"}">
            ${t.quantity_change>0?`+${t.quantity_change}`:t.quantity_change??0}
          </td>
          <td>${t.notes||"-"}</td>
          <td>${t.approver?.name||"-"}</td>
        </tr>
      `).join(""):'<tr><td colspan="6" style="text-align: center; color: #666;">Tidak ada data</td></tr>'}
  </tbody>
  </table>

  <div class="section-title">Penyesuaian Ditolak</div>
  <table>
    <thead>
      <tr>
        <th>Tanggal</th>
        <th>SKU</th>
        <th>Nama Item</th>
        <th>Perubahan</th>
        <th>Keterangan</th>
        <th>Ditolak Oleh</th>
      </tr>
    </thead>
    <tbody>
      ${tC?.rejected?.length>0?tC.rejected.map(t=>`
          <tr>
            <td>${t.approved_at?(0,T.GP)(new Date(t.approved_at),"dd MMM yyyy",{locale:A.id}):"-"}</td>
            <td>${t.product?.sku||"-"}</td>
            <td>${t.product?.name||"-"}</td>
            <td style="color: ${t.quantity_change>0?"#137333":"#a50e0e"}">
              ${t.quantity_change>0?`+${t.quantity_change}`:t.quantity_change}
            </td>
            <td>${t.notes||"-"}</td>
            <td>${t.approver?.name||"-"}</td>
          </tr>
        `).join(""):'<tr><td colspan="6" style="text-align: center; color: #666;">Tidak ada data</td></tr>'}
    </tbody>
  </table>

  <div class="footer">
    <p>Laporan ini dibuat secara otomatis oleh sistem.</p>
    <p>\xa9 ${new Date().getFullYear()} Kifa Bakery</p>
  </div>
</body>
</html>
`,s=t.contentDocument||t.contentWindow.document;s.open(),s.write(r),s.close(),t.onload=function(){t.contentWindow.focus(),t.contentWindow.print(),setTimeout(()=>{document.body.removeChild(t)},1e3)}},tK=()=>{let t=tC?.approved||[],e=tC?.rejected||[];if(0===t.length&&0===e.length){alert("Tidak ada data untuk diekspor");return}let a=[["=== LAPORAN PENYESUAIAN STOK ==="],["Periode",`: ${tx?.from?(0,T.GP)(tx.from,"dd MMMM yyyy",{locale:A.id}):"-"} - ${p?.to?(0,T.GP)(p.to,"dd MMMM yyyy",{locale:A.id}):"-"}`],["Tanggal Ekspor",`: ${(0,T.GP)(new Date,"dd MMMM yyyy HH:mm",{locale:A.id})}`],["	"]],r=(t,e)=>0===t.length?[]:[[`=== ${e.toUpperCase()} ===`],["	No	","	Tanggal	","	SKU	","	Nama Item	","	Perubahan Stok	","	Keterangan	","	Penanggung Jawab	"],...t.map((t,e)=>[`	${e+1}	`,`	${t.approved_at?(0,T.GP)(new Date(t.approved_at),"dd MMMM yyyy",{locale:A.id}):"-"}	`,`	${t.product?.sku||"-"}	`,`	${t.product?.name||"-"}	`,`	${t.quantity_change>0?`+${t.quantity_change}`:t.quantity_change}	`,`	${t.notes||"-"}	`,`	${t.approver?.name||"-"}	`]),["	"]],s=new Blob(["\uFEFF",["sep=,",'"Format Table Excel"',...a,...r(t,"Disetujui"),...r(e,"Ditolak")].map(t=>Array.isArray(t)?t.join(","):t).join("\n")],{type:"text/csv;charset=utf-8;"}),n=document.createElement("a");n.href=URL.createObjectURL(s),n.download=`Laporan_Penyesuaian_Stok_${(0,T.GP)(new Date,"yyyyMMdd")}.csv`,document.body.appendChild(n),n.click(),document.body.removeChild(n)},{data:tF,refetch:tB}=(0,w.K9)({outletId:t?.id||1,dateRange:{start_date:(0,T.GP)(tf.from,"yyyy-MM-dd"),end_date:(0,T.GP)(tf.to,"yyyy-MM-dd")}})(),tW=()=>{let e=document.createElement("iframe");e.style.position="absolute",e.style.top="-1000px",e.style.left="-1000px",document.body.appendChild(e);let a=(0,T.GP)(new Date,"dd MMMM yyyy",{locale:A.id}),r=t?t.name:"Semua Outlet",s=(0,T.GP)(tf.from,"dd MMMM yyyy",{locale:A.id}),n=(0,T.GP)(tf.to,"dd MMMM yyyy",{locale:A.id}),d={purchase:{name:"Pembelian",products:tF?.data.summary_by_type.purchase?.products||[]},sale:{name:"Penjualan",products:tF?.data.summary_by_type.sale?.products||[]},adjustment:{name:"Penyesuaian",products:tF?.data.summary_by_type.adjustment?.products||[]},shipment:{name:"Pengiriman",products:tF?.data.summary_by_type.shipment?.products||[]}},i=`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Laporan Histori Stok</title>
      <style>
        body { 
          font-family: Arial, sans-serif; 
          padding: 20px; 
          color: #333; 
          font-size: 14px;
        }
        .header { 
          display: flex;
          align-items: center;
          margin-bottom: 20px;
          padding-bottom: 15px;
          border-bottom: 1px solid #ddd;
        }
        .logo-container {
          width: 70px;
          margin-right: 15px;
        }
        .logo {
          width: 100%;
          height: auto;
        }
        .title {
          font-size: 18px;
          font-weight: bold;
          margin-bottom: 5px;
        }
        .subtitle {
          font-size: 13px;
          color: #555;
        }
        .date {
          font-size: 12px;
          color: #777;
          margin-top: 10px;
        }
        .period {
          font-size: 13px;
          margin-bottom: 15px;
        }
        .stock-group {
          margin-bottom: 30px;
          page-break-inside: avoid;
        }
        .group-title {
          font-weight: bold;
          font-size: 15px;
          margin: 15px 0 10px 0;
          padding-bottom: 5px;
          border-bottom: 1px solid #eee;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 10px;
        }
        th, td {
          padding: 8px;
          text-align: left;
          border-bottom: 1px solid #ddd;
        }
        th {
          background-color:rgb(255, 255, 255);
          font-weight: bold;
        }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .badge {
          display: inline-block;
          padding: 3px 6px;
          border-radius: 4px;
          font-size: 12px;
          border: 1px solid #ddd;
        }
        .footer {
          margin-top: 30px;
          padding-top: 15px;
          border-top: 1px solid #eee;
          font-size: 12px;
          color: #666;
          text-align: center;
        }
        @media print {
          body { padding: 15px; }
          .stock-group { page-break-inside: avoid; }
        }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="logo-container">
          <img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg0JeOFanmAshWgLBlxIH5qHVyx7okwwmeV9Wbqr9n8Aie9Gh-BqnAF0_PlfBa_ZHqnENEOz8MuPZxFYFfgvCAYF8ie3AMRW_syA0dluwZJW-jg7ZuS8aaRJ38NI2f7UFW1ePVO4kifJTbdZi0WvQFr77GyqssJzeWL2K65GPB4dZwHEkZnlab9qNKX9VSZ/s320/logo-kifa.png"
               alt="Logo Kifa"
               class="logo">
        </div>
        <div class="header-content">
          <div class="title">LAPORAN HISTORI STOK</div>
          <div class="subtitle">Outlet: ${r}</div>
          <div class="period">Periode: ${s} - ${n}</div>
          <div class="date">Dicetak pada: ${a}</div>
        </div>
      </div>

      ${Object.entries(d).map(([t,e])=>`
        <div class="stock-group">
          <div class="group-title">
            ${e.name} (${e.products.length} produk)
          </div>
          <table>
            <thead>
              <tr>
                <th>Produk</th>
                <th>SKU</th>
                <th>Stok Akhir</th>
                <th class="text-right">Total Perubahan</th>
                <th class="text-right">Total Transaksi</th>
                <th>Detail Transaksi</th>
              </tr>
            </thead>
            <tbody>
              ${e.products.map(t=>`
                <tr>
                  <td>
                    <div>${t.product_name}</div>
                  </td>
                  <td>${t.sku}</td>
                  <td>${t.stock_as_of_end_date} ${t.unit}</td>
                  <td class="text-right">
                    <span style="color:${t.total_quantity_changed>0?"green":"red"}">
                      ${t.total_quantity_changed>0?"+":""}${t.total_quantity_changed}
                    </span>
                  </td>
                  <td class="text-right">${t.total_entries}</td>
                  <td>
                    <table style="margin: 5px 0; background: #f9f9f9;">
                      <thead>
                        <tr>
                          <th style="padding: 3px;">Tanggal</th>
                          <th style="padding: 3px; text-align: right;">Sebelum</th>
                          <th style="padding: 3px; text-align: right;">Perubahan</th>
                          <th style="padding: 3px; text-align: right;">Sesudah</th>
                          <th style="padding: 3px;">Catatan</th>
                        </tr>
                      </thead>
                      <tbody>
                        ${t.entries.map(t=>`
                          <tr>
                            <td style="padding: 3px;">${(0,T.GP)(new Date(t.created_at),"dd MMM yy",{locale:A.id})}</td>
                            <td style="padding: 3px; text-align: right;">${t.quantity_before}</td>
                            <td style="padding: 3px; text-align: right; color:${t.quantity_change>0?"green":"red"}">
                              ${t.quantity_change>0?"+":""}${t.quantity_change}
                            </td>
                            <td style="padding: 3px; text-align: right;">${t.quantity_after}</td>
                            <td style="padding: 3px;">${t.notes||"-"}</td>
                          </tr>
                        `).join("")}
                      </tbody>
                    </table>
                  </td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      `).join("")}

      ${tF?.data.summary_by_type.purchase.products.length||tF?.data.summary_by_type.sale.products.length||tF?.data.summary_by_type.adjustment.products.length||tF?.data.summary_by_type.shipment.products.length?"":`
        <div class="text-center" style="margin:30px 0;color:#666;">
          Tidak ada data stok yang tersedia
        </div>
      `}

      <div class="footer">
        <p>Laporan ini dibuat secara otomatis oleh sistem</p>
        <p>\xa9 ${new Date().getFullYear()} Kifa Bakery</p>
      </div>
    </body>
    </html>
  `,o=e.contentWindow.document;o.open(),o.write(i),o.close(),e.onload=function(){setTimeout(()=>{e.contentWindow.focus(),e.contentWindow.print(),setTimeout(()=>{document.body.removeChild(e)},1e3)},500)}},tZ=()=>{if(!tF?.data||!tF.data.summary_by_type.purchase.products.length&&!tF.data.summary_by_type.sale.products.length&&!tF.data.summary_by_type.adjustment.products.length&&!tF.data.summary_by_type.shipment.products.length){alert("Tidak ada data stok untuk diekspor");return}let e=[];[{type:"purchase",name:"Pembelian"},{type:"sale",name:"Penjualan"},{type:"adjustment",name:"Penyesuaian"},{type:"shipment",name:"Pengiriman"}].forEach(({type:a,name:r})=>{(tF.data.summary_by_type[a]?.products||[]).forEach(a=>{a.entries&&a.entries.length>0?a.entries.forEach(s=>{e.push([r,`"${a.product_name}"`,`"${a.sku}"`,a.stock_as_of_end_date,`"${a.unit}"`,a.total_quantity_changed,a.total_entries,(0,T.GP)(new Date(s.created_at),"dd MMM yyyy HH:mm",{locale:A.id}),s.quantity_before,s.quantity_change,s.quantity_after,`"${s.notes||"-"}"`,`"${t?.name||"Semua Outlet"}"`])}):e.push([r,`"${a.product_name}"`,`"${a.sku}"`,a.stock_as_of_end_date,`"${a.unit}"`,a.total_quantity_changed,a.total_entries,"-","-","-","-","-",`"${t?.name||"Semua Outlet"}"`])})});let a=new Blob([["Jenis Transaksi,Nama Produk,SKU,Stok Akhir Periode,Satuan,Total Perubahan Stok,Jumlah Transaksi,Tanggal Transaksi,Stok Sebelum,Perubahan Stok,Stok Sesudah,Catatan,Outlet",...e.map(t=>t.join(","))].join("\n")],{type:"text/csv;charset=utf-8;"}),r=URL.createObjectURL(a),s=document.createElement("a");s.href=r,s.setAttribute("download",`Laporan_Histori_Stok_${t?.name||"Semua_Outlet"}_${(0,T.GP)(tf.from,"yyyyMMdd")}_${(0,T.GP)(tf.to,"yyyyMMdd")}.csv`),document.body.appendChild(s),s.click(),document.body.removeChild(s)},tz=async()=>{try{if(!tl.from||!tl.to){j({title:"Error",description:"Silakan pilih rentang tanggal terlebih dahulu",variant:"destructive"});return}f(!0);let e=await (0,w.$l)({outletId:t?.id||1,dateRange:{start_date:(0,T.GP)(tl.from,"yyyy-MM-dd"),end_date:(0,T.GP)(tl.to,"yyyy-MM-dd")}});if(!e?.data){j({title:"Error",description:"Tidak ada data yang tersedia untuk dicetak",variant:"destructive"});return}if(e.data.date_range){let t=t=>(0,T.GP)(new Date(t),"yyyy-MM-dd"),a=t(th.from),r=t(th.to),s=t(e.data.date_range.start_date),n=t(e.data.date_range.end_date);(s!==a||n!==r)&&j({title:"Peringatan",description:"Data yang ditampilkan mungkin tidak sesuai dengan periode yang dipilih",variant:"default"})}let a=document.createElement("iframe");a.style.position="absolute",a.style.top="-1000px",a.style.left="-1000px",document.body.appendChild(a);let r=(0,T.GP)(new Date,"dd MMMM yyyy",{locale:A.id}),s=(0,T.GP)(tl.from,"dd MMM yyyy",{locale:A.id}),n=(0,T.GP)(tl.to,"dd MMM yyyy",{locale:A.id}),d=`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Laporan Penjualan Per Pelanggan</title>
          <style>
            body { 
              font-family: Arial, sans-serif; 
              padding: 20px; 
              color: #333; 
              font-size: 14px;
            }
            .header { 
              margin-bottom: 20px;
              padding-bottom: 15px;
              border-bottom: 1px solid #ddd;
            }
            .title {
              font-size: 18px;
              font-weight: bold;
              margin-bottom: 5px;
            }
            .subtitle {
              font-size: 13px;
              color: #555;
            }
            .date {
              font-size: 12px;
              color: #777;
              margin-top: 10px;
            }
            .summary-cards {
              display: grid;
              grid-template-columns: repeat(4, 1fr);
              gap: 15px;
              margin-bottom: 20px;
            }
            .summary-card {
              border: 1px solid #ddd;
              border-radius: 4px;
              padding: 12px;
              background-color: #f9f9f9;
            }
            .summary-label {
              font-size: 12px;
              color: #666;
              margin-bottom: 5px;
            }
            .summary-value {
              font-weight: bold;
              font-size: 16px;
            }
            .member-card {
              margin-bottom: 30px;
              border: 1px solid #ddd;
              border-radius: 4px;
              page-break-inside: avoid;
            }
            .member-header {
              padding: 12px 15px;
              background-color: #f5f5f5;
              display: flex;
              justify-content: space-between;
              border-bottom: 1px solid #ddd;
            }
            .member-name {
              font-weight: bold;
            }
            .member-stats {
              text-align: right;
            }
            .total-sales {
              font-weight: bold;
            }
            .sales-percentage {
              font-size: 12px;
              color: #555;
            }
            table {
              width: 100%;
              border-collapse: collapse;
            }
            th, td {
              padding: 8px;
              text-align: left;
              border-bottom: 1px solid #ddd;
            }
            th {
              background-color: #f5f5f5;
              font-weight: bold;
            }
            .text-right { text-align: right; }
            .footer {
              margin-top: 30px;
              padding-top: 15px;
              border-top: 1px solid #eee;
              font-size: 12px;
              color: #666;
              text-align: center;
            }
            @media print {
              body { padding: 15px; }
              .member-card { page-break-inside: avoid; }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="title">LAPORAN PENJUALAN PER PELANGGAN</div>
            <div class="subtitle">Outlet: ${t?.name||"Semua Outlet"}</div>
            <div class="subtitle">Periode: ${s} - ${n}</div>
            <div class="date">Dicetak pada: ${r}</div>
          </div>
  
          ${e.data.summary?`
            <div class="summary-cards">
              <div class="summary-card">
                <div class="summary-label">Total Penjualan</div>
                <div class="summary-value">Rp ${Number(e.data.summary.total_sales).toLocaleString("id-ID")}</div>
              </div>
              <div class="summary-card">
                <div class="summary-label">Total Transaksi</div>
                <div class="summary-value">${e.data.summary.total_orders}</div>
              </div>
              <div class="summary-card">
                <div class="summary-label">Rata-rata Transaksi</div>
                <div class="summary-value">Rp ${Number(e.data.summary.average_order_value).toLocaleString("id-ID")}</div>
              </div>
              <div class="summary-card">
                <div class="summary-label">Total Pelanggan</div>
                <div class="summary-value">${e.data.summary.total_members||0}</div>
              </div>
            </div>
          `:""}
  
          ${e.data.members?.length>0?e.data.members.map(t=>`
              <div class="member-card">
                <div class="member-header">
                  <div>
                    <div class="member-name">${t.member_name||"Pelanggan Umum"}</div>
                    <div>${t.total_orders} transaksi</div>
                  </div>
                  <div class="member-stats">
                    <div class="total-sales">Rp ${Number(t.total_spent).toLocaleString("id-ID")}</div>
                    ${e.data.summary?.total_sales?`
                      <div class="sales-percentage">
                        ${(t.total_spent/e.data.summary.total_sales*100).toFixed(2)}% dari total
                      </div>
                    `:""}
                  </div>
                </div>
                
                ${t.products?.length>0?`
                  <table>
                    <thead>
                      <tr>
                        <th>Produk</th>
                        <th>Kategori</th>
                        <th class="text-right">Kuantitas</th>
                        <th class="text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      ${t.products.map(t=>`
                        <tr>
                          <td>${t.product_name}</td>
                          <td>${t.category}</td>
                          <td class="text-right">${t.quantity}</td>
                          <td class="text-right">Rp ${Number(t.total_spent).toLocaleString("id-ID")}</td>
                        </tr>
                      `).join("")}
                    </tbody>
                  </table>
                `:'<div style="padding: 15px; text-align: center; color: #666;">Tidak ada produk</div>'}
              </div>
            `).join(""):'<div style="text-align: center; padding: 20px; color: #666;">Tidak ada data penjualan</div>'}
  
          <div class="footer">
            <p>Laporan ini dibuat secara otomatis oleh sistem</p>
            <p>\xa9 ${new Date().getFullYear()} ${t?.name||"Kifa Bakery"}</p>
          </div>
        </body>
        </html>
      `,i=a.contentWindow.document;i.open(),i.write(d),i.close(),a.onload=function(){setTimeout(()=>{a.contentWindow.focus(),a.contentWindow.print(),setTimeout(()=>{document.body.removeChild(a)},1e3)},500)}}catch(t){console.error("Print error:",t),j({title:"Error",description:"Gagal memuat data untuk dicetak",variant:"destructive"})}finally{f(!1)}},tU=async()=>{try{if(!tl.from||!tl.to){j({title:"Error",description:"Silakan pilih rentang tanggal terlebih dahulu",variant:"destructive"});return}f(!0),(0,T.GP)(th.from,"yyyy-MM-dd"),(0,T.GP)(th.to,"yyyy-MM-dd");let e=await (0,w.$l)({outletId:t?.id||1,dateRange:{start_date:(0,T.GP)(tl.from,"yyyy-MM-dd"),end_date:(0,T.GP)(tl.to,"yyyy-MM-dd")}});if(!e?.data){j({title:"Error",description:"Tidak ada data yang tersedia untuk diekspor",variant:"destructive"});return}let a=e.data.summary?.total_sales||1,r=[["Periode",`${(0,T.GP)(tl.from,"dd/MM/yyyy")} - ${(0,T.GP)(tl.to,"dd/MM/yyyy")}`],["Outlet",t?.name||"Semua Outlet"],[]],s=[];e.data.members?.forEach(t=>{t.products?.forEach(e=>{s.push([`"${t.member_name||"Pelanggan Umum"}"`,t.total_orders,`"Rp ${Number(t.total_spent).toLocaleString("id-ID")}"`,`"${(t.total_spent/a*100).toFixed(2)}%"`,`"${e.product_name}"`,`"${e.category}"`,e.quantity,`"Rp ${Number(e.total_spent).toLocaleString("id-ID")}"`])})});let n=[...r.map(t=>t.join(",")),"Nama Pelanggan,Total Transaksi,Total Belanja,Persentase Kontribusi,Nama Produk,Kategori,Kuantitas,Total Belanja Produk",...s.map(t=>t.join(","))].join("\n"),d=new Blob([n],{type:"text/csv;charset=utf-8;"}),i=URL.createObjectURL(d),o=document.createElement("a");o.href=i,o.setAttribute("download",`Laporan_Penjualan_Pelanggan_${(0,T.GP)(th.from,"yyyyMMdd")}_${(0,T.GP)(th.to,"yyyyMMdd")}.csv`),document.body.appendChild(o),o.click(),document.body.removeChild(o),j({title:"Sukses",description:"Data berhasil diekspor ke CSV",variant:"default"})}catch(t){console.error("Export error:",t),j({title:"Error",description:"Gagal mengeksport data",variant:"destructive"})}finally{f(!1)}},tY=async()=>{if(y){f(!0),L(null);try{let t=(0,T.GP)(th.from,"yyyy-MM-dd"),e=(0,T.GP)(th.to,"yyyy-MM-dd"),a=await fetch(`http://kifa-bakery-backend.test/api/reports/monthly-sales/${y}?start_date=${t}&end_date=${e}`,{headers:{Accept:"application/json",Authorization:`Bearer ${tT}`,"Content-Type":"application/json"}});if(!a.ok)throw Error("Failed to fetch product data");let r=await a.json();r.status&&r.data?(J(r.data.products||[]),r.data.summary&&to(r.data.summary)):(J([]),to(null))}catch(t){L(t.message||"Terjadi kesalahan saat mengambil data")}finally{f(!1)}}},tJ=async()=>{if(!y||!th.from||!th.to){L("Harap pilih outlet dan tanggal terlebih dahulu");return}f(!0),L(null);try{let t=(0,T.GP)(th.from,"yyyy-MM-dd"),e=(0,T.GP)(th.to,"yyyy-MM-dd"),a=await fetch(`http://kifa-bakery-backend.test/api/reports/monthly-inventory/${y}?start_date=${t}&end_date=${e}`,{headers:{Authorization:`Bearer ${tT}`,"Content-Type":"application/json"}});if(!a.ok)throw Error(`Error ${a.status}: ${a.statusText}`);let r=await a.json();if(console.log("Full API Response:",r),!r?.data?.products)throw Error("Struktur data tidak valid: products tidak ditemukan");let s={data:{outlet:r.data.outlet||"Outlet Tidak Diketahui",periode:r.data.periode||{start_date:t,end_date:e},products:r.data.products.map(t=>({...t,product_name:t.product_name||"Produk Tanpa Nama",product_code:t.product_code||"TANPA-KODE",saldo_awal:Number(t.saldo_awal)||0,stock_masuk:Number(t.stock_masuk)||0,stock_keluar:Number(t.stock_keluar)||0,stock_akhir:Number(t.stock_akhir)||0,stock_aktual:Number(t.stock_aktual)||0,selisih:Number(t.selisih)||0})),summary:r.data.summary||{total_saldo_awal:r.data.products.reduce((t,e)=>t+(Number(e.saldo_awal)||0),0),total_stock_masuk:r.data.products.reduce((t,e)=>t+(Number(e.stock_masuk)||0),0),total_stock_keluar:r.data.products.reduce((t,e)=>t+(Number(e.stock_keluar)||0),0),total_stock_akhir:r.data.products.reduce((t,e)=>t+(Number(e.stock_akhir)||0),0)}}};tP(s)}catch(t){console.error("Error fetching inventory data:",t),L(t.message||"Gagal memuat data stok"),tP({data:{outlet:"",periode:{start_date:(0,T.GP)(th.from,"yyyy-MM-dd"),end_date:(0,T.GP)(th.to,"yyyy-MM-dd")},products:[],summary:{total_saldo_awal:0,total_stock_masuk:0,total_stock_keluar:0,total_stock_akhir:0}}})}finally{f(!1)}};return(0,r.jsxs)("div",{className:"flex flex-col space-y-4",children:[(0,r.jsxs)("div",{className:"flex items-center justify-between",children:[(0,r.jsx)("h2",{className:"text-3xl font-bold tracking-tight",children:"Laporan dan Analitik"}),(0,r.jsxs)("div",{className:"flex items-center space-x-2",children:[(0,r.jsxs)($.$,{variant:"outline",onClick:()=>{"monthly"===h?tD():"stock"===h?tA():"kategori"===h?tq():"dailySales"===h?tG():"perday"===h?tG():"realtime"===h?tW():"productByMember"===h?tz():"approve"===h&&tH()},children:[(0,r.jsx)(E.A,{className:"mr-2 h-4 w-4"}),"Cetak"]}),(0,r.jsxs)($.$,{variant:"outline",onClick:()=>{"monthly"===h?tL():"stock"===h?tR():"kategori"===h?tE():"dailySales"===h?tO():"perday"===h?tO():"realtime"===h?tZ():"productByMember"===h?tU():"approve"===h&&tK()},children:[(0,r.jsx)(G.A,{className:"mr-2 h-4 w-4"}),"Ekspor"]})]})]}),t&&"all"!==y&&(0,r.jsxs)(B.Fc,{children:[(0,r.jsx)(O.A,{className:"h-4 w-4"}),(0,r.jsxs)(B.XL,{children:["Menampilkan laporan untuk: ",t.name]}),(0,r.jsxs)(B.TN,{children:["Data yang ditampilkan adalah khusus untuk outlet"," ",t.name,"."]})]}),(0,r.jsxs)(Z.tU,{value:h,onValueChange:t=>{o.push(`/dashboard/reports?tab=${t}`)},className:"w-full",children:[(0,r.jsx)(Z.av,{value:"dailySales",className:"space-y-4",children:(0,r.jsxs)(M.Zp,{children:[(0,r.jsxs)(M.aR,{children:[(0,r.jsx)(M.ZB,{children:"Analisis Penjualan"}),(0,r.jsxs)(M.BT,{children:["Detail penjualan per hari","all"!==y&&t&&` untuk ${t.name}`]})]}),(0,r.jsxs)(M.Wu,{className:"space-y-4",children:[(0,r.jsx)("div",{className:"flex items-center space-x-4",children:(0,r.jsx)("div",{className:"grid grid-cols-2 gap-4",children:(0,r.jsx)(N.U,{value:tu,onChange:t=>{let{from:e,to:a}=t;e&&a&&e>a&&tm({from:e,to:e}),t_()}})})}),tw&&(0,r.jsxs)("div",{className:"grid grid-cols-4 gap-4",children:[(0,r.jsxs)("div",{className:"rounded-lg border p-4",children:[(0,r.jsx)("h3",{className:"text-sm font-medium",children:"Total Penjualan"}),(0,r.jsxs)("p",{className:"text-2xl font-bold",children:["Rp ",tw?.data.summary.total_sales.toLocaleString()]})]}),(0,r.jsxs)("div",{className:"rounded-lg border p-4",children:[(0,r.jsx)("h3",{className:"text-sm font-medium",children:"Total Order"}),(0,r.jsx)("p",{className:"text-2xl font-bold",children:tw?.data.summary.total_orders})]}),(0,r.jsxs)("div",{className:"rounded-lg border p-4",children:[(0,r.jsx)("h3",{className:"text-sm font-medium",children:"Total Item"}),(0,r.jsx)("p",{className:"text-2xl font-bold",children:tw?.data.summary.total_items})]}),(0,r.jsxs)("div",{className:"rounded-lg border p-4",children:[(0,r.jsx)("h3",{className:"text-sm font-medium",children:"Rata-rata Order"}),(0,r.jsxs)("p",{className:"text-2xl font-bold",children:["Rp ",tw?.data.summary.average_order_value.toLocaleString()]})]})]}),(0,r.jsxs)(P.XI,{children:[(0,r.jsx)(P.A0,{children:(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nd,{children:"Order ID"}),(0,r.jsx)(P.nd,{children:"Waktu"}),(0,r.jsx)(P.nd,{children:"Kasir"}),(0,r.jsx)(P.nd,{children:"Metode Pembayaran"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Total"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Aksi"})]})}),(0,r.jsx)(P.BF,{children:tw?.data.orders?.map(t=>r.jsxs(P.Hj,{children:[r.jsxs(P.nA,{children:["#",t.order_id]}),r.jsx(P.nA,{children:t.order_time}),r.jsx(P.nA,{children:t.cashier}),r.jsx(P.nA,{children:r.jsx(d.E,{variant:"outline",children:"cash"===t.payment_method?"Tunai":"Non-Tunai"})}),r.jsxs(P.nA,{className:"text-right",children:["Rp ",t.total.toLocaleString()]}),r.jsx(P.nA,{className:"text-right",children:r.jsx($.$,{variant:"ghost",size:"sm",children:r.jsx(i.A,{className:"h-4 w-4"})})})]},t.order_id))})]})]})]})}),(0,r.jsx)(Z.av,{value:"stock",className:"space-y-4",children:(0,r.jsxs)(M.Zp,{children:[(0,r.jsxs)(M.aR,{children:[(0,r.jsx)(M.ZB,{children:"Laporan Stok"}),(0,r.jsxs)(M.BT,{children:["Perubahan stok produk","all"!==y&&t&&` di ${t.name}`]}),(0,r.jsxs)("div",{className:"flex justify-between items-center mt-4",children:[(0,r.jsx)(N.U,{value:th,onChange:tN}),(0,r.jsx)($.$,{onClick:tJ,children:"Terapkan"})]})]}),(0,r.jsx)(M.Wu,{className:"space-y-4",children:b?(0,r.jsx)("div",{className:"flex justify-center items-center py-8",children:(0,r.jsx)("p",{children:"Memuat data..."})}):S?(0,r.jsxs)(B.Fc,{variant:"destructive",children:[(0,r.jsx)(B.XL,{children:"Error"}),(0,r.jsx)(B.TN,{children:S})]}):(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)("div",{className:"mb-6",children:[(0,r.jsxs)("h3",{className:"text-lg font-semibold mb-4",children:["Periode: ",tM?.data?.periode.start_date," s/d ",tM?.data?.periode.end_date]}),(0,r.jsxs)("div",{className:"grid grid-cols-4 gap-4 mb-6",children:[(0,r.jsx)(tS,{title:"Total Saldo Awal",value:`${tM?.data?.summary.total_saldo_awal} pcs`,icon:(0,r.jsx)(l,{className:"h-4 w-4"})}),(0,r.jsx)(tS,{title:"Total Stock Masuk",value:`${tM?.data?.summary.total_stock_masuk} pcs`,icon:(0,r.jsx)(c,{className:"h-4 w-4"})}),(0,r.jsx)(tS,{title:"Total Stock Keluar",value:`${tM?.data?.summary.total_stock_keluar} pcs`,icon:(0,r.jsx)(u,{className:"h-4 w-4"})}),(0,r.jsx)(tS,{title:"Total Stock Akhir",value:`${tM?.data?.summary.total_stock_akhir} pcs`,icon:(0,r.jsx)(m,{className:"h-4 w-4"})})]}),(0,r.jsx)(D.p,{placeholder:"Cari Produk",className:"w-80 mb-4",onChange:t$}),(0,r.jsxs)(P.XI,{children:[(0,r.jsx)(P.A0,{children:(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nd,{children:"Produk"}),(0,r.jsx)(P.nd,{children:"Satuan"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Saldo Awal"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Stock Masuk"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Stock Keluar"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Stock Akhir"})]})}),(0,r.jsx)(P.BF,{children:tr.map(t=>(0,r.jsxs)(P.Hj,{children:[(0,r.jsxs)(P.nA,{children:[(0,r.jsx)("div",{className:"font-medium",children:t.product_name}),(0,r.jsx)("div",{className:"text-sm text-muted-foreground",children:t.product_code})]}),(0,r.jsx)(P.nA,{className:"text-right",children:t.unit}),(0,r.jsx)(P.nA,{className:"text-right",children:t.saldo_awal}),(0,r.jsx)(P.nA,{className:"text-right",children:t.stock_masuk}),(0,r.jsx)(P.nA,{className:"text-right",children:t.stock_keluar}),(0,r.jsx)(P.nA,{className:"text-right",children:t.stock_akhir})]},t.product_id))})]})]}),(0,r.jsxs)("div",{className:"grid gap-4 md:grid-cols-2",children:[(0,r.jsxs)(M.Zp,{children:[(0,r.jsx)(M.aR,{children:(0,r.jsx)(M.ZB,{children:"Produk Dengan Stock Masuk Terbanyak"})}),(0,r.jsx)(M.Wu,{children:(0,r.jsxs)(P.XI,{children:[(0,r.jsx)(P.A0,{children:(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nd,{children:"Produk"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Qty"})]})}),(0,r.jsx)(P.BF,{children:[...tM?.data?.products].sort((t,e)=>e.stock_masuk-t.stock_masuk).slice(0,5).map(t=>(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nA,{className:"font-medium",children:t.product_name}),(0,r.jsx)(P.nA,{className:"text-right",children:t.stock_masuk})]},t.product_id))})]})})]}),(0,r.jsxs)(M.Zp,{children:[(0,r.jsx)(M.aR,{children:(0,r.jsx)(M.ZB,{children:"Produk Dengan Stock Keluar Terbanyak"})}),(0,r.jsx)(M.Wu,{children:(0,r.jsxs)(P.XI,{children:[(0,r.jsx)(P.A0,{children:(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nd,{children:"Produk"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Qty"})]})}),(0,r.jsx)(P.BF,{children:[...tM?.data?.products].sort((t,e)=>e.stock_keluar-t.stock_keluar).slice(0,5).map(t=>(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nA,{children:t.product_name}),(0,r.jsx)(P.nA,{className:"text-right",children:t.stock_keluar})]},t.product_id))})]})})]})]})]})})]})}),(0,r.jsx)(Z.av,{value:"monthly",className:"space-y-4",children:(0,r.jsxs)(M.Zp,{children:[(0,r.jsxs)(M.aR,{children:[(0,r.jsx)(M.ZB,{children:"Daftar Produk"}),(0,r.jsxs)(M.BT,{children:["Daftar produk berdasarkan rentang tanggal","all"!==y&&t&&` untuk ${t.name}`]}),(0,r.jsxs)("div",{className:"flex justify-between items-center mt-4",children:[(0,r.jsx)(N.U,{value:th,onChange:tN}),(0,r.jsx)($.$,{onClick:tY,children:"Terapkan"})]})]}),(0,r.jsx)(M.Wu,{children:b?(0,r.jsx)("div",{className:"flex justify-center items-center py-8",children:(0,r.jsx)("p",{children:"Memuat data..."})}):S?(0,r.jsxs)(B.Fc,{variant:"destructive",children:[(0,r.jsx)(B.XL,{children:"Error"}),(0,r.jsx)(B.TN,{children:S})]}):Y?.length===0?(0,r.jsx)("p",{className:"text-center py-8",children:"Tidak ada data yang tersedia"}):(0,r.jsxs)(r.Fragment,{children:[ti&&(0,r.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-4 gap-4 mb-6",children:[(0,r.jsxs)(M.Zp,{children:[(0,r.jsx)(M.aR,{className:"pb-2",children:(0,r.jsx)(M.ZB,{className:"text-sm font-medium",children:"Total Penjualan"})}),(0,r.jsx)(M.Wu,{children:(0,r.jsxs)("p",{className:"text-2xl font-bold",children:["Rp ",ti.total_sales?.toLocaleString()]})})]}),(0,r.jsxs)(M.Zp,{children:[(0,r.jsx)(M.aR,{className:"pb-2",children:(0,r.jsx)(M.ZB,{className:"text-sm font-medium",children:"Total Kuantitas"})}),(0,r.jsx)(M.Wu,{children:(0,r.jsx)("p",{className:"text-2xl font-bold",children:ti.total_quantity?.toLocaleString()})})]}),(0,r.jsxs)(M.Zp,{children:[(0,r.jsx)(M.aR,{className:"pb-2",children:(0,r.jsx)(M.ZB,{className:"text-sm font-medium",children:"Total Transaksi"})}),(0,r.jsx)(M.Wu,{children:(0,r.jsx)("p",{className:"text-2xl font-bold",children:ti.total_orders?.toLocaleString()})})]}),(0,r.jsxs)(M.Zp,{children:[(0,r.jsx)(M.aR,{className:"pb-2",children:(0,r.jsx)(M.ZB,{className:"text-sm font-medium",children:"Rata-rata Transaksi"})}),(0,r.jsx)(M.Wu,{children:(0,r.jsxs)("p",{className:"text-2xl font-bold",children:["Rp ",ti.average_order_value?.toLocaleString()]})})]})]}),(0,r.jsx)(D.p,{placeholder:"Cari Produk",className:"w-80 mb-4",onChange:t$}),(0,r.jsxs)(P.XI,{children:[(0,r.jsx)(P.A0,{children:(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nd,{children:"SKU"}),(0,r.jsx)(P.nd,{children:"Nama Produk"}),(0,r.jsx)(P.nd,{children:"Kategori"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Jumlah Order"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Total Kuantitas"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Total Penjualan"}),(0,r.jsx)(P.nd,{className:"text-right",children:"Kontribusi (%)"})]})}),(0,r.jsx)(P.BF,{children:te.map((t,e)=>(0,r.jsxs)(P.Hj,{children:[(0,r.jsx)(P.nA,{children:t.sku}),(0,r.jsx)(P.nA,{children:t.product_name}),(0,r.jsx)(P.nA,{children:t.category_name||"-"}),(0,r.jsx)(P.nA,{className:"text-right",children:t.order_count.toLocaleString()}),(0,r.jsx)(P.nA,{className:"text-right",children:t.total_quantity.toLocaleString()}),(0,r.jsxs)(P.nA,{className:"text-right",children:["Rp ",t.total_sales.toLocaleString()]}),(0,r.jsxs)(P.nA,{className:"text-right",children:[t.sales_percentage,"%"]})]},t.id||e))})]})]})})]})}),(0,r.jsx)(Z.av,{value:"kategori",className:"space-y-4",children:(0,r.jsxs)(M.Zp,{children:[(0,r.jsxs)(M.aR,{children:[(0,r.jsx)(M.ZB,{children:"Penjualan Per Kategori"}),(0,r.jsx)(M.BT,{children:"Data penjualan produk dikelompokkan per kategori"}),(0,r.jsxs)("div",{className:"flex justify-between items-center mt-4",children:[(0,r.jsx)(N.U,{value:th,onChange:tN}),(0,r.jsx)($.$,{onClick:tY,children:"Terapkan"})]})]}),(0,r.jsx)(M.Wu,{children:b?(0,r.jsx)("div",{className:"flex justify-center items-center h-64",children:(0,r.jsx)(k.A,{className:"h-8 w-8 animate-spin"})}):S?(0,r.jsxs)("div",{className:"text-red-500 text-center py-4",children:["Error: ",S.message]}):tv?.data?.categories?(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)("div",{className:"mb-6",children:(0,r.jsx)(I.u,{width:"100%",height:350,children:(0,r.jsxs)(C.E,{data:tv.data.categories.map(t=>({name:t.category_name,penjualan:Number(t.total_sales)})),children:[(0,r.jsx)(H.W,{dataKey:"name",stroke:"#888888",fontSize:12,tickLine:!1,axisLine:!1}),(0,r.jsx)(K.h,{stroke:"#888888",fontSize:12,tickLine:!1,axisLine:!1,tickFormatter:t=>`Rp ${t.toLocaleString("id-ID")}`}),(0,r.jsx)(F.y,{dataKey:"penjualan",fill:"currentColor",radius:[4,4,0,0],className:"fill-primary"})]})})}),(0,r.jsx)(D.p,{placeholder:"Cari Kategori",className:"w-80 mb-4",onChange:t$}),(0,r.jsx)("div",{className:"space-y-6",children:tn?.map(t=>r.jsxs("div",{className:"border rounded-lg",children:[r.jsxs("div",{className:"p-4 bg-gray-50 flex justify-between items-center",children:[r.jsxs("div",{children:[r.jsx("h3",{className:"font-medium",children:t.category_name}),r.jsxs("p",{className:"text-sm text-gray-500",children:[t.products.length," produk terjual"]})]}),r.jsxs("div",{className:"text-right",children:[r.jsxs("p",{className:"font-medium",children:["Rp ",Number(t.total_sales).toLocaleString("id-ID")]}),r.jsxs("p",{className:"text-sm text-gray-500",children:[t.sales_percentage.toFixed(2),"% dari total"]})]})]}),r.jsxs(P.XI,{children:[r.jsx(P.A0,{children:r.jsxs(P.Hj,{children:[r.jsx(P.nd,{children:"Produk"}),r.jsx(P.nd,{className:"text-right",children:"SKU"}),r.jsx(P.nd,{className:"text-right",children:"Kuantitas"}),r.jsx(P.nd,{className:"text-right",children:"Penjualan"}),r.jsx(P.nd,{className:"text-right",children:"% Kategori"})]})}),r.jsx(P.BF,{children:t.products.map(t=>r.jsxs(P.Hj,{children:[r.jsx(P.nA,{className:"font-medium",children:t.product_name}),r.jsx(P.nA,{className:"text-right",children:t.product_sku}),r.jsx(P.nA,{className:"text-right",children:Number(t.quantity)}),r.jsxs(P.nA,{className:"text-right",children:["Rp ",Number(t.sales).toLocaleString("id-ID")]}),r.jsxs(P.nA,{className:"text-right",children:[t.sales_percentage.toFixed(2),"%"]})]},t.product_id))})]})]},t.category_id))}),(0,r.jsx)("div",{className:"mt-6 p-4 bg-gray-50 rounded-lg",children:(0,r.jsxs)("div",{className:"grid grid-cols-4 gap-4",children:[(0,r.jsxs)("div",{children:[(0,r.jsx)("p",{className:"text-sm text-gray-500",children:"Total Kategori"}),(0,r.jsx)("p",{className:"font-medium",children:tv.data.summary.total_categories})]}),(0,r.jsxs)("div",{children:[(0,r.jsx)("p",{className:"text-sm text-gray-500",children:"Total Produk Terjual"}),(0,r.jsx)("p",{className:"font-medium",children:tv.data.summary.total_products})]}),(0,r.jsxs)("div",{children:[(0,r.jsx)("p",{className:"text-sm text-gray-500",children:"Total Kuantitas"}),(0,r.jsx)("p",{className:"font-medium",children:tv.data.summary.total_quantity})]}),(0,r.jsxs)("div",{children:[(0,r.jsx)("p",{className:"text-sm text-gray-500",children:"Total Penjualan"}),(0,r.jsxs)("p",{className:"font-medium",children:["Rp ",Number(tv.data.summary.total_sales).toLocaleString("id-ID")]})]})]})})]}):(0,r.jsx)("div",{className:"text-center py-4",children:"Tidak ada data penjualan"})})]})}),"perday"===h&&(0,r.jsx)(ei,{dateRange:tg,setDateRange:tb}),"realtime"===h&&(0,r.jsx)(R,{dateRange:tf,setDateRange:tj}),"approve"===h&&(0,r.jsx)(V,{date:tx,setDate:ty}),"productByMember"===h&&(0,r.jsx)(q,{dateRange:tl,setDateRange:tc})]})]})}},60363:(t,e,a)=>{"use strict";a.d(e,{Fc:()=>o,TN:()=>c,XL:()=>l});var r=a(18652),s=a(9861),n=a(13801),d=a(28070);let i=(0,n.F)("relative w-full rounded-lg border p-4 [&>svg~*]:pl-7 [&>svg+div]:translate-y-[-3px] [&>svg]:absolute [&>svg]:left-4 [&>svg]:top-4 [&>svg]:text-foreground",{variants:{variant:{default:"bg-background text-foreground",destructive:"border-destructive/50 text-destructive dark:border-destructive [&>svg]:text-destructive"}},defaultVariants:{variant:"default"}}),o=s.forwardRef(({className:t,variant:e,...a},s)=>(0,r.jsx)("div",{ref:s,role:"alert",className:(0,d.cn)(i({variant:e}),t),...a}));o.displayName="Alert";let l=s.forwardRef(({className:t,...e},a)=>(0,r.jsx)("h5",{ref:a,className:(0,d.cn)("mb-1 font-medium leading-none tracking-tight",t),...e}));l.displayName="AlertTitle";let c=s.forwardRef(({className:t,...e},a)=>(0,r.jsx)("div",{ref:a,className:(0,d.cn)("text-sm [&_p]:leading-relaxed",t),...e}));c.displayName="AlertDescription"},45502:(t,e,a)=>{"use strict";a.d(e,{U:()=>c});var r=a(18652);a(9861);var s=a(44066),n=a(52801),d=a(28070),i=a(80429),o=a(99647),l=a(72382);function c({className:t,value:e,onChange:a}){return(0,r.jsx)("div",{className:(0,d.cn)("grid gap-2",t),children:(0,r.jsxs)(l.AM,{children:[(0,r.jsx)(l.Wv,{asChild:!0,children:(0,r.jsxs)(i.$,{id:"date",variant:"outline",className:(0,d.cn)("w-[300px] justify-start text-left font-normal",!e&&"text-muted-foreground"),children:[(0,r.jsx)(s.A,{className:"mr-2 h-4 w-4"}),e?.from?e.to?(0,r.jsxs)(r.Fragment,{children:[(0,n.GP)(e.from,"dd MMM yyyy")," -"," ",(0,n.GP)(e.to,"dd MMM yyyy")]}):(0,n.GP)(e.from,"dd MMM yyyy"):(0,r.jsx)("span",{children:"Pilih rentang tanggal"})]})}),(0,r.jsx)(l.hl,{className:"w-auto p-0",align:"start",children:(0,r.jsx)(o.V,{initialFocus:!0,mode:"range",defaultMonth:e?.from,selected:e,onSelect:a,numberOfMonths:2})})]})})}},69978:(t,e,a)=>{"use strict";a.d(e,{F:()=>i});var r=a(18652),s=a(9861),n=a(99350),d=a(28070);let i=s.forwardRef(({className:t,children:e,...a},s)=>(0,r.jsxs)(n.bL,{ref:s,className:(0,d.cn)("relative overflow-hidden",t),...a,children:[(0,r.jsx)(n.LM,{className:"h-full w-full rounded-[inherit]",children:e}),(0,r.jsx)(o,{}),(0,r.jsx)(n.OK,{})]}));i.displayName=n.bL.displayName;let o=s.forwardRef(({className:t,orientation:e="vertical",...a},s)=>(0,r.jsx)(n.VM,{ref:s,orientation:e,className:(0,d.cn)("flex touch-none select-none transition-colors","vertical"===e&&"h-full w-2.5 border-l border-l-transparent p-[1px]","horizontal"===e&&"h-2.5 flex-col border-t border-t-transparent p-[1px]",t),...a,children:(0,r.jsx)(n.lr,{className:"relative flex-1 rounded-full bg-border"})}));o.displayName=n.VM.displayName},54761:(t,e,a)=>{"use strict";a.d(e,{Xi:()=>l,av:()=>c,j7:()=>o,tU:()=>i});var r=a(18652),s=a(9861),n=a(3975),d=a(28070);let i=n.bL,o=s.forwardRef(({className:t,...e},a)=>(0,r.jsx)(n.B8,{ref:a,className:(0,d.cn)("inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground",t),...e}));o.displayName=n.B8.displayName;let l=s.forwardRef(({className:t,...e},a)=>(0,r.jsx)(n.l9,{ref:a,className:(0,d.cn)("inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm",t),...e}));l.displayName=n.l9.displayName;let c=s.forwardRef(({className:t,...e},a)=>(0,r.jsx)(n.UC,{ref:a,className:(0,d.cn)("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",t),...e}));c.displayName=n.UC.displayName},82984:(t,e,a)=>{"use strict";a.d(e,{A:()=>r});let r=(0,a(27277).A)("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]])},986:(t,e,a)=>{"use strict";a.d(e,{$l:()=>b,Gw:()=>m,K9:()=>u,Ke:()=>p,Ub:()=>c,gQ:()=>x,nO:()=>h,uv:()=>g});var r=a(3953),s=a(52801),n=a(63288),d=a(89080);let i="http://kifa-bakery-backend.test/api",o=(0,d.getCookie)("access_token"),l=async({queryKey:t})=>{let[e]=t,a=await fetch(`${i}${e}`,{headers:{Authorization:`Bearer ${o}`,"Content-Type":"application/json"}});if(!a.ok)throw Error("Network response was not ok");return a.json()},c=t=>{let e=t.dateRange?.start_date,a=t.dateRange?.end_date??e;return(0,r.G)(`/inventory-histories/stock/${t.outletId}?start_date=${e}&end_date=${a}`,["realtime-stock"])},u=t=>{let e=t.dateRange?.start_date,a=t.dateRange?.end_date??e;return(0,r.G)(`/inventory-histories/type/${t.outletId}?start_date=${e}&end_date=${a}`,["realtime-stock"])},m=(t,e)=>(0,r.G)(`/reports/inventory-by-date/${t}?date=${e}`,["inventory-by-date",e,t.toString()])(),h=(t,e)=>{let a=new URLSearchParams;e?.from&&a.append("start_date",e.from.toISOString().split("T")[0]),e?.to&&a.append("end_date",e.to.toISOString().split("T")[0]);let s=a.toString()?`?${a.toString()}`:"";return(0,r.G)(`/reports/dashboard-summary/${t}${s}`,["dashboard-report",t.toString(),e?.from?.toString(),e?.to?.toString()])()},p=(t,e)=>{let a=new URLSearchParams;e?.from&&a.append("start_date",(0,s.GP)(e.from,"yyyy-MM-dd")),e?.to&&a.append("end_date",(0,s.GP)(e.to,"yyyy-MM-dd"));let r=`/reports/sales-by-category/${t}?${a.toString()}`;return{queryKey:["sales-by-category",t,e?.from?.toString(),e?.to?.toString()],queryFn:()=>l({queryKey:[r]})}},x=(t,e,a)=>({queryKey:["daily-sales",t.toString()],queryFn:async()=>{let r=await fetch(`${i}/reports/daily-sales/${t}?start_date=${e}&end_date=${a}`,{headers:{Authorization:`Bearer ${o}`}});if(!r.ok)throw Error("Network response was not ok");return r.json()}}),y=(t,e,a)=>({queryKey:["inventory-approvals",t,e,a],queryFn:async()=>{let r=await fetch(`${i}/reports/inventory-approvals/${t}?start_date=${e}&end_date=${a}`,{headers:{Authorization:`Bearer ${o}`}});if(!r.ok)throw Error("Network response was not ok");let s=await r.json();if(!s)throw Error("Response data is undefined");return s},enabled:!!t&&!!e&&!!a}),g=(t,e,a)=>{let r=e?(0,s.GP)(e,"yyyy-MM-dd"):"",d=a?(0,s.GP)(a,"yyyy-MM-dd"):"";return(0,n.I)(y(t??0,r,d))},b=t=>{let e=t.dateRange.start_date,a=t.dateRange.end_date;return e&&a?fetch(`${i}/reports/sales-by-member/${t.outletId}?start_date=${e}&end_date=${a}`,{headers:{Authorization:`Bearer ${o}`}}).then(t=>t.json()):Promise.reject(Error("Invalid date range"))}},22396:(t,e,a)=>{"use strict";a.r(e),a.d(e,{default:()=>n});var r=a(48408),s=a(35027);function n(){return(0,r.jsxs)("div",{className:"flex flex-col space-y-4",children:[(0,r.jsx)(s.ym,{}),(0,r.jsxs)("div",{className:"flex items-center space-x-4",children:[(0,r.jsx)("div",{className:"flex-1",children:(0,r.jsx)("div",{className:"h-10 w-full rounded-md border border-input bg-background px-3 py-2"})}),(0,r.jsx)("div",{className:"flex-1",children:(0,r.jsx)("div",{className:"h-10 w-full rounded-md border border-input bg-background px-3 py-2"})})]}),(0,r.jsx)(s.ci,{tabs:5}),(0,r.jsx)(s.Tt,{}),(0,r.jsxs)("div",{className:"grid gap-4 md:grid-cols-2 lg:grid-cols-7",children:[(0,r.jsx)("div",{className:"col-span-4",children:(0,r.jsx)(s.Qv,{})}),(0,r.jsx)("div",{className:"col-span-3",children:(0,r.jsx)(s.Qv,{})})]})]})}},52919:(t,e,a)=>{"use strict";a.r(e),a.d(e,{default:()=>r});let r=(0,a(44444).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\aku\\\\kifa-bakery-frontend\\\\app\\\\dashboard\\\\reports\\\\page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\aku\\kifa-bakery-frontend\\app\\dashboard\\reports\\page.tsx","default")},22843:(t,e,a)=>{"use strict";function r(t,[e,a]){return Math.min(a,Math.max(e,t))}a.d(e,{q:()=>r})}};var e=require("../../../webpack-runtime.js");e.C(t);var a=t=>e(e.s=t),r=e.X(0,[660,369,794,252,303,801,18,127,355,812,586,342],()=>a(4531));module.exports=r})();
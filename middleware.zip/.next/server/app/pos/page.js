(()=>{var e={};e.id=807,e.ids=[807],e.modules={10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},12412:e=>{"use strict";e.exports=require("assert")},55511:e=>{"use strict";e.exports=require("crypto")},94735:e=>{"use strict";e.exports=require("events")},29021:e=>{"use strict";e.exports=require("fs")},81630:e=>{"use strict";e.exports=require("http")},55591:e=>{"use strict";e.exports=require("https")},33873:e=>{"use strict";e.exports=require("path")},27910:e=>{"use strict";e.exports=require("stream")},79551:e=>{"use strict";e.exports=require("url")},28354:e=>{"use strict";e.exports=require("util")},74075:e=>{"use strict";e.exports=require("zlib")},3411:(e,t,a)=>{"use strict";a.r(t),a.d(t,{GlobalError:()=>n.a,__next_app__:()=>m,pages:()=>c,routeModule:()=>u,tree:()=>o});var s=a(88832),r=a(33471),i=a(83127),n=a.n(i),d=a(50280),l={};for(let e in d)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>d[e]);a.d(t,l);let o=["",{children:["pos",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,90909)),"D:\\aku\\kifa-bakery-frontend\\app\\pos\\page.tsx"]}]},{layout:[()=>Promise.resolve().then(a.bind(a,28678)),"D:\\aku\\kifa-bakery-frontend\\app\\pos\\layout.tsx"],loading:[()=>Promise.resolve().then(a.bind(a,30206)),"D:\\aku\\kifa-bakery-frontend\\app\\pos\\loading.tsx"],metadata:{icon:[async e=>(await Promise.resolve().then(a.bind(a,23913))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(a.bind(a,97755)),"D:\\aku\\kifa-bakery-frontend\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(a.bind(a,20583)),"D:\\aku\\kifa-bakery-frontend\\app\\not-found.tsx"],forbidden:[()=>Promise.resolve().then(a.t.bind(a,2456,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(a.t.bind(a,13305,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(a.bind(a,23913))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],c=["D:\\aku\\kifa-bakery-frontend\\app\\pos\\page.tsx"],m={require:a,loadChunk:()=>Promise.resolve()},u=new s.AppPageRouteModule({definition:{kind:r.RouteKind.APP_PAGE,page:"/pos/page",pathname:"/pos",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:o}})},55828:(e,t,a)=>{Promise.resolve().then(a.bind(a,90909))},58036:(e,t,a)=>{Promise.resolve().then(a.bind(a,34034))},12766:()=>{},52934:()=>{},65225:()=>{},7081:()=>{},34034:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>ti});var s,r=a(18652),i=a(9861),n=a(5988),d=a(80429),l=a(28427),o=a(62657),c=a(70576),m=a(45617),u=a(69978),x=a(27191),p=a(47533),h=a(27277);let f=(0,h.A)("Menu",[["line",{x1:"4",x2:"20",y1:"12",y2:"12",key:"1e0a9i"}],["line",{x1:"4",x2:"20",y1:"6",y2:"6",key:"1owob3"}],["line",{x1:"4",x2:"20",y1:"18",y2:"18",key:"yk5zj1"}]]);var g=a(98812),v=a(56951),b=a(49411),j=a(57744),y=a(74574),N=a(94205),w=a(46579),k=a(30144),C=a(12695),S=a(17199),R=a(54605),$=a(91180),A=a(81633),_=a(14494),L=a(61573),P=a(13728),M=a(99317),q="Radio",[T,D]=(0,S.A)(q),[E,z]=T(q),B=i.forwardRef((e,t)=>{let{__scopeRadio:a,name:s,checked:n=!1,required:d,disabled:l,value:o="on",onCheck:c,form:m,...u}=e,[x,p]=i.useState(null),h=(0,C.s)(t,e=>p(e)),f=i.useRef(!1),g=!x||m||!!x.closest("form");return(0,r.jsxs)(E,{scope:a,checked:n,disabled:l,children:[(0,r.jsx)(R.sG.button,{type:"button",role:"radio","aria-checked":n,"data-state":O(n),"data-disabled":l?"":void 0,disabled:l,value:o,...u,ref:h,onClick:(0,k.m)(e.onClick,e=>{n||c?.(),g&&(f.current=e.isPropagationStopped(),f.current||e.stopPropagation())})}),g&&(0,r.jsx)(G,{control:x,bubbles:!f.current,name:s,value:o,checked:n,required:d,disabled:l,form:m,style:{transform:"translateX(-100%)"}})]})});B.displayName=q;var F="RadioIndicator",I=i.forwardRef((e,t)=>{let{__scopeRadio:a,forceMount:s,...i}=e,n=z(F,a);return(0,r.jsx)(M.C,{present:s||n.checked,children:(0,r.jsx)(R.sG.span,{"data-state":O(n.checked),"data-disabled":n.disabled?"":void 0,...i,ref:t})})});I.displayName=F;var G=e=>{let{control:t,checked:a,bubbles:s=!0,...n}=e,d=i.useRef(null),l=(0,P.Z)(a),o=(0,L.X)(t);return i.useEffect(()=>{let e=d.current,t=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"checked").set;if(l!==a&&t){let r=new Event("click",{bubbles:s});t.call(e,a),e.dispatchEvent(r)}},[l,a,s]),(0,r.jsx)("input",{type:"radio","aria-hidden":!0,defaultChecked:a,...n,tabIndex:-1,ref:d,style:{...e.style,...o,position:"absolute",pointerEvents:"none",opacity:0,margin:0}})};function O(e){return e?"checked":"unchecked"}var K=["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"],H="RadioGroup",[W,U]=(0,S.A)(H,[$.RG,D]),J=(0,$.RG)(),Z=D(),[V,Q]=W(H),X=i.forwardRef((e,t)=>{let{__scopeRadioGroup:a,name:s,defaultValue:i,value:n,required:d=!1,disabled:l=!1,orientation:o,dir:c,loop:m=!0,onValueChange:u,...x}=e,p=J(a),h=(0,_.jH)(c),[f,g]=(0,A.i)({prop:n,defaultProp:i,onChange:u});return(0,r.jsx)(V,{scope:a,name:s,required:d,disabled:l,value:f,onValueChange:g,children:(0,r.jsx)($.bL,{asChild:!0,...p,orientation:o,dir:h,loop:m,children:(0,r.jsx)(R.sG.div,{role:"radiogroup","aria-required":d,"aria-orientation":o,"data-disabled":l?"":void 0,dir:h,...x,ref:t})})})});X.displayName=H;var Y="RadioGroupItem",ee=i.forwardRef((e,t)=>{let{__scopeRadioGroup:a,disabled:s,...n}=e,d=Q(Y,a),l=d.disabled||s,o=J(a),c=Z(a),m=i.useRef(null),u=(0,C.s)(t,m),x=d.value===n.value,p=i.useRef(!1);return i.useEffect(()=>{let e=e=>{K.includes(e.key)&&(p.current=!0)},t=()=>p.current=!1;return document.addEventListener("keydown",e),document.addEventListener("keyup",t),()=>{document.removeEventListener("keydown",e),document.removeEventListener("keyup",t)}},[]),(0,r.jsx)($.q7,{asChild:!0,...o,focusable:!l,active:x,children:(0,r.jsx)(B,{disabled:l,required:d.required,checked:x,...c,...n,name:d.name,ref:u,onCheck:()=>d.onValueChange(n.value),onKeyDown:(0,k.m)(e=>{"Enter"===e.key&&e.preventDefault()}),onFocus:(0,k.m)(n.onFocus,()=>{p.current&&m.current?.click()})})})});ee.displayName=Y;var et=i.forwardRef((e,t)=>{let{__scopeRadioGroup:a,...s}=e,i=Z(a);return(0,r.jsx)(I,{...i,...s,ref:t})});et.displayName="RadioGroupIndicator";var ea=a(35036),es=a(28070);let er=i.forwardRef(({className:e,...t},a)=>(0,r.jsx)(X,{className:(0,es.cn)("grid gap-2",e),...t,ref:a}));er.displayName=X.displayName;let ei=i.forwardRef(({className:e,...t},a)=>(0,r.jsx)(ee,{ref:a,className:(0,es.cn)("aspect-square h-4 w-4 rounded-full border border-primary text-primary ring-offset-background focus:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50",e),...t,children:(0,r.jsx)(et,{className:"flex items-center justify-center",children:(0,r.jsx)(ea.A,{className:"h-2.5 w-2.5 fill-current text-current"})})}));ei.displayName=ee.displayName;let en=(0,h.A)("CircleCheckBig",[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335",key:"yps3ct"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]]);var ed=a(80658);let el=(0,h.A)("QrCode",[["rect",{width:"5",height:"5",x:"3",y:"3",rx:"1",key:"1tu5fj"}],["rect",{width:"5",height:"5",x:"16",y:"3",rx:"1",key:"1v8r4q"}],["rect",{width:"5",height:"5",x:"3",y:"16",rx:"1",key:"1x03jg"}],["path",{d:"M21 16h-3a2 2 0 0 0-2 2v3",key:"177gqh"}],["path",{d:"M21 21v.01",key:"ents32"}],["path",{d:"M12 7v3a2 2 0 0 1-2 2H7",key:"8crl2c"}],["path",{d:"M3 12h.01",key:"nlz23k"}],["path",{d:"M12 3h.01",key:"n36tog"}],["path",{d:"M12 16v.01",key:"133mhm"}],["path",{d:"M16 12h1",key:"1slzba"}],["path",{d:"M21 12v.01",key:"1lwtk9"}],["path",{d:"M12 21v-1",key:"1880an"}]]);var eo=a(92736),ec=a(21786),em=a(44138),eu=a(86960),ex=a(33131);let ep=(e,t,a)=>{let s=window.open("","_blank","width=400,height=600");if(s){let r=`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Struk Transaksi #${e.order_number}</title>
          <style>
            body {
              font-family: 'Courier New', monospace;
              margin: 0;
              padding: 20px;
              max-width: 300px;
            }
           .header {
              display: flex;
              align-items: center;
              gap: 15px;
              margin-bottom: 20px;
            }
            
            .header-text {
              flex: 1;
              text-align: right;
            }
            
            .logo-container {
              display: flex;
              align-items: center;
            }
            
            .logo {
              max-width: 50px;
              height: auto;
            }
            
            .title {
              font-size: 16px;
              font-weight: bold;
              margin-bottom: 4px;
            }
            .info {
              font-size: 12px;
              margin: 5px 0;
            }
            .divider {
              border-top: 1px dashed #000;
              margin: 10px 0;
            }
            .item {
              display: flex;
              justify-content: space-between;
              font-size: 12px;
              margin: 5px 0;
            }
            .total {
              font-weight: bold;
              margin-top: 10px;
              text-align: right;
            }
            .footer {
              text-align: center;
              margin-top: 20px;
              font-size: 12px;
            }
            .logo {
              max-width: 40px; 
              height: auto; 
              margin-bottom: 10px;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="logo-container">
              <img src="${a?.logo_url}" 
                  alt="Logo Outlet" 
                  class="logo"/>
            </div>
            <div class="header-text">
              <div class="title">${a?.company_name}</div>
              <div class="info">${a?.company_slogan}</div>
              <div class="info">${t.name}</div>
              <div class="info">Alamat: ${t.address}</div>
              <div class="info">Telp: ${t.phone}</div>
            </div>
          </div>

            <div class="divider"></div>
            <div class="info">No. Invoice: ${e.order_number}</div>
            <div class="info">Tanggal: ${e.created_at}</div>
            <div class="info">Kasir: ${e.user}</div>
          </div>
          <div class="divider"></div>
          <div>
            ${e.items.map(e=>`
              <div class="item">
                <div>${e.quantity}x ${e.product}</div>
                <div>
                  Rp ${Number(Number(e.price)*e.quantity).toLocaleString()}
                  ${Number(e.discount)>0?` (-${Number(e.discount).toLocaleString()})`:""}
                </div>
              </div>
              `).join("")}
              <div class="divider"></div>
              ${parseInt(e.tax)>0?`
                <div class="item">
                  <div>PPN:</div>
                  <div>Rp ${Number(e.tax).toLocaleString()}</div>
                </div>
                `:""}
          <div class="item">
            <div>Subtotal: </div>
            <div>Rp ${Number(e.subtotal).toLocaleString()}</div>
          </div>
          <div class="item">
            <div>Total Diskon:</div>
            <div>Rp -${Number(e.discount).toLocaleString()}</div>
          </div>
          </div>
          <div class="divider"></div>
          <div class="total">Total: Rp ${Number(e.total).toLocaleString()}</div>
          <div class="item">
            <div>Metode Pembayaran:</div>
            <div>${"cash"===e.payment_method?"TUNAI":"qris"===e.payment_method?"QRIS":"TRANSFER"}</div>
          </div>
           ${"cash"===e.payment_method?`
          <div class="item">
            <div>Bayar:</div>
            <div>Rp ${Number(e.total_paid).toLocaleString()}</div>
          </div>
          <div class="item">
            <div>Kembalian:</div>
            <div>Rp ${Number(e.change).toLocaleString()}</div>
          </div>
        `:""}
          <div class="divider"></div>
           ${e.member?`
            <div class="info">
                Member: ${e.member.name} (${e.member.member_code})
            </div>
        `:""}
          <div class="footer">
            ${a?.footer_message}
          </div>
        </body>
        </html>
      `;s.document.open(),s.document.write(r),s.document.close(),s.onload=function(){s.print()}}else console.error("Failed to open print window"),alert("Tidak dapat membuka jendela cetak. Periksa pengaturan popup browser Anda.")};var eh=a(31766),ef=a(72382),eg=a(89873),ev=a(40422),eb=a(6894);function ej({onMemberSelect:e}){let[t,a]=(0,i.useState)(!1),[s,n]=(0,i.useState)(null),[l,o]=(0,i.useState)(""),{data:c}=(0,eb.Zo)();if(!c)return null;let m=c.data.filter(e=>e.name.toLowerCase().includes(l.toLowerCase())),u=t=>{s?.id===t.id?(n(void 0),e(null)):(n(t),e(t)),a(!1),o("")};return(0,r.jsxs)(ef.AM,{open:t,onOpenChange:a,children:[(0,r.jsx)(ef.Wv,{asChild:!0,children:(0,r.jsxs)(d.$,{variant:"outline",role:"combobox","aria-expanded":t,className:"w-full justify-between",children:[s?(0,r.jsx)("span",{className:"truncate",children:s.name}):"Pilih member...",(0,r.jsx)(eg.A,{className:"ml-2 h-4 w-4 shrink-0 opacity-50"})]})}),(0,r.jsx)(ef.hl,{className:"w-full p-0",children:(0,r.jsxs)(eh.uB,{shouldFilter:!1,children:[(0,r.jsx)(eh.G7,{placeholder:"Cari member...",value:l,onValueChange:o}),(0,r.jsxs)(eh.oI,{children:[(0,r.jsx)(eh.xL,{children:"Tidak ditemukan member."}),(0,r.jsx)(eh.L$,{children:m.map(e=>(0,r.jsxs)(eh.h_,{value:e.name,onSelect:()=>u(e),children:[(0,r.jsx)(ev.A,{className:(0,es.cn)("mr-2 h-4 w-4",s?.id===e.id?"opacity-100":"opacity-0")}),(0,r.jsxs)("div",{className:"flex flex-col",children:[(0,r.jsx)("span",{className:"font-medium",children:e.name}),e.member_code&&(0,r.jsx)("span",{className:"text-xs text-gray-500",children:e.member_code})]})]},e.id))})]})]})})]})}var ey=a(46156);function eN({open:e,onOpenChange:t,total:a,refetchBalance:s,cart:n,onSuccess:l,tax:m,discount:x}){let[p,h]=(0,i.useState)("tunai"),[f,g]=(0,i.useState)(""),[v,b]=(0,i.useState)(!1),[y,k]=(0,i.useState)(!1),[C,S]=(0,i.useState)(null),[R,$]=(0,i.useState)(null),[A,_]=(0,i.useState)(0),{user:L}=(0,em.A)(),{mutate:P,isPending:M}=(0,ec.fS)(),{data:q}=(0,ey.r)(L?.outlet_id??0),{invalidate:T}=(0,eu.j)(),D=()=>{t(!1)},E=f?Number.parseInt(f):0,z=E-a,B=E>=a;return(0,r.jsx)(N.lG,{open:e,onOpenChange:t,children:(0,r.jsxs)(N.Cf,{className:"sm:max-w-[500px] max-h-[90vh] flex flex-col p-2",children:[(0,r.jsxs)(N.c7,{className:"px-3 pt-3",children:[(0,r.jsx)(N.L3,{className:"text-sm",children:"Pembayaran"}),(0,r.jsx)(N.rr,{className:"text-xs",children:"Selesaikan transaksi dengan memilih metode pembayaran"})]}),y?(0,r.jsxs)("div",{className:"py-4 text-center px-3",children:[(0,r.jsx)("div",{className:"inline-flex h-12 w-12 items-center justify-center rounded-full bg-green-100 mb-3",children:(0,r.jsx)(en,{className:"h-6 w-6 text-green-600"})}),(0,r.jsx)("h3",{className:"text-sm font-medium text-green-700",children:"Pembayaran Berhasil!"}),(0,r.jsx)("p",{className:"mt-1 text-xs text-muted-foreground",children:"Transaksi telah berhasil diselesaikan"}),(0,r.jsxs)("div",{className:"flex justify-center gap-5 mt-3",children:[(0,r.jsx)(d.$,{variant:"default",onClick:()=>ep(R,L?.outlet,q.data),children:"Cetak Struk"}),(0,r.jsx)(d.$,{variant:"outline",className:"text-destructive",onClick:D,children:"Tutup"})]})]}):(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)(u.F,{className:"flex-1 px-3 overflow-y-scroll",children:[(0,r.jsxs)("div",{className:"rounded-md bg-orange-50 p-3 mb-3",children:[(0,r.jsxs)("div",{className:"flex items-center justify-between font-medium text-xs",children:[(0,r.jsx)("span",{children:"Total Pembayaran"}),(0,r.jsxs)("span",{className:"text-base text-orange-600",children:["Rp ",a.toLocaleString()]})]}),(0,r.jsxs)("div",{className:"text-xs text-muted-foreground mt-1",children:[n.length," item dalam transaksi"]})]}),(0,r.jsx)(er,{value:p,onValueChange:h,className:"mb-3",children:(0,r.jsxs)("div",{className:"flex flex-col space-y-2",children:[(0,r.jsx)(w.J,{className:"text-xs font-medium",children:"Metode Pembayaran"}),(0,r.jsxs)("div",{className:"flex items-center space-x-2 border rounded-md p-2 cursor-pointer",onClick:()=>h("tunai"),children:[(0,r.jsx)(ei,{value:"tunai",id:"tunai"}),(0,r.jsx)(ed.A,{className:"h-3 w-3 text-orange-500 ml-1 mr-2"}),(0,r.jsx)(w.J,{htmlFor:"tunai",className:"cursor-pointer flex-1 text-xs",children:"Tunai"})]}),(0,r.jsxs)("div",{className:"flex items-center space-x-2 border rounded-md p-2 cursor-pointer",onClick:()=>h("transfer"),children:[(0,r.jsx)(ei,{value:"transfer",id:"transfer"}),(0,r.jsx)(j.A,{className:"h-3 w-3 text-orange-500 ml-1 mr-2"}),(0,r.jsx)(w.J,{htmlFor:"transfer",className:"cursor-pointer flex-1 text-xs",children:"Transfer"})]}),(0,r.jsxs)("div",{className:"flex items-center space-x-2 border rounded-md p-2 cursor-pointer",onClick:()=>h("qris"),children:[(0,r.jsx)(ei,{value:"qris",id:"qris"}),(0,r.jsx)(el,{className:"h-3 w-3 text-orange-500 ml-1 mr-2"}),(0,r.jsx)(w.J,{htmlFor:"qris",className:"cursor-pointer flex-1 text-xs",children:"QRIS"})]})]})}),"tunai"===p&&(0,r.jsxs)("div",{className:"space-y-2 mb-3",children:[(0,r.jsxs)("div",{className:"grid gap-1",children:[(0,r.jsx)(w.J,{htmlFor:"amount",className:"text-xs",children:"Jumlah Uang Diterima"}),(0,r.jsx)(o.p,{id:"amount",placeholder:"Masukkan jumlah uang",value:f?`Rp ${Number.parseInt(f).toLocaleString()}`:"",onChange:e=>{g(e.target.value.replace(/[^0-9]/g,""))},className:"border-orange-200 text-xs"})]}),f&&(0,r.jsxs)("div",{className:"rounded-md bg-muted p-2",children:[(0,r.jsxs)("div",{className:"flex justify-between mb-1",children:[(0,r.jsx)("span",{className:"text-xs",children:"Total"}),(0,r.jsxs)("span",{className:"text-xs",children:["Rp ",a.toLocaleString()]})]}),(0,r.jsxs)("div",{className:"flex justify-between mb-1",children:[(0,r.jsx)("span",{className:"text-xs",children:"Dibayar"}),(0,r.jsxs)("span",{className:"text-xs",children:["Rp ",E.toLocaleString()]})]}),(0,r.jsx)(c.w,{className:"my-1"}),(0,r.jsxs)("div",{className:"flex justify-between font-medium text-xs",children:[(0,r.jsx)("span",{children:z<0?"Kekurangan":"Kembalian"}),(0,r.jsxs)("span",{className:z<0?"text-red-500":"text-green-600",children:["Rp ",z.toLocaleString()]})]})]})]}),"transfer"===p&&(0,r.jsxs)("div",{className:"mb-3 space-y-1 text-xs text-muted-foreground border rounded-md p-3",children:[(0,r.jsxs)("div",{children:[(0,r.jsx)("span",{className:"font-semibold",children:"Nama Pemilik:"})," ",L?.outlet.atas_nama_bank]}),(0,r.jsxs)("div",{children:[(0,r.jsx)("span",{className:"font-semibold",children:"Bank:"})," ",L?.outlet.nama_bank]}),(0,r.jsxs)("div",{children:[(0,r.jsx)("span",{className:"font-semibold",children:"Nomor Rekening:"})," ",L?.outlet.nomor_transaksi_bank]})]}),"qris"===p&&(0,r.jsxs)("div",{className:"space-y-2 mb-3",children:[(0,r.jsx)("div",{className:"flex justify-center p-3 bg-muted rounded-md",children:(0,r.jsx)("div",{className:"w-48 h-48 bg-white p-1 rounded-md flex items-center justify-center",children:(0,r.jsx)(ex.default,{src:L?.outlet.qris_url??"/placeholder-logo.png",alt:"QRIS Code",width:700,height:700,className:"w-full h-full object-contain"})})}),(0,r.jsx)("div",{className:"text-center text-xs text-muted-foreground",children:"Scan kode QR di atas menggunakan aplikasi e-wallet atau mobile banking Anda"})]}),(0,r.jsx)("div",{className:"space-y-2",children:(0,r.jsxs)("div",{className:"grid gap-1",children:[(0,r.jsx)(w.J,{className:"text-xs font-medium",children:"Member"}),(0,r.jsx)(ej,{onMemberSelect:S})]})}),(0,r.jsx)("div",{className:"h-2"})]}),(0,r.jsxs)(N.Es,{className:"flex flex-col sm:flex-row gap-2 sm:gap-0 mt-3 px-3 py-3 border-t",children:[(0,r.jsx)(d.$,{variant:"outline",onClick:D,className:"border-orange-200 text-xs",disabled:v,children:"Batal"}),(0,r.jsx)(d.$,{type:"submit",onClick:()=>{if(!L)return;let e=n.reduce((e,t)=>e+t.price*t.quantity,0),t=n.map(e=>({product_id:e.id,quantity:e.quantity,price:e.price,discount:e.discount})),a=Math.min(e,t.reduce((e,t)=>e+t.discount,0)+(x||0)),r=Math.max(0,e-a+m);console.log("Data yang dikirim:",{items:t,discount:a,tax:m,total:r}),P({outlet_id:L.outlet_id,shift_id:L.last_shift.id,payment_method:"tunai"===p?"cash":"transfer"===p?"transfer":"qris",total_paid:Number(f),tax:m,discount:a,member_id:C?.id,items:t},{onSuccess:e=>{T(["products-outlet",`${L.outlet_id}`]),T(["orders-history",`${L.outlet_id}`]),T(["cash-register",`${L.outlet_id}`]),T(["revenue",`${L.outlet_id}`]),s(),e&&$(e.data),k(!0),l(),b(!1)},onError:()=>{b(!1)}})},className:"bg-orange-500 hover:bg-orange-600 text-xs",disabled:v||"tunai"===p&&!B,children:M?(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(eo.A,{className:"mr-1 h-3 w-3 animate-spin"}),"Memproses..."]}):"Bayar"})]})]})]})})}var ew=a(52801),ek=a(28297),eC=a(76662);let eS=(0,h.A)("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]),eR=({transactions:e,outlet:t})=>{let a=new Date().toLocaleDateString("id-ID",{day:"2-digit",month:"long",year:"numeric"}),s=e=>new Intl.NumberFormat("id-ID",{minimumFractionDigits:2,maximumFractionDigits:2}).format(parseFloat(e)),r=document.createElement("iframe");r.style.position="absolute",r.style.top="-1000px",r.style.left="-1000px",document.body.appendChild(r);let i=`
    <!DOCTYPE html>
    <html>
    <head>
    <title>Kifa Bakery</title>
      <style>
        body { 
          font-family: Arial, sans-serif; 
          padding: 20px;
          color: #333;
        }
        .header { 
          text-align: center;
          margin-bottom: 30px;
          padding-bottom: 20px;
          border-bottom: 2px solid #eee;
        }
        .title { 
          font-size: 24px; 
          font-weight: bold; 
          margin-bottom: 10px; 
        }
        .subtitle { 
          font-size: 14px; 
          margin-bottom: 5px; 
          color: #666;
        }
        .date {
          font-size: 12px;
          color: #666;
        }
        .order-card {
          margin-bottom: 30px;
          padding: 15px;
          border: 1px solid #ddd;
        }
        .order-header {
          margin-bottom: 10px;
        }
        .order-header span {
          display: inline-block;
          min-width: 150px;
          font-weight: bold;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 10px;
        }
        th, td {
          padding: 8px;
          text-align: left;
          border-bottom: 1px solid #ddd;
          font-size: 14px;
        }
        th { 
          background-color: #f5f5f5; 
        }
        .footer {
          margin-top: 40px;
          padding-top: 20px;
          border-top: 1px solid #eee;
          font-size: 12px;
          color: #666;
          text-align: right;
        }
        @media print {
          body { -webkit-print-color-adjust: exact; }
        }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="title">Laporan Penjualan Kifa Bakery</div>
        <div class="subtitle">Outlet: ${t.name}</div>
        <div class="subtitle">Alamat: ${t.address}</div>
        <div class="subtitle">Telp: ${t.phone}</div>
        <div class="date">Dicetak pada: ${a}</div>
        <div class="subtitle">Periode: ${e.date_from} - ${e.date_to}</div>
      </div>

      ${e.orders.map(e=>`
        <div class="order-card">
          <div class="order-header">
            <div><span>No. Invoice:</span> ${e.order_number}</div>
            <div><span>Tanggal:</span> ${e.created_at}</div>
            <div><span>Kasir:</span> ${e.user}</div>
            <div><span>Pajak:</span> Rp ${s(e.tax)}</div>
            <div><span>Diskon:</span> Rp ${s(e.discount)}</div>
            <div><span>Total:</span> Rp ${s(e.total)}</div>
            <div><span>Status:</span> ${"completed"===e.status?"Selesai":"cancelled"===e.status?"Dibatalkan":"Pending"}</div>
          </div>
          <div>
            <table>
              <thead>
                <tr>
                  <th>Produk</th>
                  <th>Kuantitas</th>
                  <th>Harga</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                ${e.items.map(e=>`
                  <tr>
                    <td>${e.product}</td>
                    <td>${e.quantity}</td>
                    <td>Rp ${s(e.price)}</td>
                    <td>Rp ${s(e.total)}</td>
                  </tr>
                  `).join("")}
                  <tr>
                    <td style="border-bottom: 0"></td>
                    <td style="border-bottom: 0"></td>
                    <td style="border-bottom: 0">Subtotal: </td>
                    <td style="border-bottom: 0">Rp ${s(e.subtotal)}</td>
                  </tr>
              </tbody>
            </table>
          </div>
        </div>
      `).join("")}

      <div class="footer">
        Total Orders: ${e.total_orders} <br/>
        Total Revenue: Rp ${s(e.total_revenue)} <br/>
        <p>Laporan ini dibuat secara otomatis oleh sistem.</p>
        <p>\xa9 ${new Date().getFullYear()} Kifa Bakery</p>
      </div>
    </body>
    </html>
  `,n=r.contentWindow.document;n.open(),n.write(i),n.close(),r.onload=function(){setTimeout(()=>{try{r.contentWindow.focus(),r.contentWindow.print()}catch(e){console.error("Gagal mencetak:",e)}finally{setTimeout(()=>{document.body.removeChild(r)},1e3)}},500)}};var e$=a(41559),eA=a(45502);function e_({open:e,onOpenChange:t,refetchBalance:a}){let[s,l]=(0,i.useState)(new Date),[c,u]=(0,i.useState)({from:new Date(new Date().setDate(1)),to:new Date}),[x,p]=(0,i.useState)(""),{user:h}=(0,em.A)(),{data:f}=(0,ey.r)(h?.outlet_id??0),{data:v}=(0,ec.Ib)(h?.outlet_id,(0,ew.GP)(c?.from??new Date,"yyyy-MM-dd"),(0,ew.GP)(c?.to??new Date,"yyyy-MM-dd"))(),b=v?.data.orders.filter(e=>{let t=x.toLowerCase();return e.order_number.toLowerCase().includes(t)||e.user.name.toLowerCase().includes(t)})||[],j=(e,t)=>{let a=window.open("","_blank","width=400,height=600");if(a){let s=`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Struk Transaksi #${e.order_number}</title>
          <style>
            body {
              font-family: 'Courier New', monospace;
              margin: 0;
              padding: 20px;
              max-width: 300px;
            }
           .header {
              display: flex;
              align-items: center;
              gap: 15px;
              margin-bottom: 20px;
            }
            
            .header-text {
              flex: 1;
              text-align: right;
            }
            
            .logo-container {
              display: flex;
              align-items: center;
            }
            
            .logo {
              max-width: 50px;
              height: auto;
            }
            
            .title {
              font-size: 16px;
              font-weight: bold;
              margin-bottom: 4px;
            }
            .info {
              font-size: 12px;
              margin: 5px 0;
            }
            .divider {
              border-top: 1px dashed #000;
              margin: 10px 0;
            }
            .item {
              display: flex;
              justify-content: space-between;
              font-size: 12px;
              margin: 5px 0;
            }
            .total {
              font-weight: bold;
              margin-top: 10px;
              text-align: right;
            }
            .footer {
              text-align: center;
              margin-top: 20px;
              font-size: 12px;
            }
            .logo {
              max-width: 40px; 
              height: auto; 
              margin-bottom: 10px;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="logo-container">
              <img src="${f?.data?.logo_url}" 
                  alt="Logo Outlet" 
                  class="logo"/>
            </div>
            <div class="header-text">
             <div class="title">${f?.data?.company_name}</div>
              <div class="info">${f?.data?.company_slogan}</div>
              <div class="info">${t.name}</div>
              <div class="info">Alamat: ${t.address}</div>
              <div class="info">Telp: ${t.phone}</div>
            </div>
          </div>

            <div class="divider"></div>
            <div class="info">No. Invoice: ${e.order_number}</div>
            <div class="info">Tanggal: ${e.created_at}</div>
            <div class="info">Kasir: ${e.user}</div>
          </div>
          <div class="divider"></div>
          <div>
            ${e.items.map(e=>`
              <div class="item">
                <div>${e.quantity}x ${e.product}</div>
                <div>
                  Rp ${Number(Number(e.price)*e.quantity).toLocaleString()}
                  ${Number(e.discount)>0?` (-${Number(e.discount).toLocaleString()})`:""}
                </div>
              </div>
              `).join("")}
              <div class="divider"></div>
              ${parseInt(e.tax)>0?`
                      <div class="item">
                        <div>PPN:</div>
                        <div>Rp ${Number(e.tax).toLocaleString()}</div>
                      </div>
                      `:""}
              <div class="item">
                <div>Subtotal: </div>
                <div>Rp ${Number(e.subtotal).toLocaleString()}</div>
              </div>
              <div class="item">
                <div>Total Diskon:</div>
                <div>Rp -${Number(e.discount).toLocaleString()}</div>
              </div>
          </div>
          <div class="divider"></div>
          <div class="total">Total: Rp ${Number(e.total).toLocaleString()}</div>
          <div class="item">
            <div>Metode Pembayaran:</div>
            <div>${"cash"===e.payment_method?"TUNAI":"qris"===e.payment_method?"QRIS":"TRANSFER"}</div>
          </div>
           ${"cash"===e.payment_method?`
          <div class="item">
            <div>Bayar:</div>
            <div>Rp ${Number(e.total_paid).toLocaleString()}</div>
          </div>
          <div class="item">
            <div>Kembalian:</div>
            <div>Rp ${Number(e.change).toLocaleString()}</div>
          </div>
        `:""}
          <div class="divider"></div>
          ${e.member?`
            <div class="info">
                Member: ${e.member.name} (${e.member.member_code})
            </div>
        `:""}
          <div class="footer">
            ${f?.data?.footer_message}
          </div>
        </body>
        </html>
      `;a.document.open(),a.document.write(s),a.document.close(),a.onload=function(){a.print()}}else console.error("Failed to open print window"),alert("Tidak dapat membuka jendela cetak. Periksa pengaturan popup browser Anda.")};return(0,r.jsx)(N.lG,{open:e,onOpenChange:t,children:(0,r.jsxs)(N.Cf,{className:"sm:max-w-[1200px]",children:[(0,r.jsxs)(N.c7,{children:[(0,r.jsx)(N.L3,{children:"Riwayat Transaksi"}),(0,r.jsx)(N.rr,{children:"Lihat riwayat transaksi berdasarkan tanggal"})]}),(0,r.jsxs)("div",{className:"flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4",children:[(0,r.jsxs)("div",{className:"flex flex-1 gap-2 items-center",children:[(0,r.jsx)(eA.U,{value:c,onChange:e=>{u({from:e?.from??c.from,to:e?.to??c.to})}}),h?.id&&v?.data.total_orders?(0,r.jsxs)(d.$,{onClick:()=>eR({outlet:h?.outlet,transactions:v?.data}),children:[(0,r.jsx)(eC.A,{})," Cetak"]}):null]}),(0,r.jsxs)("div",{className:"relative w-full sm:w-auto",children:[(0,r.jsx)(g.A,{className:"absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground"}),(0,r.jsx)(o.p,{type:"search",placeholder:"Cari transaksi berdasarkan invoice...",className:"pl-8 border-orange-200 w-full sm:w-[400px]",value:x,onChange:e=>p(e.target.value)})]})]}),(0,r.jsx)("div",{className:"rounded-md bg-orange-50 p-3 mb-4",children:(0,r.jsxs)("div",{className:"flex justify-between items-center",children:[(0,r.jsxs)("div",{children:[(0,r.jsxs)("p",{className:"font-medium",children:["Total Transaksi ",(0,ew.GP)(c.from,"d MMMM yyyy",{locale:ek.id})," - ",(0,ew.GP)(c.to,"d MMMM yyyy ",{locale:ek.id})]}),(0,r.jsxs)("p",{className:"text-sm text-muted-foreground",children:[v?.data.total_orders," transaksi"]})]}),(0,r.jsxs)("div",{className:"text-xl font-bold text-orange-600",children:["Rp ",Number(v?.data.total_revenue).toLocaleString()]})]})}),(0,r.jsx)("div",{className:"border rounded-md max-h-[300px] overflow-auto",children:(0,r.jsxs)(m.XI,{children:[(0,r.jsx)(m.A0,{children:(0,r.jsxs)(m.Hj,{children:[(0,r.jsx)(m.nd,{className:"text-sm font-semibold text-gray-700",children:"No"}),(0,r.jsx)(m.nd,{className:"text-sm font-semibold text-gray-700",children:"Invoice"}),(0,r.jsx)(m.nd,{className:"text-sm font-semibold text-gray-700",children:"Waktu"}),(0,r.jsx)(m.nd,{className:"text-sm font-semibold text-gray-700",children:"Kasir"}),(0,r.jsx)(m.nd,{className:"text-sm font-semibold text-gray-700",children:"Pembayaran"}),(0,r.jsx)(m.nd,{className:"text-sm font-semibold text-gray-700",children:"Status"}),(0,r.jsx)(m.nd,{className:"text-sm font-semibold text-gray-700 text-right",children:"Total"}),(0,r.jsx)(m.nd,{className:"text-right"})]})}),(0,r.jsx)(m.BF,{children:0===b.length?(0,r.jsx)(m.Hj,{children:(0,r.jsx)(m.nA,{colSpan:7,className:"h-24 text-center text-sm text-gray-500",children:x?"Tidak ada transaksi yang cocok.":"Tidak ada transaksi pada tanggal ini."})}):b.map((e,t)=>(0,r.jsxs)(m.Hj,{className:"hover:bg-gray-50 transition-colors",children:[(0,r.jsx)(m.nA,{className:"text-sm text-gray-800 font-medium",children:t+1}),(0,r.jsx)(m.nA,{className:"text-sm text-gray-800 font-medium",children:e.order_number}),(0,r.jsx)(m.nA,{className:"text-sm text-gray-600",children:e.created_at}),(0,r.jsx)(m.nA,{className:"text-sm text-gray-600",children:e.user}),(0,r.jsx)(m.nA,{children:(0,r.jsx)(n.E,{variant:"outline",className:`text-xs px-2 py-1 rounded-full ${"cash"===e.payment_method?"bg-green-100 text-green-800 border-green-200":"qris"===e.payment_method?"bg-orange-100 text-orange-800 border-orange-200":"bg-purple-100 text-purple-800 border-purple-200"}`,children:"cash"===e.payment_method?"Tunai":"qris"===e.payment_method?"QRIS":"TRANSFER"})}),(0,r.jsx)(m.nA,{className:"text-sm",children:"completed"===e.status?(0,r.jsx)("span",{className:"text-green-600 font-medium",children:"Selesai"}):(0,r.jsx)("span",{className:"text-red-500 font-medium",children:"Dibatalkan"})}),(0,r.jsxs)(m.nA,{className:"text-right text-sm font-semibold text-gray-800",children:["Rp ",Number(e.total).toLocaleString()]}),(0,r.jsx)(m.nA,{className:"text-right",children:(0,r.jsxs)("div",{className:"flex justify-end gap-2",children:[(0,r.jsx)(e$.A,{trx:e}),(0,r.jsx)(d.$,{variant:"ghost",size:"sm",className:"h-8 w-8 p-0",onClick:()=>{h?.outlet&&j(e,h.outlet)},title:"Cetak struk",children:(0,r.jsx)(eS,{className:"h-4 w-4 text-orange-500"})})]})})]},e.id))})]})}),(0,r.jsx)("div",{className:"mt-4 flex justify-end",children:(0,r.jsx)(d.$,{variant:"outline",className:"border-orange-200",onClick:()=>t(!1),children:"Tutup"})})]})})}function eL({products:e,searchQuery:t,activeCategory:a,addToCart:s}){let i=e.filter(e=>{let s=e.name.toLowerCase().includes(t.toLowerCase()),r="Semua"===a||e.category.name===a;return s&&r});return(0,r.jsxs)("div",{className:"space-y-3",children:[i.map(e=>(0,r.jsx)(l.Zp,{onClick:()=>s(e),className:`flex flex-row items-center justify-between overflow-hidden transition-all border-orange-200 hover:border-orange-400 hover:shadow-md p-2 ${0===e.quantity?"opacity-60":""}`,children:(0,r.jsx)(l.Wu,{className:"p-0 flex-1",children:(0,r.jsxs)("div",{className:"flex flex-row items-center justify-between w-full",children:[(0,r.jsxs)("div",{className:"flex flex-col space-y-0.5",children:[(0,r.jsxs)("h3",{className:"text-sm font-medium line-clamp-1",children:[e.name," (",e.quantity,")"]}),(0,r.jsxs)("p",{className:"text-xs text-orange-600 font-semibold",children:["Rp ",e.price.toLocaleString()]}),e.quantity<=e.min_stock&&e.quantity>0&&(0,r.jsx)("span",{className:"bg-yellow-100 text-yellow-800 text-xs px-1 py-0.5 rounded",children:"Produk menipis"})]}),(0,r.jsxs)("div",{className:"flex flex-col items-end space-y-1",children:[(0,r.jsxs)("div",{className:"flex items-center space-x-1",children:[(0,r.jsx)(v.A,{className:"h-3.5 w-3.5"}),(0,r.jsx)("span",{className:"text-xs",children:e.category.name})]}),(0,r.jsx)(d.$,{onClick:t=>{t.stopPropagation(),s(e)},disabled:0===e.quantity,className:"bg-orange-500 hover:bg-orange-600 text-xs h-6 px-2 rounded-md",children:0===e.quantity?"Tidak Tersedia":"Tambah"})]})]})})},e.id)),0===i.length&&(0,r.jsxs)("div",{className:"flex flex-col items-center justify-center h-60 border border-dashed rounded-lg border-orange-200",children:[(0,r.jsx)("div",{className:"text-orange-500 mb-2",children:(0,r.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"48",height:"48",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,r.jsx)("circle",{cx:"11",cy:"11",r:"8"}),(0,r.jsx)("path",{d:"m21 21-4.3-4.3"})]})}),(0,r.jsx)("p",{className:"text-muted-foreground text-center mx-2",children:"Tidak ada produk yang ditemukan. Coba cari dengan kata kunci lain."})]})]})}var eP=a(81624);let eM=(0,h.A)("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);var eq=a(65614);function eT({outletId:e,cashBalance:t}){let[a,s]=(0,i.useState)(!1),[n,l]=(0,i.useState)("add"),[m,u]=(0,i.useState)(""),[x,p]=(0,i.useState)(""),{mutate:h,isPending:f}=(0,eq.ff)(),{mutate:g,isPending:v}=(0,eq.K$)(),{invalidate:b}=(0,eu.j)();return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)(ef.AM,{children:[(0,r.jsx)(ef.Wv,{asChild:!0,children:(0,r.jsxs)(d.$,{variant:"outline",className:"border-orange-200 bg-orange-50 hover:bg-orange-100",children:[(0,r.jsx)(ed.A,{className:"mr-2 h-4 w-4 text-orange-500"}),"Kas kasir",(0,r.jsx)(eg.A,{className:"ml-2 h-4 w-4 text-orange-500 opacity-50"})]})}),(0,r.jsx)(ef.hl,{className:"w-80",children:(0,r.jsxs)("div",{className:"space-y-4",children:[(0,r.jsxs)("div",{className:"flex flex-col space-y-1",children:[(0,r.jsx)("h4",{className:"font-medium text-sm",children:"Kas Kasir"}),(0,r.jsxs)("p",{className:"text-2xl font-bold text-orange-600",children:["Rp ",Number(t).toLocaleString()]})]}),(0,r.jsx)(c.w,{}),(0,r.jsxs)("div",{className:"flex justify-between",children:[(0,r.jsxs)(d.$,{variant:"outline",className:"border-orange-200 w-[48%]",onClick:()=>{l("add"),s(!0)},children:[(0,r.jsx)(eP.A,{className:"mr-2 h-4 w-4 text-green-500"}),"Tambah Kas"]}),(0,r.jsxs)(d.$,{variant:"outline",className:"border-orange-200 w-[48%]",onClick:()=>{l("remove"),s(!0)},children:[(0,r.jsx)(eM,{className:"mr-2 h-4 w-4 text-red-500"}),"Ambil Kas"]})]})]})})]}),(0,r.jsx)(N.lG,{open:a,onOpenChange:s,children:(0,r.jsxs)(N.Cf,{className:"sm:max-w-[425px]",children:[(0,r.jsxs)(N.c7,{children:[(0,r.jsx)(N.L3,{children:"add"===n?"Tambah Kas":"Ambil Kas"}),(0,r.jsx)(N.rr,{children:"add"===n?"Masukkan jumlah kas yang akan ditambahkan ke mesin kasir.":"Masukkan jumlah kas yang akan diambil dari mesin kasir."})]}),(0,r.jsxs)("div",{className:"grid gap-4 py-4",children:[(0,r.jsxs)("div",{className:"grid gap-2",children:[(0,r.jsx)(w.J,{htmlFor:"amount",children:"Jumlah"}),(0,r.jsx)(o.p,{id:"amount",placeholder:"Masukkan jumlah",value:m?`Rp ${Number.parseInt(m).toLocaleString()}`:"",onChange:e=>{u(e.target.value.replace(/[^0-9]/g,""))},className:"border-orange-200",required:!0})]}),(0,r.jsxs)("div",{className:"grid gap-2",children:[(0,r.jsx)(w.J,{htmlFor:"note",children:"Catatan"}),(0,r.jsx)(o.p,{id:"note",placeholder:"Tambahkan catatan",value:x,onChange:e=>p(e.target.value),className:"border-orange-200",required:!0})]})]}),(0,r.jsxs)(N.Es,{children:[(0,r.jsx)(d.$,{variant:"outline",onClick:()=>s(!1),className:"border-orange-200",children:"Batal"}),(0,r.jsx)(d.$,{onClick:()=>{let t=Number.parseInt(m)||0;"add"===n?h({amount:t,outlet_id:e,reason:x},{onSuccess:()=>{b(["cash-register",`${e}`])}}):g({amount:t,outlet_id:e,reason:x},{onSuccess:()=>{b(["cash-register",`${e}`])}}),u(""),p(""),s(!1)},className:"bg-orange-500 hover:bg-orange-600",disabled:!m||0>=Number.parseInt(m)||!x,children:"add"===n?"Tambah Kas":"Ambil Kas"})]})]})})]})}var eD=a(94736),eE=a(76201),ez=a(39522),eB=a(61653),eF=a(34843),eI=a(35402),eG=a(113);function eO({setIsAdjustStockDialogOpen:e,products:t,refetch:a}){let{user:s}=(0,em.A)(),[n,l]=(0,i.useState)(""),c=(0,eI.of)(),m={outlet_id:s?.outlet_id??0,product_id:"",quantity_change:"",type:"",notes:""},[u,x]=(0,i.useState)(m),p=(0,i.useMemo)(()=>n?t.filter(e=>e.name.toLowerCase().includes(n.toLowerCase())):t,[t,n]),h=(e,t)=>{let a=t.replace(/[^-0-9]/g,"");return"-"===a||""===a?"":parseInt(a.startsWith("-")?"-"+a.replace(/-/g,""):a,10).toString()},f=e=>{let{name:t,value:a}=e.target;"price"===t||"quantity"===t||"min_stock"===t||"quantity_change"===t?x(e=>({...e,[t]:h(t,a)})):x(e=>({...e,[t]:a}))};return(0,r.jsxs)("form",{onSubmit:e=>{e.preventDefault(),c.mutate(u,{onSuccess:e=>{a(),"adjustment"===u.type?(0,eG.oR)({title:"Berhasil mengajukan penyesuaian stok!",description:"Perubahan membutuhkan persetujuan admin"}):(0,eG.oR)({title:"Berhasil mengatur stok!",description:"Perubahan stok telah berhasil diterapkan"}),x(m),l("")},onError:()=>{(0,eG.oR)({title:"Gagal mengatur stok!",description:"Tidak dapat mengatur stok, silahkan coba lagi",variant:"destructive"})}})},children:[(0,r.jsx)("div",{className:"grid gap-6 py-4 max-h-[70vh] overflow-y-auto",children:(0,r.jsx)("div",{className:"space-y-4 p-4 rounded-lg border bg-muted/40",children:(0,r.jsxs)("div",{className:"grid grid-cols-2 gap-4",children:[(0,r.jsxs)("div",{className:"space-y-2 col-span-2",children:[(0,r.jsx)(w.J,{children:"Nama Produk"}),(0,r.jsxs)(eB.l6,{value:`${u.product_id}`,onValueChange:e=>x(t=>({...t,product_id:e})),children:[(0,r.jsx)(eB.bq,{children:(0,r.jsx)(eB.yv,{placeholder:"Pilih produk"})}),(0,r.jsxs)(eB.gC,{children:[(0,r.jsxs)("div",{className:"relative px-2 mb-2",children:[(0,r.jsx)(g.A,{className:"absolute left-4 top-3 h-4 w-4 text-muted-foreground"}),(0,r.jsx)(o.p,{placeholder:"Cari produk...",className:"pl-10 h-9",value:n,onChange:e=>l(e.target.value)})]}),p.length>0?p.map(e=>(0,r.jsx)(eB.eb,{value:`${e.id}`,children:e.name},e.id)):(0,r.jsx)("div",{className:"py-2 text-center text-sm text-muted-foreground",children:"Produk tidak ditemukan"})]})]})]}),(0,r.jsxs)("div",{className:"space-y-2",children:[(0,r.jsx)(w.J,{children:"Nilai + / -"}),(0,r.jsx)(o.p,{type:"number",name:"quantity_change",value:u.quantity_change,onChange:f,placeholder:"Masukkan nilai penambahan/pengurangan",onKeyPress:e=>{"-"===e.key&&e.currentTarget.value.includes("-")&&e.preventDefault()}})]}),(0,r.jsxs)("div",{className:"space-y-2",children:[(0,r.jsx)(w.J,{children:"Tipe"}),(0,r.jsxs)(eB.l6,{value:u.type,onValueChange:e=>x(t=>({...t,type:e})),children:[(0,r.jsx)(eB.bq,{children:(0,r.jsx)(eB.yv,{placeholder:"Pilih tipe"})}),(0,r.jsxs)(eB.gC,{children:[(0,r.jsx)(eB.eb,{value:"purchase",children:"Pembelian"}),(0,r.jsx)(eB.eb,{value:"adjustment",children:"Penyesuaian"}),(0,r.jsx)(eB.eb,{value:"shipment",children:"Kiriman Pabrik"}),(0,r.jsx)(eB.eb,{value:"other",children:"Lainnya"})]})]})]}),(0,r.jsxs)("div",{className:"space-y-2 col-span-2",children:[(0,r.jsx)(w.J,{children:"Keterangan"}),(0,r.jsx)(eF.T,{name:"notes",value:u.notes,onChange:f,placeholder:"Masukkan keterangan (opsional)"})]})]})})}),(0,r.jsxs)(N.Es,{className:"border-t pt-4",children:[(0,r.jsx)(d.$,{type:"button",variant:"outline",onClick:()=>e(!1),children:"Batal"}),(0,r.jsxs)(d.$,{type:"submit",className:"gap-2 bg-orange-600 hover:bg-orange-700",disabled:c.isPending,children:[c.isPending?(0,r.jsx)(eo.A,{className:"animate-spin h-4 w-4"}):(0,r.jsx)(eP.A,{className:"h-4 w-4"}),"Sesuaikan Stok"]})]})]})}var eK=a(54761),eH=a(44066),eW=a(99647);function eU({inventories:e,date:t,setDate:a}){return(0,r.jsxs)("div",{className:"",children:[(0,r.jsxs)(ef.AM,{children:[(0,r.jsx)(ef.Wv,{asChild:!0,children:(0,r.jsx)("div",{className:"pt-3 pb-4",children:(0,r.jsxs)(d.$,{variant:"outline",className:(0,es.cn)("justify-start text-left font-normal border-orange-200",!t&&"text-muted-foreground"),children:[(0,r.jsx)(eH.A,{className:"mr-2 h-4 w-4"}),t?(0,ew.GP)(t,"PPP",{locale:ek.id}):(0,r.jsx)("span",{children:"Pilih tanggal"})]})})}),(0,r.jsx)(ef.hl,{className:"w-auto p-0",align:"start",children:(0,r.jsx)(eW.V,{mode:"single",selected:t,onSelect:e=>e&&a(e),initialFocus:!0})})]}),(0,r.jsx)("div",{className:"border rounded-md max-h-[300px] overflow-auto",children:(0,r.jsxs)(m.XI,{children:[(0,r.jsx)(m.A0,{children:(0,r.jsxs)(m.Hj,{children:[(0,r.jsx)(m.nd,{className:"text-sm font-semibold text-gray-700",children:"Nama Produk"}),(0,r.jsx)(m.nd,{className:"text-sm font-semibold text-gray-700",children:"Perubahan"}),(0,r.jsx)(m.nd,{className:"text-sm font-semibold text-gray-700",children:"Tipe"}),(0,r.jsx)(m.nd,{className:"text-sm font-semibold text-gray-700",children:"Keterangan"}),(0,r.jsx)(m.nd,{className:"text-sm font-semibold text-gray-700",children:"Status"})]})}),(0,r.jsx)(m.BF,{children:0===e.length?(0,r.jsx)(m.Hj,{children:(0,r.jsx)(m.nA,{colSpan:7,className:"h-24 text-center text-sm text-gray-500",children:"Tidak ada permintaan penyesuaian pada tanggal ini."})}):e.map(e=>(0,r.jsxs)(m.Hj,{className:"hover:bg-gray-50 transition-colors",children:[(0,r.jsx)(m.nA,{className:"text-sm text-gray-800 font-medium",children:e.product.name}),(0,r.jsx)(m.nA,{className:"text-sm text-gray-600",children:e.quantity_change}),(0,r.jsx)(m.nA,{className:"text-sm text-gray-600",children:"adjustment"===e.type?"Penyesuaian":"shipment"===e.type?"Kiriman Pabrik":"purchase"===e.type?"Pembelian":"Lainnya"}),(0,r.jsx)(m.nA,{className:"text-sm text-gray-600",children:e.notes}),(0,r.jsx)(m.nA,{className:"text-sm text-gray-600",children:"approved"===e.status?(0,r.jsx)(n.E,{children:"Disetujui"}):"rejected"===e.status?(0,r.jsx)(n.E,{variant:"destructive",children:"Ditolak"}):(0,r.jsx)(n.E,{variant:"secondary",children:"Pending"})})]},e.id))})]})})]})}function eJ({products:e}){let[t,a]=(0,i.useState)(!1),[s,n]=(0,i.useState)(new Date),{user:l}=(0,em.A)(),{data:o,refetch:c}=(0,eI.s5)(l?.outlet_id??0,(0,ew.GP)(s,"yyyy-MM-dd"));return(0,r.jsxs)(N.lG,{open:t,onOpenChange:a,children:[(0,r.jsx)(N.zM,{asChild:!0,children:(0,r.jsxs)(d.$,{variant:"outline",className:"border-orange-200 bg-orange-50 hover:bg-orange-100",children:[(0,r.jsx)(ez.A,{className:"h-4 w-4 text-orange-500"}),"Stok"]})}),(0,r.jsxs)(N.Cf,{className:"sm:max-w-[700px]",children:[(0,r.jsxs)(N.c7,{children:[(0,r.jsx)(N.L3,{children:"Sesuaikan Stok"}),(0,r.jsx)(N.rr,{children:"Sesuaikan stok produk. Perubahan memerlukan persetujuan admin"})]}),(0,r.jsxs)(eK.tU,{children:[(0,r.jsxs)(eK.j7,{className:"grid w-full grid-cols-2",children:[(0,r.jsx)(eK.Xi,{value:"form",children:"Sesuaikan"}),(0,r.jsx)(eK.Xi,{value:"history",children:"Riwayat"})]}),(0,r.jsx)(eK.av,{value:"form",className:"border-orange-200",children:(0,r.jsx)(eO,{products:e,setIsAdjustStockDialogOpen:a,refetch:c})}),(0,r.jsx)(eK.av,{value:"history",children:o?.data?(0,r.jsx)(eU,{inventories:o?.data,date:s,setDate:n}):(0,r.jsx)("p",{children:"Tidak ada history stok"})})]})]})]})}var eZ=a(7802),eV=(a(24971),a(31783)),eQ="HoverCard",[eX,eY]=(0,S.A)(eQ,[eZ.Bk]),e0=(0,eZ.Bk)(),[e1,e2]=eX(eQ),e4=e=>{let{__scopeHoverCard:t,children:a,open:s,defaultOpen:n,onOpenChange:d,openDelay:l=700,closeDelay:o=300}=e,c=e0(t),m=i.useRef(0),u=i.useRef(0),x=i.useRef(!1),p=i.useRef(!1),[h=!1,f]=(0,A.i)({prop:s,defaultProp:n,onChange:d}),g=i.useCallback(()=>{clearTimeout(u.current),m.current=window.setTimeout(()=>f(!0),l)},[l,f]),v=i.useCallback(()=>{clearTimeout(m.current),x.current||p.current||(u.current=window.setTimeout(()=>f(!1),o))},[o,f]),b=i.useCallback(()=>f(!1),[f]);return i.useEffect(()=>()=>{clearTimeout(m.current),clearTimeout(u.current)},[]),(0,r.jsx)(e1,{scope:t,open:h,onOpenChange:f,onOpen:g,onClose:v,onDismiss:b,hasSelectionRef:x,isPointerDownOnContentRef:p,children:(0,r.jsx)(eZ.bL,{...c,children:a})})};e4.displayName=eQ;var e5="HoverCardTrigger",e3=i.forwardRef((e,t)=>{let{__scopeHoverCard:a,...s}=e,i=e2(e5,a),n=e0(a);return(0,r.jsx)(eZ.Mz,{asChild:!0,...n,children:(0,r.jsx)(R.sG.a,{"data-state":i.open?"open":"closed",...s,ref:t,onPointerEnter:(0,k.m)(e.onPointerEnter,tt(i.onOpen)),onPointerLeave:(0,k.m)(e.onPointerLeave,tt(i.onClose)),onFocus:(0,k.m)(e.onFocus,i.onOpen),onBlur:(0,k.m)(e.onBlur,i.onClose),onTouchStart:(0,k.m)(e.onTouchStart,e=>e.preventDefault())})})});e3.displayName=e5;var[e6,e8]=eX("HoverCardPortal",{forceMount:void 0}),e7="HoverCardContent",e9=i.forwardRef((e,t)=>{let a=e8(e7,e.__scopeHoverCard),{forceMount:s=a.forceMount,...i}=e,n=e2(e7,e.__scopeHoverCard);return(0,r.jsx)(M.C,{present:s||n.open,children:(0,r.jsx)(te,{"data-state":n.open?"open":"closed",...i,onPointerEnter:(0,k.m)(e.onPointerEnter,tt(n.onOpen)),onPointerLeave:(0,k.m)(e.onPointerLeave,tt(n.onClose)),ref:t})})});e9.displayName=e7;var te=i.forwardRef((e,t)=>{let{__scopeHoverCard:a,onEscapeKeyDown:n,onPointerDownOutside:d,onFocusOutside:l,onInteractOutside:o,...c}=e,m=e2(e7,a),u=e0(a),x=i.useRef(null),p=(0,C.s)(t,x),[h,f]=i.useState(!1);return i.useEffect(()=>{if(h){let e=document.body;return s=e.style.userSelect||e.style.webkitUserSelect,e.style.userSelect="none",e.style.webkitUserSelect="none",()=>{e.style.userSelect=s,e.style.webkitUserSelect=s}}},[h]),i.useEffect(()=>{if(x.current){let e=()=>{f(!1),m.isPointerDownOnContentRef.current=!1,setTimeout(()=>{document.getSelection()?.toString()!==""&&(m.hasSelectionRef.current=!0)})};return document.addEventListener("pointerup",e),()=>{document.removeEventListener("pointerup",e),m.hasSelectionRef.current=!1,m.isPointerDownOnContentRef.current=!1}}},[m.isPointerDownOnContentRef,m.hasSelectionRef]),i.useEffect(()=>{x.current&&(function(e){let t=[],a=document.createTreeWalker(e,NodeFilter.SHOW_ELEMENT,{acceptNode:e=>e.tabIndex>=0?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP});for(;a.nextNode();)t.push(a.currentNode);return t})(x.current).forEach(e=>e.setAttribute("tabindex","-1"))}),(0,r.jsx)(eV.qW,{asChild:!0,disableOutsidePointerEvents:!1,onInteractOutside:o,onEscapeKeyDown:n,onPointerDownOutside:d,onFocusOutside:(0,k.m)(l,e=>{e.preventDefault()}),onDismiss:m.onDismiss,children:(0,r.jsx)(eZ.UC,{...u,...c,onPointerDown:(0,k.m)(c.onPointerDown,e=>{e.currentTarget.contains(e.target)&&f(!0),m.hasSelectionRef.current=!1,m.isPointerDownOnContentRef.current=!0}),ref:p,style:{...c.style,userSelect:h?"text":void 0,WebkitUserSelect:h?"text":void 0,"--radix-hover-card-content-transform-origin":"var(--radix-popper-transform-origin)","--radix-hover-card-content-available-width":"var(--radix-popper-available-width)","--radix-hover-card-content-available-height":"var(--radix-popper-available-height)","--radix-hover-card-trigger-width":"var(--radix-popper-anchor-width)","--radix-hover-card-trigger-height":"var(--radix-popper-anchor-height)"}})})});function tt(e){return t=>"touch"===t.pointerType?void 0:e()}i.forwardRef((e,t)=>{let{__scopeHoverCard:a,...s}=e,i=e0(a);return(0,r.jsx)(eZ.i3,{...i,...s,ref:t})}).displayName="HoverCardArrow";let ta=i.forwardRef(({className:e,align:t="center",sideOffset:a=4,...s},i)=>(0,r.jsx)(e9,{ref:i,align:t,sideOffset:a,className:(0,es.cn)("z-50 w-64 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",e),...s}));ta.displayName=e9.displayName;let ts=(0,h.A)("CalendarDays",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}],["path",{d:"M8 14h.01",key:"6423bh"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M16 14h.01",key:"1gbofw"}],["path",{d:"M8 18h.01",key:"lrp35t"}],["path",{d:"M12 18h.01",key:"mhygvu"}],["path",{d:"M16 18h.01",key:"kzsmim"}]]);function tr({revenue:e}){return(0,r.jsxs)(e4,{children:[(0,r.jsx)(e3,{asChild:!0,children:(0,r.jsxs)(d.$,{variant:"outline",className:"border-orange-200 bg-orange-50 hover:bg-orange-100",children:[(0,r.jsx)(ts,{className:"mr-2 h-4 w-4 text-orange-500"}),(0,r.jsxs)("span",{className:"font-medium",children:["Rp ",Number(e.total).toLocaleString()||0]})]})}),(0,r.jsx)(ta,{className:"w-80",children:(0,r.jsx)("div",{children:(0,r.jsxs)("p",{className:"text-muted-foreground text-sm mt-1",children:["Total pendapatan dari "," ",(0,r.jsx)("span",{className:"font-semibold underline-offset-4 text-black/70 underline",children:e.from})," ","sampai "," ",(0,r.jsx)("span",{className:"font-semibold underline-offset-4 text-black/70 underline",children:e.to})]})})})]})}function ti(){let[e,t]=(0,i.useState)([]),[a,s]=(0,i.useState)(""),[h,N]=(0,i.useState)("Semua"),[w,k]=(0,i.useState)(!1),[C,S]=(0,i.useState)(!1),[R,$]=(0,i.useState)([]),[A,_]=(0,i.useState)(0),[L,P]=(0,i.useState)(!1),{user:M,logout:q}=(0,em.A)(),T=Number(M?.outlet_id)||1,{data:D}=(0,ec.vc)(T),{data:E,refetch:z}=(0,eq.uw)(T)(),{data:B,isLoading:F,refetch:I}=(0,eE.cq)(T)(),{data:G}=(0,eD.QU)(),O=a=>{let s=e.find(e=>e.id===a);s&&($(e=>e.map(e=>e.id===a?{...e,quantity:e.quantity+s.quantity}:e)),t(e.filter(e=>e.id!==a)))},K=(a,s)=>{if(s<1)return;let r=e.find(e=>e.id===a);if(!r)return;let i=s-r.quantity,n=R.find(e=>e.id===a);n&&n.quantity-i<0||(t(e.map(e=>{if(e.id===a){let t=e.price*s,a=Math.min(e.discount,t);return{...e,quantity:s,discount:a}}return e})),n&&$(e=>e.map(e=>e.id===a?{...e,quantity:e.quantity-i}:e)))},H=(a,s)=>{let r=e.find(e=>e.id===a);if(!r)return;let i=Math.min(r.price*r.quantity,Math.max(0,s));t(e.map(e=>e.id===a?{...e,discount:i}:e))};e.reduce((e,t)=>e+t.discount,0);let W=e.reduce((e,t)=>e+(t.price*t.quantity-t.discount),0),U=(M?.outlet.tax??0)/100,J=W?W*U:0,Z=W+J-A;return(0,r.jsxs)("div",{className:"flex flex-col min-h-screen",children:[(0,r.jsx)("header",{className:"sticky top-0 z-10 border-b bg-white px-4 py-3 shadow-sm dark:bg-gray-950",children:(0,r.jsxs)("div",{className:"flex items-center justify-between",children:[(0,r.jsxs)("div",{className:"flex items-center",children:[(0,r.jsx)(ex.default,{src:"https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEg0JeOFanmAshWgLBlxIH5qHVyx7okwwmeV9Wbqr9n8Aie9Gh-BqnAF0_PlfBa_ZHqnENEOz8MuPZxFYFfgvCAYF8ie3AMRW_syA0dluwZJW-jg7ZuS8aaRJ38NI2f7UFW1ePVO4kifJTbdZi0WvQFr77GyqssJzeWL2K65GPB4dZwHEkZnlab9qNKX9VSZ/s320/logo-kifa.png",alt:"Logo kifa",width:50,height:50,className:"w-7 mr-4"}),(0,r.jsx)("h1",{className:"text-xl font-bold text-orange-500",children:M?.outlet?.name})]}),(0,r.jsxs)("div",{className:"hidden md:flex items-center space-x-4",children:[(0,r.jsx)(eJ,{products:R}),D?.data&&(0,r.jsx)(tr,{revenue:D?.data}),(0,r.jsx)(eT,{outletId:T,cashBalance:Number(E?.data.balance)||0}),(0,r.jsxs)("div",{className:"flex items-center",children:[(0,r.jsx)(x.A,{className:"h-5 w-5 text-orange-500 mr-2"}),(0,r.jsxs)("span",{className:"font-medium",children:[M?.name," (",M?.role,")"]})]}),(0,r.jsx)(d.$,{variant:"outline",size:"icon",className:"border-orange-200 hover:bg-orange-100 hover:text-orange-700",onClick:q,children:(0,r.jsx)(p.A,{className:"h-4 w-4 mr-2"})})]}),(0,r.jsxs)("div",{className:"flex md:hidden items-center space-x-3",children:[(0,r.jsxs)("div",{className:"flex items-center",children:[(0,r.jsx)(x.A,{className:"h-5 w-5 text-orange-500 mr-1"}),(0,r.jsx)("span",{className:"font-medium text-sm",children:M?.name})]}),(0,r.jsxs)(ef.AM,{children:[(0,r.jsx)(ef.Wv,{asChild:!0,children:(0,r.jsx)(d.$,{variant:"outline",size:"icon",className:"border-orange-200",children:(0,r.jsx)(f,{className:"h-5 w-5"})})}),(0,r.jsx)(ef.hl,{className:"w-60 p-2",align:"end",children:(0,r.jsxs)("div",{className:"space-y-2",children:[(0,r.jsx)("div",{className:"p-2 rounded-md bg-orange-50",children:(0,r.jsxs)("div",{className:"flex items-center mb-1",children:[(0,r.jsx)(x.A,{className:"h-4 w-4 text-orange-500 mr-2"}),(0,r.jsxs)("span",{className:"font-medium",children:[M?.name," (",M?.role,")"]})]})}),(0,r.jsx)("div",{className:"p-2",children:(0,r.jsx)(eT,{outletId:T,cashBalance:Number(E?.data.balance)||0})}),(0,r.jsx)(c.w,{}),(0,r.jsxs)(d.$,{variant:"outline",size:"sm",className:"w-full border-orange-200 hover:bg-orange-100 hover:text-orange-700",onClick:q,children:[(0,r.jsx)(p.A,{className:"h-4 w-4 mr-2"}),"Logout"]})]})})]})]})]})}),(0,r.jsxs)("div",{className:"flex flex-1 flex-col md:flex-row overflow-hidden",children:[(0,r.jsxs)("div",{className:"w-full md:w-3/5 p-4 flex flex-col h-[calc(100vh-64px)]",children:[(0,r.jsxs)("div",{className:"flex flex-col mb-4 gap-3",children:[(0,r.jsxs)("div",{className:"relative w-full",children:[(0,r.jsx)(g.A,{className:"absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground"}),(0,r.jsx)(o.p,{type:"search",placeholder:"Cari produk...",className:"pl-8 border-orange-200 focus-visible:ring-orange-500",value:a,onChange:e=>s(e.target.value)})]}),(0,r.jsxs)("div",{className:"flex overflow-x-auto gap-2",children:[(0,r.jsx)(n.E,{variant:"outline",className:"hover:bg-orange-100 cursor-pointer border-orange-200",onClick:()=>N("Semua"),children:"Semua"}),G?.data.map(e=>r.jsx(n.E,{variant:h===e.name?"default":"outline",className:h===e.name?"bg-orange-500 hover:bg-orange-600 cursor-pointer":"hover:bg-orange-100 cursor-pointer border-orange-200",onClick:()=>N(e.name),children:e.name},e.id))]})]}),(0,r.jsx)(u.F,{className:"flex-1 rounded-md border border-orange-100",children:(0,r.jsx)("div",{className:"p-4",children:B?.data?(0,r.jsx)(eL,{products:R,searchQuery:a,activeCategory:h,addToCart:a=>{let s=R.find(e=>e.id===a.id);s&&!(s.quantity<1)&&(e.find(e=>e.id===a.id)?t(e.map(e=>e.id===a.id?{...e,quantity:e.quantity+1}:e)):t([...e,{id:a.id,name:a.name,price:a.price,quantity:1,discount:0}]),$(e=>e.map(e=>e.id===a.id?{...e,quantity:e.quantity-1}:e)))},tax:J}):(0,r.jsx)(tn,{})})})]}),(0,r.jsx)("div",{className:"w-full md:w-2/5 border-t md:border-t-0 md:border-l border-orange-200 flex flex-col h-[calc(100vh-64px)]",children:(0,r.jsxs)(l.Zp,{className:"h-full flex flex-col rounded-none border-x-0 border-b-0",children:[(0,r.jsx)(l.aR,{className:"border-b border-orange-200",children:(0,r.jsx)(l.ZB,{className:"flex items-center justify-between",children:(0,r.jsxs)("div",{className:"flex items-center",children:[(0,r.jsx)(v.A,{className:"mr-2 h-5 w-5 text-orange-500"}),"Keranjang"]})})}),(0,r.jsx)(l.Wu,{className:"flex-grow overflow-auto p-4",children:0===e.length?(0,r.jsxs)("div",{className:"flex h-40 flex-col items-center justify-center rounded-md border border-dashed p-4 text-center border-orange-200",children:[(0,r.jsx)(v.A,{className:"h-10 w-10 text-orange-300"}),(0,r.jsx)("p",{className:"mt-2 text-sm text-muted-foreground",children:"Keranjang kosong. Tambahkan produk untuk memulai transaksi."})]}):(0,r.jsxs)(m.XI,{children:[(0,r.jsx)(m.A0,{children:(0,r.jsxs)(m.Hj,{children:[(0,r.jsx)(m.nd,{children:"Produk"}),(0,r.jsx)(m.nd,{className:"text-center",children:"Qty"}),(0,r.jsx)(m.nd,{className:"text-center",children:"Diskon"}),(0,r.jsx)(m.nd,{className:"text-right",children:"Subtotal"}),(0,r.jsx)(m.nd,{})]})}),(0,r.jsx)(m.BF,{children:e.map(e=>(e.price,e.quantity,e.discount,(0,r.jsxs)(m.Hj,{children:[(0,r.jsx)(m.nA,{className:"font-medium",children:(0,r.jsxs)("div",{children:[e.name,(0,r.jsxs)("div",{className:"text-xs text-muted-foreground",children:["Rp ",e.price.toLocaleString()]})]})}),(0,r.jsx)(m.nA,{className:"text-center",children:(0,r.jsxs)("div",{className:"flex items-center justify-center gap-2",children:[(0,r.jsx)(d.$,{variant:"outline",size:"icon",className:"h-8 w-8 border-orange-200 hover:bg-orange-50",onClick:()=>K(e.id,e.quantity-1),children:"-"}),(0,r.jsx)(o.p,{type:"number",min:"1",value:e.quantity,onChange:t=>{let a=Math.max(1,parseInt(t.target.value)||1);K(e.id,a)},className:"h-8 w-16 text-center font-medium border-orange-200 hover:border-orange-300 focus-visible:ring-orange-500"}),(0,r.jsx)(d.$,{variant:"outline",size:"icon",className:"h-8 w-8 border-orange-200 hover:bg-orange-50",onClick:()=>K(e.id,e.quantity+1),children:"+"})]})}),(0,r.jsxs)(m.nA,{className:"text-center",children:[(0,r.jsx)(o.p,{type:"number",min:"0",max:e.price*e.quantity,step:"0.6",className:"h-8 w-20 text-center font-medium border-orange-200 hover:border-orange-300 focus-visible:ring-orange-500",placeholder:"Diskon",value:e.discount,onChange:t=>{let a=Number(t.target.value);H(e.id,a)}}),e.discount>0&&(0,r.jsx)("div",{className:"text-xs text-orange-500 flex items-center mt-1",children:(0,r.jsxs)("span",{children:["Rp ",e.discount.toLocaleString()]})})]}),(0,r.jsxs)(m.nA,{className:"text-right",children:["Rp ",(e.price*e.quantity-e.discount).toLocaleString()]}),(0,r.jsx)(m.nA,{className:"text-center",children:(0,r.jsx)(d.$,{variant:"ghost",size:"icon",onClick:()=>O(e.id),children:(0,r.jsx)(b.A,{className:"h-4 w-4 text-red-500"})})})]},e.id)))})]})}),(0,r.jsx)("div",{className:"border-t border-orange-200 p-4",children:(0,r.jsxs)("div",{className:"space-y-1.5",children:[e.some(e=>e.discount>0)&&(0,r.jsxs)("div",{className:"flex justify-between text-orange-500",children:[(0,r.jsx)("span",{children:"Diskon Item (Rp)"}),(0,r.jsxs)("span",{children:["- Rp ",e.reduce((e,t)=>e+t.discount,0).toLocaleString()]})]}),(0,r.jsxs)("div",{className:"flex justify-between",children:[(0,r.jsx)("span",{className:"text-muted-foreground",children:"Subtotal"}),(0,r.jsxs)("span",{children:["Rp ",W.toLocaleString()]})]}),(0,r.jsxs)("div",{className:"flex justify-between",children:[(0,r.jsxs)("span",{className:"text-muted-foreground",children:["Pajak (",parseFloat(M?.outlet?.tax),"%)"]}),(0,r.jsxs)("span",{children:["Rp ",J.toLocaleString()]})]}),(0,r.jsx)(c.w,{className:"my-2"}),(0,r.jsxs)("div",{className:"flex justify-between font-bold text-lg",children:[(0,r.jsx)("span",{children:"Total"}),(0,r.jsxs)("span",{className:"text-orange-600",children:["Rp ",Z.toLocaleString()]})]})]})}),(0,r.jsxs)("div",{className:"mt-auto border-t border-orange-200 p-4",children:[(0,r.jsx)("div",{className:"grid grid-cols-1 gap-2 mb-2",children:(0,r.jsxs)(d.$,{className:"bg-orange-500 hover:bg-orange-600",disabled:0===e.length,onClick:()=>k(!0),children:[(0,r.jsx)(j.A,{className:"mr-2 h-4 w-4"}),"Pembayaran"]})}),(0,r.jsxs)(d.$,{variant:"outline",className:"w-full border-orange-200",onClick:()=>S(!0),children:[(0,r.jsx)(y.A,{className:"mr-2 h-4 w-4"}),"Riwayat Transaksi"]})]})]})})]}),(0,r.jsx)(eN,{open:w,onOpenChange:k,total:Z,tax:J,cart:e,refetchBalance:z,onSuccess:()=>{t([]),_(0)}}),(0,r.jsx)(e_,{open:C,onOpenChange:S,refetchBalance:z})]})}function tn(){return(0,r.jsxs)("div",{className:"col-span-full flex flex-col items-center justify-center h-60 border border-dashed rounded-lg border-orange-200",children:[(0,r.jsx)("div",{className:"text-orange-500 mb-2",children:(0,r.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",width:"48",height:"48",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[(0,r.jsx)("circle",{cx:"11",cy:"11",r:"8"}),(0,r.jsx)("path",{d:"m21 21-4.3-4.3"})]})}),(0,r.jsx)("p",{className:"text-muted-foreground text-center mx-2",children:"Produk kosong."})]})}},80429:(e,t,a)=>{"use strict";a.d(t,{$:()=>o,r:()=>l});var s=a(18652),r=a(9861),i=a(76648),n=a(13801),d=a(28070);let l=(0,n.F)("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",{variants:{variant:{default:"bg-primary text-primary-foreground hover:bg-primary/90",destructive:"bg-destructive text-destructive-foreground hover:bg-destructive/90",outline:"border border-input bg-background hover:bg-accent hover:text-accent-foreground",secondary:"bg-secondary text-secondary-foreground hover:bg-secondary/80",ghost:"hover:bg-accent hover:text-accent-foreground",link:"text-primary underline-offset-4 hover:underline"},size:{default:"h-10 px-4 py-2",sm:"h-9 rounded-md px-3",lg:"h-11 rounded-md px-8",icon:"h-10 w-10"}},defaultVariants:{variant:"default",size:"default"}}),o=r.forwardRef(({className:e,variant:t,size:a,asChild:r=!1,...n},o)=>{let c=r?i.DX:"button";return(0,s.jsx)(c,{className:(0,d.cn)(l({variant:t,size:a,className:e})),ref:o,...n})});o.displayName="Button"},28427:(e,t,a)=>{"use strict";a.d(t,{BT:()=>o,Wu:()=>c,ZB:()=>l,Zp:()=>n,aR:()=>d,wL:()=>m});var s=a(18652),r=a(9861),i=a(28070);let n=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)("div",{ref:a,className:(0,i.cn)("rounded-lg border bg-card text-card-foreground shadow-sm",e),...t}));n.displayName="Card";let d=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)("div",{ref:a,className:(0,i.cn)("flex flex-col space-y-1.5 p-6",e),...t}));d.displayName="CardHeader";let l=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)("div",{ref:a,className:(0,i.cn)("text-2xl font-semibold leading-none tracking-tight",e),...t}));l.displayName="CardTitle";let o=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)("div",{ref:a,className:(0,i.cn)("text-sm text-muted-foreground",e),...t}));o.displayName="CardDescription";let c=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)("div",{ref:a,className:(0,i.cn)("p-6 pt-0",e),...t}));c.displayName="CardContent";let m=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)("div",{ref:a,className:(0,i.cn)("flex items-center p-6 pt-0",e),...t}));m.displayName="CardFooter"},31766:(e,t,a)=>{"use strict";a.d(t,{G7:()=>o,L$:()=>u,h_:()=>x,oI:()=>c,uB:()=>l,xL:()=>m});var s=a(18652),r=a(9861),i=a(31640),n=a(98812),d=a(28070);a(94205);let l=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.uB,{ref:a,className:(0,d.cn)("flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground",e),...t}));l.displayName=i.uB.displayName;let o=r.forwardRef(({className:e,...t},a)=>(0,s.jsxs)("div",{className:"flex items-center border-b px-3","cmdk-input-wrapper":"",children:[(0,s.jsx)(n.A,{className:"mr-2 h-4 w-4 shrink-0 opacity-50"}),(0,s.jsx)(i.uB.Input,{ref:a,className:(0,d.cn)("flex h-11 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50",e),...t})]}));o.displayName=i.uB.Input.displayName;let c=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.uB.List,{ref:a,className:(0,d.cn)("max-h-[300px] overflow-y-auto overflow-x-hidden",e),...t}));c.displayName=i.uB.List.displayName;let m=r.forwardRef((e,t)=>(0,s.jsx)(i.uB.Empty,{ref:t,className:"py-6 text-center text-sm",...e}));m.displayName=i.uB.Empty.displayName;let u=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.uB.Group,{ref:a,className:(0,d.cn)("overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground",e),...t}));u.displayName=i.uB.Group.displayName,r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.uB.Separator,{ref:a,className:(0,d.cn)("-mx-1 h-px bg-border",e),...t})).displayName=i.uB.Separator.displayName;let x=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.uB.Item,{ref:a,className:(0,d.cn)("relative flex cursor-default gap-2 select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none data-[disabled=true]:pointer-events-none data-[selected='true']:bg-accent data-[selected=true]:text-accent-foreground data-[disabled=true]:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",e),...t}));x.displayName=i.uB.Item.displayName},45502:(e,t,a)=>{"use strict";a.d(t,{U:()=>c});var s=a(18652);a(9861);var r=a(44066),i=a(52801),n=a(28070),d=a(80429),l=a(99647),o=a(72382);function c({className:e,value:t,onChange:a}){return(0,s.jsx)("div",{className:(0,n.cn)("grid gap-2",e),children:(0,s.jsxs)(o.AM,{children:[(0,s.jsx)(o.Wv,{asChild:!0,children:(0,s.jsxs)(d.$,{id:"date",variant:"outline",className:(0,n.cn)("w-[300px] justify-start text-left font-normal",!t&&"text-muted-foreground"),children:[(0,s.jsx)(r.A,{className:"mr-2 h-4 w-4"}),t?.from?t.to?(0,s.jsxs)(s.Fragment,{children:[(0,i.GP)(t.from,"dd MMM yyyy")," -"," ",(0,i.GP)(t.to,"dd MMM yyyy")]}):(0,i.GP)(t.from,"dd MMM yyyy"):(0,s.jsx)("span",{children:"Pilih rentang tanggal"})]})}),(0,s.jsx)(o.hl,{className:"w-auto p-0",align:"start",children:(0,s.jsx)(l.V,{initialFocus:!0,mode:"range",defaultMonth:t?.from,selected:t,onSelect:a,numberOfMonths:2})})]})})}},94205:(e,t,a)=>{"use strict";a.d(t,{Cf:()=>x,Es:()=>h,HM:()=>m,L3:()=>f,c7:()=>p,lG:()=>l,rr:()=>g,zM:()=>o});var s=a(18652),r=a(9861),i=a(39992),n=a(36354),d=a(28070);let l=i.bL,o=i.l9,c=i.ZL,m=i.bm,u=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.hJ,{ref:a,className:(0,d.cn)("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",e),...t}));u.displayName=i.hJ.displayName;let x=r.forwardRef(({className:e,children:t,...a},r)=>(0,s.jsxs)(c,{children:[(0,s.jsx)(u,{}),(0,s.jsxs)(i.UC,{ref:r,className:(0,d.cn)("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg",e),...a,children:[t,(0,s.jsxs)(i.bm,{className:"absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",children:[(0,s.jsx)(n.A,{className:"h-4 w-4"}),(0,s.jsx)("span",{className:"sr-only",children:"Close"})]})]})]}));x.displayName=i.UC.displayName;let p=({className:e,...t})=>(0,s.jsx)("div",{className:(0,d.cn)("flex flex-col space-y-1.5 text-center sm:text-left",e),...t});p.displayName="DialogHeader";let h=({className:e,...t})=>(0,s.jsx)("div",{className:(0,d.cn)("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2",e),...t});h.displayName="DialogFooter";let f=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.hE,{ref:a,className:(0,d.cn)("text-lg font-semibold leading-none tracking-tight",e),...t}));f.displayName=i.hE.displayName;let g=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.VY,{ref:a,className:(0,d.cn)("text-sm text-muted-foreground",e),...t}));g.displayName=i.VY.displayName},62657:(e,t,a)=>{"use strict";a.d(t,{p:()=>n});var s=a(18652),r=a(9861),i=a(28070);let n=r.forwardRef(({className:e,type:t,...a},r)=>(0,s.jsx)("input",{type:t,className:(0,i.cn)("flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",e),ref:r,...a}));n.displayName="Input"},46579:(e,t,a)=>{"use strict";a.d(t,{J:()=>o});var s=a(18652),r=a(9861),i=a(45685),n=a(13801),d=a(28070);let l=(0,n.F)("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"),o=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.b,{ref:a,className:(0,d.cn)(l(),e),...t}));o.displayName=i.b.displayName},72382:(e,t,a)=>{"use strict";a.d(t,{AM:()=>d,Wv:()=>l,hl:()=>o});var s=a(18652),r=a(9861),i=a(34403),n=a(28070);let d=i.bL,l=i.l9,o=r.forwardRef(({className:e,align:t="center",sideOffset:a=4,...r},d)=>(0,s.jsx)(i.ZL,{children:(0,s.jsx)(i.UC,{ref:d,align:t,sideOffset:a,className:(0,n.cn)("z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",e),...r})}));o.displayName=i.UC.displayName},69978:(e,t,a)=>{"use strict";a.d(t,{F:()=>d});var s=a(18652),r=a(9861),i=a(99350),n=a(28070);let d=r.forwardRef(({className:e,children:t,...a},r)=>(0,s.jsxs)(i.bL,{ref:r,className:(0,n.cn)("relative overflow-hidden",e),...a,children:[(0,s.jsx)(i.LM,{className:"h-full w-full rounded-[inherit]",children:t}),(0,s.jsx)(l,{}),(0,s.jsx)(i.OK,{})]}));d.displayName=i.bL.displayName;let l=r.forwardRef(({className:e,orientation:t="vertical",...a},r)=>(0,s.jsx)(i.VM,{ref:r,orientation:t,className:(0,n.cn)("flex touch-none select-none transition-colors","vertical"===t&&"h-full w-2.5 border-l border-l-transparent p-[1px]","horizontal"===t&&"h-2.5 flex-col border-t border-t-transparent p-[1px]",e),...a,children:(0,s.jsx)(i.lr,{className:"relative flex-1 rounded-full bg-border"})}));l.displayName=i.VM.displayName},61653:(e,t,a)=>{"use strict";a.d(t,{bq:()=>u,eb:()=>f,gC:()=>h,l6:()=>c,yv:()=>m});var s=a(18652),r=a(9861),i=a(64012),n=a(98634),d=a(14131),l=a(40422),o=a(28070);let c=i.bL;i.YJ;let m=i.WT,u=r.forwardRef(({className:e,children:t,...a},r)=>(0,s.jsxs)(i.l9,{ref:r,className:(0,o.cn)("flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1",e),...a,children:[t,(0,s.jsx)(i.In,{asChild:!0,children:(0,s.jsx)(n.A,{className:"h-4 w-4 opacity-50"})})]}));u.displayName=i.l9.displayName;let x=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.PP,{ref:a,className:(0,o.cn)("flex cursor-default items-center justify-center py-1",e),...t,children:(0,s.jsx)(d.A,{className:"h-4 w-4"})}));x.displayName=i.PP.displayName;let p=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.wn,{ref:a,className:(0,o.cn)("flex cursor-default items-center justify-center py-1",e),...t,children:(0,s.jsx)(n.A,{className:"h-4 w-4"})}));p.displayName=i.wn.displayName;let h=r.forwardRef(({className:e,children:t,position:a="popper",...r},n)=>(0,s.jsx)(i.ZL,{children:(0,s.jsxs)(i.UC,{ref:n,className:(0,o.cn)("relative z-50 max-h-96 min-w-[8rem] overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2","popper"===a&&"data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1",e),position:a,...r,children:[(0,s.jsx)(x,{}),(0,s.jsx)(i.LM,{className:(0,o.cn)("p-1","popper"===a&&"h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"),children:t}),(0,s.jsx)(p,{})]})}));h.displayName=i.UC.displayName,r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.JU,{ref:a,className:(0,o.cn)("py-1.5 pl-8 pr-2 text-sm font-semibold",e),...t})).displayName=i.JU.displayName;let f=r.forwardRef(({className:e,children:t,...a},r)=>(0,s.jsxs)(i.q7,{ref:r,className:(0,o.cn)("relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",e),...a,children:[(0,s.jsx)("span",{className:"absolute left-2 flex h-3.5 w-3.5 items-center justify-center",children:(0,s.jsx)(i.VF,{children:(0,s.jsx)(l.A,{className:"h-4 w-4"})})}),(0,s.jsx)(i.p4,{children:t})]}));f.displayName=i.q7.displayName,r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.wv,{ref:a,className:(0,o.cn)("-mx-1 my-1 h-px bg-muted",e),...t})).displayName=i.wv.displayName},70576:(e,t,a)=>{"use strict";a.d(t,{w:()=>d});var s=a(18652),r=a(9861),i=a(31302),n=a(28070);let d=r.forwardRef(({className:e,orientation:t="horizontal",decorative:a=!0,...r},d)=>(0,s.jsx)(i.b,{ref:d,decorative:a,orientation:t,className:(0,n.cn)("shrink-0 bg-border","horizontal"===t?"h-[1px] w-full":"h-full w-[1px]",e),...r}));d.displayName=i.b.displayName},54761:(e,t,a)=>{"use strict";a.d(t,{Xi:()=>o,av:()=>c,j7:()=>l,tU:()=>d});var s=a(18652),r=a(9861),i=a(3975),n=a(28070);let d=i.bL,l=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.B8,{ref:a,className:(0,n.cn)("inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground",e),...t}));l.displayName=i.B8.displayName;let o=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.l9,{ref:a,className:(0,n.cn)("inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow-sm",e),...t}));o.displayName=i.l9.displayName;let c=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)(i.UC,{ref:a,className:(0,n.cn)("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",e),...t}));c.displayName=i.UC.displayName},34843:(e,t,a)=>{"use strict";a.d(t,{T:()=>n});var s=a(18652),r=a(9861),i=a(28070);let n=r.forwardRef(({className:e,...t},a)=>(0,s.jsx)("textarea",{className:(0,i.cn)("flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",e),ref:a,...t}));n.displayName="Textarea"},86960:(e,t,a)=>{"use strict";a.d(t,{j:()=>r});var s=a(52090);let r=()=>{let e=(0,s.jE)();return{invalidate:t=>{e.invalidateQueries({queryKey:t})}}}},80658:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(27277).A)("Banknote",[["rect",{width:"20",height:"12",x:"2",y:"6",rx:"2",key:"9lu3g6"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}],["path",{d:"M6 12h.01M18 12h.01",key:"113zkx"}]])},57744:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(27277).A)("CreditCard",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]])},56951:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(27277).A)("ShoppingCart",[["circle",{cx:"8",cy:"21",r:"1",key:"jimo8o"}],["circle",{cx:"19",cy:"21",r:"1",key:"13723u"}],["path",{d:"M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12",key:"9zh506"}]])},49411:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(27277).A)("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]])},65614:(e,t,a)=>{"use strict";a.d(t,{K$:()=>n,ff:()=>i,oj:()=>d,uw:()=>r});var s=a(3953);let r=e=>(0,s.G)(`/cash-registers/${e}`,["cash-register",e.toString()]),i=(0,s.L)("/cash-register-transactions/add-cash","post"),n=(0,s.L)("/cash-register-transactions/subtract-cash","post"),d=(e,t)=>(0,s.G)(`/cash-register-transactions?source=cash&outlet_id=${e}&date=${t}`,["cash-history",e.toString(),t])},94736:(e,t,a)=>{"use strict";a.d(t,{QU:()=>r,bZ:()=>n,xZ:()=>d,zZ:()=>i});var s=a(3953);let r=(0,s.G)("/categories",["categories"]),i=(0,s.L)("/categories","post"),n=e=>(0,s.L)(`/categories/${e}`,"put")(),d=()=>(0,s.L)(e=>`/categories/${e}`,"delete")()},35402:(e,t,a)=>{"use strict";a.d(t,{$S:()=>d,CE:()=>i,ZG:()=>l,of:()=>n,rV:()=>r,s5:()=>o});var s=a(3953);let r=(0,s.L)("/inventory-histories","post");(0,s.L)("/inventory","put"),(0,s.L)("/inventory","delete");let i=(e,t)=>(0,s.G)(`/inventory-histories/outlet/${e}?date=${t}`,["inventory-histories-outlet",e.toString(),t])(),n=(0,s.L)("/adjust-inventory","post"),d=(0,s.L)("/inventory-histories/approval","post"),l=(0,s.L)("/inventory-histories/reject","post"),o=(e,t)=>(0,s.G)(`/adjust-inventory/${e}?date=${t}`,["inventory-cashier",e.toString(),t])()},6894:(e,t,a)=>{"use strict";a.d(t,{ON:()=>n,Zo:()=>r,bi:()=>i,cx:()=>d});var s=a(3953);let r=(0,s.G)("/members",["members"]),i=(0,s.L)("/members","post"),n=e=>(0,s.L)(`/members/${e}`,"put")(),d=()=>(0,s.L)(e=>`/members/${e}`,"delete")()},46156:(e,t,a)=>{"use strict";a.d(t,{r:()=>i,w:()=>r});var s=a(3953);let r=(0,s.L)("/print-template","post"),i=e=>(0,s.G)(`/print-template/${e}`,["print",e.toString()])()},76201:(e,t,a)=>{"use strict";a.d(t,{DD:()=>d,WY:()=>i,cq:()=>r,vc:()=>n});var s=a(3953);let r=e=>(0,s.G)(`/products/outlet/${e}`,["products-outlet",e.toString()]),i=(0,s.L)("/products","post"),n=e=>(0,s.L)(`/products/${e}`,"post")(),d=()=>(0,s.L)(e=>`/products/${e}`,"delete")()},28678:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>i,metadata:()=>r});var s=a(48408);a(28602);let r={title:"Kifa Bakery POS",description:"Sistem Point of Sale untuk Kifa Bakery"};function i({children:e}){return(0,s.jsx)("div",{children:e})}},30206:(e,t,a)=>{"use strict";function s(){return null}a.r(t),a.d(t,{default:()=>s})},90909:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>s});let s=(0,a(44444).registerClientReference)(function(){throw Error("Attempted to call the default export of \"D:\\\\aku\\\\kifa-bakery-frontend\\\\app\\\\pos\\\\page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"D:\\aku\\kifa-bakery-frontend\\app\\pos\\page.tsx","default")}};var t=require("../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),s=t.X(0,[660,369,794,252,801,18,486,355,812,342],()=>a(3411));module.exports=s})();
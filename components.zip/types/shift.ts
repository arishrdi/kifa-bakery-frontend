export interface Shift {
    id: number;
    outlet_id: number;
    user_id: number;
    start_time: string;
    end_time: string;
    created_at: Date;
    updated_at: Date;
}
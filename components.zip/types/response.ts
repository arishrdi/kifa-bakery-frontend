export type StatusMessage = {
  status: string;
  message: string;
};